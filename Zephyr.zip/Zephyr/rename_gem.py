import os
import re

directory = r"c:\Users\Lenovo 3rd\Desktop\MusicBot"

# Files to exclude from text replacement (like DBs, binaries, git, etc.)
exclude_dirs = {'.git', '.env', '__pycache__', 'db', 'node_modules', '.idea', '.vscode', '.gemini'}
exclude_exts = {'.pyc', '.pyo', '.db', '.sqlite', '.sqlite3', '.png', '.jpg', '.jpeg', '.gif', '.mp3', '.mp4'}

def replace_in_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        return
    
    new_content = re.sub(r'\bgem\b', 'zephyr', content)
    new_content = re.sub(r'\bGem\b', 'Zephyr', new_content)
    new_content = re.sub(r'\bGEM\b', 'ZEPHYR', new_content)
    
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Updated {filepath}")

for root, dirs, files in os.walk(directory):
    dirs[:] = [d for d in dirs if d not in exclude_dirs]
    for file in files:
        if file == 'rename_gem.py':
            continue
        if any(file.endswith(ext) for ext in exclude_exts):
            continue
        filepath = os.path.join(root, file)
        replace_in_file(filepath)

# File renames
file_renames = [
    (os.path.join(directory, 'core', 'Gem.py'), os.path.join(directory, 'core', 'Zephyr.py')),
    (os.path.join(directory, 'gem.log'), os.path.join(directory, 'zephyr.log'))
]

for old, new in file_renames:
    if os.path.exists(old):
        os.rename(old, new)
        print(f"Renamed {old} to {new}")
