"""
Zephyr Bot — Entry Point
Loads config.yml, instantiates the Zephyr bot, and runs it.
"""

import asyncio
import logging
import sys
from pathlib import Path

import yaml

# ── Logging ────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s │ %(levelname)-8s │ %(name)-18s │ %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("zephyr.log", encoding="utf-8", mode="a"),
    ],
)
log = logging.getLogger("zephyr.main")


def load_config() -> dict:
    """Load and validate config.yml."""
    config_path = Path("config.yml")
    if not config_path.exists():
        log.critical("config.yml not found! Copy config.yml.example and fill in your credentials.")
        sys.exit(1)

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    token = config.get("bot", {}).get("token", "")
    if not token or token == "YOUR_BOT_TOKEN_HERE":
        log.critical("Bot token is missing or still a placeholder! Edit config.yml.")
        sys.exit(1)

    return config


async def main():
    config = load_config()

    # Import here to avoid circular imports
    from core.Zephyr import Zephyr

    bot = Zephyr(config=config)

    log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    log.info("       ✦  K Y A N I T E  ✦")
    log.info("  Premium Discord Bot — Starting up…")
    log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    async with bot:
        await bot.start(config["bot"]["token"])


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("Zephyr shut down by user.")
