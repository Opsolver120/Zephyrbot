"""
AutoResponder — /autoresponder create/delete/edit/config
Custom trigger-response pairs. Max 20 per guild. Case-insensitive exact match.
DB: db/autoresponder.db — table: autoresponder (guild_id, trigger_text, response)
"""
from __future__ import annotations
import logging
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.autoresponder")

class AutoResponderCog(commands.Cog):
    def __init__(self, bot: Zephyr):
        self.bot = bot

    ar = app_commands.Group(name="autoresponder", description="Auto-response management")

    @ar.command(name="create", description="Create a new auto-response trigger")
    @app_commands.describe(trigger="Trigger phrase (exact, case-insensitive)", response="Bot's reply")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ar_create(self, it: discord.Interaction, trigger: str, response: str):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/autoresponder.db") as db:
            async with db.execute("SELECT COUNT(*) FROM autoresponder WHERE guild_id=?",(g.id,)) as c:
                cnt = (await c.fetchone())[0]
            if cnt >= 20:
                return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Max 20 auto-responses per server.",color=COLORS["error"]),ephemeral=True)
            await db.execute("INSERT OR REPLACE INTO autoresponder(guild_id,trigger_text,response) VALUES(?,?,?)",(g.id,trigger.lower(),response))
            await db.commit()
        self.bot.cache["autoresponder"].setdefault(g.id,{})[trigger.lower()] = response
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Auto-response created: **{trigger}** → {response}",color=COLORS["success"]))

    @ar.command(name="delete", description="Delete an auto-response trigger")
    @app_commands.describe(trigger="Trigger to delete")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ar_delete(self, it: discord.Interaction, trigger: str):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/autoresponder.db") as db:
            await db.execute("DELETE FROM autoresponder WHERE guild_id=? AND trigger_text=?",(g.id,trigger.lower()))
            await db.commit()
        self.bot.cache["autoresponder"].get(g.id,{}).pop(trigger.lower(),None)
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Auto-response **{trigger}** deleted.",color=COLORS["success"]))

    @ar.command(name="edit", description="Edit an existing auto-response")
    @app_commands.describe(trigger="Trigger to edit", new_response="New response")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ar_edit(self, it: discord.Interaction, trigger: str, new_response: str):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/autoresponder.db") as db:
            await db.execute("UPDATE autoresponder SET response=? WHERE guild_id=? AND trigger_text=?",(new_response,g.id,trigger.lower()))
            await db.commit()
        self.bot.cache["autoresponder"].setdefault(g.id,{})[trigger.lower()] = new_response
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Auto-response **{trigger}** updated.",color=COLORS["success"]))

    @ar.command(name="config", description="List all auto-responses")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ar_config(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        triggers = self.bot.cache["autoresponder"].get(g.id, {})
        if not triggers:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No auto-responses configured.",color=COLORS["info"]),ephemeral=True)
        lines = [f"{EMOJIS['dot']} **{t}** → {r}" for t,r in triggers.items()]
        em = create_embed(description=f"## {EMOJIS['automod']} Auto-Responses [{len(triggers)}]\n" + "\n".join(lines),color=COLORS["primary"])
        await it.response.send_message(embed=em, ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, msg: discord.Message):
        if msg.author.bot or not msg.guild: return
        triggers = self.bot.cache["autoresponder"].get(msg.guild.id, {})
        resp = triggers.get(msg.content.lower())
        if resp:
            try: await msg.channel.send(resp)
            except discord.HTTPException: pass

async def setup(bot):
    await bot.add_cog(AutoResponderCog(bot))
    log.info("  ✓ AutoResponderCog loaded")
