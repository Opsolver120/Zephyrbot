"""
Utility Commands — help, ping, avatar, banner, userinfo, serverinfo, etc.
Includes "Ultra-Premium" Help Command with Select Menu navigation.
Supports both Slash Commands (/) and Prefix Commands ($).
"""
from __future__ import annotations
import time
import logging
import aiosqlite
from typing import TYPE_CHECKING, List

import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS, LINKS
from utils.Tools import create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.utility")


# ═══════════════════════════════════════════════════════════════
#  HELP MENU — Compact, All Commands
# ═══════════════════════════════════════════════════════════════

# Map every cog class name → display info  (label, emoji, description)
_COG_META: dict[str, tuple[str, str, str]] = {
    "AntinukeCog":      ("Antinuke",      EMOJIS["shield"],        "Server protection & raid defence"),
    "AutomodCog":       ("Automod",       EMOJIS["automod"],       "Auto-moderation filters & rules"),
    "AutomationCog":    ("Automation",    EMOJIS["settings"],      "Auto-roles, voice roles, status roles"),
    "AutoResponderCog": ("AutoResponder", EMOJIS["message"],       "Custom trigger → reply system"),
    "BlacklistCog":     ("Blacklist",     EMOJIS["denied"],        "Word blacklist & global blocks"),
    "ConfigCog":        ("Config",        EMOJIS["staff"],         "Autorole, ignore, autoreact setup"),
    "CustomRolesCog":   ("Custom Roles",  EMOJIS["palette"],       "Vanity / self-assignable roles"),
    "EmergencyCog":     ("Emergency",     EMOJIS["emergency"],     "Emergency lockdown & recovery"),
    "GiveawayCog":      ("Giveaways",     EMOJIS["giveaway"],      "Create & manage giveaways"),
    "MediaCog":         ("Media Only",    EMOJIS["camera"],        "Media-only channel enforcement"),
    "ModerationCog":    ("Moderation",    EMOJIS["ban_hammer"],    "Ban, kick, timeout, purge, warns"),
    "MusicCog":         ("Music",         EMOJIS["a_music"],       "Play, queue, volume, player controls"),
    "NightmodeCog":     ("Nightmode",     EMOJIS["nightmode"],     "Scheduled slow-mode & lockdowns"),
    "NoPrefixCog":      ("No Prefix",     EMOJIS["admin"],         "Owner-only quick commands"),
    "NotifyCog":        ("Notify",        EMOJIS["bell"],          "Twitch / YouTube live alerts"),
    "StickyCog":        ("Sticky",        EMOJIS["pin"],           "Sticky messages in channels"),
    "UtilityCog":       ("Utility",       EMOJIS["toolbox"],       "Ping, help, avatar, user/server info"),
    "VoiceCog":         ("Voice",         EMOJIS["voice"],         "Voice kick, mute, move, lock"),
    "VoiceBanCog":      ("Voice Ban",     EMOJIS["mute"],          "Ban users from joining voice"),
    "WelcomeCog":       ("Welcome",       EMOJIS["waving_hand"],   "Welcome / greeter messages"),
}


def _count_commands(cog: commands.Cog) -> int:
    """Count all (app + prefix) commands in a cog."""
    total = sum(1 for _ in cog.walk_app_commands())
    seen = set()
    for cmd in cog.walk_app_commands():
        seen.add(cmd.qualified_name)
    for cmd in cog.get_commands():
        if cmd.qualified_name not in seen:
            total += 1
    return total


def _build_cmd_list(cog: commands.Cog) -> list[str]:
    """Build a compact list of command strings for a cog."""
    lines: list[str] = []
    seen: set[str] = set()

    for cmd in cog.walk_app_commands():
        if cmd.qualified_name in seen:
            continue
        seen.add(cmd.qualified_name)
        name = cmd.qualified_name.replace(" ", " ")
        lines.append(f"`/{name}` — {cmd.description or '—'}")

    for cmd in cog.get_commands():
        if cmd.qualified_name not in seen:
            seen.add(cmd.qualified_name)
            brief = cmd.brief or cmd.short_doc or "—"
            lines.append(f"`${cmd.qualified_name}` — {brief}")

    return lines or ["*No commands*"]


class HelpSelect(discord.ui.Select):
    """Category dropdown — covers every loaded cog."""

    def __init__(self, bot: Zephyr):
        options: list[discord.SelectOption] = []
        self._bot = bot

        for cog_cls_name, cog_obj in sorted(bot.cogs.items(), key=lambda x: x[0]):
            meta = _COG_META.get(cog_cls_name)
            if not meta:
                continue  # truly unknown cog
            label, emoji, desc = meta
            cnt = _count_commands(cog_obj)
            if cnt == 0:
                continue
            options.append(discord.SelectOption(
                label=f"{label}  ({cnt})",
                description=desc,
                emoji=emoji,
                value=cog_cls_name,
            ))

        if not options:
            options.append(discord.SelectOption(label="No modules", value="_none"))

        super().__init__(
            placeholder="📂 Browse a category…",
            options=options[:25],
        )

    async def callback(self, interaction: discord.Interaction):
        cog_cls = self.values[0]
        if cog_cls == "_none":
            return await interaction.response.defer()

        cog = self._bot.cogs.get(cog_cls)
        if not cog:
            return await interaction.response.send_message("Module not found.", ephemeral=True)

        meta = _COG_META.get(cog_cls, (cog_cls, "📂", ""))
        label, emoji, _ = meta
        lines = _build_cmd_list(cog)

        em = create_embed(
            description=f"## {emoji} {label}\n" + "\n".join(lines),
            color=COLORS["primary"],
        )
        em.set_footer(text=f"✦ Zephyr • {len(lines)} commands")
        await interaction.response.edit_message(embed=em, view=self.view)


class HelpView(discord.ui.View):
    def __init__(self, bot: Zephyr, author_id: int):
        super().__init__(timeout=180)
        self.author_id = author_id
        self.add_item(HelpSelect(bot))
        self.add_item(discord.ui.Button(label="Support", url=LINKS["support"], emoji="💜"))
        self.add_item(discord.ui.Button(label="Docs", url=LINKS["docs"], emoji="📖"))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message("❌ This menu belongs to someone else.", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        for item in self.children:
            if isinstance(item, discord.ui.Select):
                item.disabled = True
        try:
            await self.message.edit(view=self)  # type: ignore
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════
#  COG
# ═══════════════════════════════════════════════════════════════

class UtilityCog(commands.Cog):
    """Utility commands for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot
        self._start_time = time.time()

    # ── PING (Slash + Prefix) ──────────────────────────────────
    async def _ping_logic(self, interaction_or_ctx):
        start_db = time.perf_counter()
        async with aiosqlite.connect("db/whitelist.db") as db:
            async with db.execute("SELECT 1") as cur:
                await cur.fetchone()
        db_latency = (time.perf_counter() - start_db) * 1000
        ws_latency = self.bot.latency * 1000
        ram_cache = len(self.bot.cache.get("prefixes", {})) + len(self.bot.cache.get("whitelist", {}))

        # Determine latency quality
        if ws_latency < 100:
            ws_status = f"{EMOJIS['green_circle']} Excellent"
            ws_color = COLORS["success"]
        elif ws_latency < 200:
            ws_status = f"{EMOJIS['yellow_circle']} Good"
            ws_color = COLORS["warning"]
        elif ws_latency < 300:
            ws_status = f"{EMOJIS['orange_circle']} Fair"
            ws_color = COLORS["warning"]
        else:
            ws_status = f"{EMOJIS['red_circle']} Poor"
            ws_color = COLORS["error"]

        em = create_embed(
            description=(
                f"## {EMOJIS['ping_pong']} Pong!\n"
                f"{EMOJIS['websocket']} **WebSocket:** `{ws_latency:.0f}ms` {ws_status}\n"
                f"{EMOJIS['database']} **Database:** `{db_latency:.1f}ms`\n"
                f"{EMOJIS['cache']} **Cache:** `{ram_cache}` items\n"
                f"{EMOJIS['uptime']} **Uptime:** <t:{int(self._start_time)}:R>"
            ),
            color=ws_color,
        )

        if isinstance(interaction_or_ctx, discord.Interaction):
            await interaction_or_ctx.response.send_message(embed=em)
        else:
            await interaction_or_ctx.send(embed=em)


    @app_commands.command(name="ping", description="Check bot latency")
    async def ping_slash(self, interaction: discord.Interaction):
        await self._ping_logic(interaction)

    @commands.command(name="ping")
    async def ping_prefix(self, ctx: commands.Context):
        await self._ping_logic(ctx)

    # ── HELP (Slash + Prefix) ──────────────────────────────────
    async def _help_logic(self, interaction_or_ctx):
        user = interaction_or_ctx.user if isinstance(interaction_or_ctx, discord.Interaction) else interaction_or_ctx.author
        guild = interaction_or_ctx.guild
        prefix = self.bot.cache["prefixes"].get(guild.id if guild else 0, self.bot._default_prefix)

        # Build compact category grid for home page
        cats: list[str] = []
        total_cmds = 0
        for cog_cls_name, cog_obj in sorted(self.bot.cogs.items(), key=lambda x: x[0]):
            meta = _COG_META.get(cog_cls_name)
            if not meta:
                continue
            label, emoji, desc = meta
            cnt = _count_commands(cog_obj)
            if cnt == 0:
                continue
            total_cmds += cnt
            cats.append(f"{emoji} **{label}** — `{cnt}` cmds")

        cat_grid = "\n".join(cats)

        em = create_embed(
            description=(
                f"## 💎 Zephyr\n"
                f"-# Premium Discord Bot — `{total_cmds}` commands\n\n"
                f"🛠️ **Prefix:** `{prefix}` • **Slash:** `/`\n\n"
                f"{cat_grid}\n\n"
                f"-# Select a category below to view commands"
            ),
            color=COLORS["primary"],
        )

        if self.bot.user:
            em.set_thumbnail(url=self.bot.user.display_avatar.url)

        view = HelpView(self.bot, user.id)

        if isinstance(interaction_or_ctx, discord.Interaction):
            await interaction_or_ctx.response.send_message(embed=em, view=view)
            view.message = await interaction_or_ctx.original_response()
        else:
            view.message = await interaction_or_ctx.send(embed=em, view=view)

    @app_commands.command(name="help", description="View all commands")
    async def help_slash(self, interaction: discord.Interaction):
        await self._help_logic(interaction)

    @commands.command(name="help")
    async def help_prefix(self, ctx: commands.Context):
        await self._help_logic(ctx)

    # ── OTHER UTILS ────────────────────────────────────────────
    @app_commands.command(name="avatar", description="View user's avatar")
    @app_commands.describe(user="User to view avatar of")
    async def avatar_slash(self, interaction: discord.Interaction, user: discord.Member = None):
        target = user or interaction.user
        em = create_embed(description=f"## 🖼️ {target.display_name}'s Avatar", color=target.color if target.color.value else COLORS["primary"])
        em.set_author(name=target.display_name, icon_url=target.display_avatar.url)
        em.set_image(url=target.display_avatar.with_size(1024).url)
        await interaction.response.send_message(embed=em)

    @commands.command(name="avatar", aliases=["av", "pfp"])
    async def avatar_prefix(self, ctx: commands.Context, user: discord.Member = None):
        target = user or ctx.author
        em = create_embed(description=f"## 🖼️ {target.display_name}'s Avatar", color=target.color if target.color.value else COLORS["primary"])
        em.set_author(name=target.display_name, icon_url=target.display_avatar.url)
        em.set_image(url=target.display_avatar.with_size(1024).url)
        await ctx.send(embed=em)

    @app_commands.command(name="userinfo", description="User details")
    async def userinfo(self, interaction: discord.Interaction, user: discord.Member = None):
        target = user or interaction.user
        
        # Compact display with roles
        roles = [r.mention for r in target.roles[1:]][:8]  # Skip @everyone, max 8
        role_str = " ".join(roles) if roles else "`None`"
        
        em = create_embed(
            description=(
                f"## {EMOJIS['member']} User Info\n"
                f"**{target.mention}** • `{target.id}`\n\n"
                f"📅 **Joined:** <t:{int(target.joined_at.timestamp())}:R>\n"
                f"📅 **Created:** <t:{int(target.created_at.timestamp())}:R>\n"
                f"{EMOJIS['role']} **Roles:** {role_str}"
            ),
            color=target.color if target.color.value else COLORS["primary"]
        )
        await interaction.response.send_message(embed=em)

    @commands.command(name="userinfo", aliases=["ui", "whois"])
    async def userinfo_prefix(self, ctx: commands.Context, user: discord.Member = None):
        target = user or ctx.author
        roles = [r.mention for r in target.roles[1:]][:8]
        role_str = " ".join(roles) if roles else "`None`"
        em = create_embed(
            description=(
                f"## {EMOJIS['member']} User Info\n"
                f"**{target.mention}** • `{target.id}`\n\n"
                f"📅 **Joined:** <t:{int(target.joined_at.timestamp())}:R>\n"
                f"📅 **Created:** <t:{int(target.created_at.timestamp())}:R>\n"
                f"{EMOJIS['role']} **Roles:** {role_str}"
            ),
            color=target.color if target.color.value else COLORS["primary"]
        )
        await ctx.send(embed=em)

    @app_commands.command(name="serverinfo", description="Server information")
    async def serverinfo(self, interaction: discord.Interaction):
        guild = interaction.guild
        
        em = create_embed(
            description=(
                f"## 🏰 {guild.name}\n"
                f"-# `{guild.id}`\n\n"
                f"{EMOJIS['member']} **Members:** `{guild.member_count}`\n"
                f"💬 **Channels:** `{len([c for c in guild.channels if isinstance(c, discord.TextChannel)])}` text • `{len([c for c in guild.channels if isinstance(c, discord.VoiceChannel)])}` voice\n"
                f"{EMOJIS['boost']} **Boost:** Level `{guild.premium_tier}` • `{guild.premium_subscription_count}` boosts\n"
                f"{EMOJIS['role']} **Roles:** `{len(guild.roles)}`\n"
                f"{EMOJIS['owner']} **Owner:** <@{guild.owner_id}>\n"
                f"📅 **Created:** <t:{int(guild.created_at.timestamp())}:R>"
            ),
            color=COLORS["primary"]
        )
        if guild.icon:
            em.set_thumbnail(url=guild.icon.url)
        await interaction.response.send_message(embed=em)

    @commands.command(name="serverinfo", aliases=["si"])
    async def serverinfo_prefix(self, ctx: commands.Context):
        guild = ctx.guild
        if not guild:
            return
        em = create_embed(
            description=(
                f"## 🏰 {guild.name}\n"
                f"-# `{guild.id}`\n\n"
                f"{EMOJIS['member']} **Members:** `{guild.member_count}`\n"
                f"💬 **Channels:** `{len([c for c in guild.channels if isinstance(c, discord.TextChannel)])}` text • `{len([c for c in guild.channels if isinstance(c, discord.VoiceChannel)])}` voice\n"
                f"{EMOJIS['boost']} **Boost:** Level `{guild.premium_tier}` • `{guild.premium_subscription_count}` boosts\n"
                f"{EMOJIS['role']} **Roles:** `{len(guild.roles)}`\n"
                f"{EMOJIS['owner']} **Owner:** <@{guild.owner_id}>\n"
                f"📅 **Created:** <t:{int(guild.created_at.timestamp())}:R>"
            ),
            color=COLORS["primary"]
        )
        if guild.icon:
            em.set_thumbnail(url=guild.icon.url)
        await ctx.send(embed=em)


async def setup(bot: Zephyr):
    await bot.add_cog(UtilityCog(bot))
    log.info("  ✓ UtilityCog loaded")
