"""
Sticky Message System — /sticky add/remove/list
A message that sticks to the bottom of the channel.
Uses a lock/debounce to prevent race conditions.
DB: db/sticky.db — table: sticky (guild_id, channel_id, message_id, content, is_embed, color)
"""
from __future__ import annotations
import asyncio, logging
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.sticky")

class StickyCog(commands.Cog):
    def __init__(self, bot: Zephyr):
        self.bot = bot
        self._locks: dict[int, asyncio.Lock] = {}

    sticky = app_commands.Group(name="sticky", description="Sticky message management")

    @sticky.command(name="add", description="Add a sticky message to a channel")
    @app_commands.describe(channel="Channel",message="Message content",embed="Send as embed?",color="Hex color for embed (e.g. #5865F2)")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def sticky_add(self, it: discord.Interaction, channel: discord.TextChannel, message: str, embed: bool = False, color: str | None = None):
        g = it.guild
        if not g: return
        col = color if color else str(COLORS["primary"])
        async with aiosqlite.connect("db/sticky.db") as db:
            await db.execute("INSERT OR REPLACE INTO sticky(guild_id,channel_id,message_id,content,is_embed,color) VALUES(?,?,0,?,?,?)",(g.id,channel.id,message,int(embed),col))
            await db.commit()
        self.bot.cache["sticky"].setdefault(g.id,{})[channel.id] = {"message_id":0,"content":message,"is_embed":embed,"color":col}
        await it.response.send_message(embed=create_embed(description=f"## 📌 Sticky Set\n{EMOJIS['success']} Sticky message set in {channel.mention}",color=COLORS["success"]))

    @sticky.command(name="remove", description="Remove the sticky message from a channel")
    @app_commands.describe(channel="Channel")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def sticky_remove(self, it: discord.Interaction, channel: discord.TextChannel):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/sticky.db") as db:
            await db.execute("DELETE FROM sticky WHERE guild_id=? AND channel_id=?",(g.id,channel.id))
            await db.commit()
        self.bot.cache["sticky"].get(g.id,{}).pop(channel.id,None)
        await it.response.send_message(embed=create_embed(description=f"## 📌 Sticky Removed\n{EMOJIS['success']} Sticky message removed from {channel.mention}",color=COLORS["success"]))

    @sticky.command(name="list", description="List all sticky messages")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def sticky_list(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        stickies = self.bot.cache["sticky"].get(g.id, {})
        if not stickies:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No sticky messages.",color=COLORS["info"]),ephemeral=True)
        lines = []
        for cid, data in stickies.items():
            cnt = data["content"]
            lines.append(f"{EMOJIS['channel']} <#{cid}> — {cnt[:50]}{'…' if len(cnt)>50 else ''}")
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['pin']} Sticky Messages\n" + "\n".join(lines),color=COLORS["primary"]),ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, msg: discord.Message):
        if not msg.guild: return
        guild_stickies = self.bot.cache["sticky"].get(msg.guild.id, {})
        sticky_data = guild_stickies.get(msg.channel.id)
        if not sticky_data: return
        if msg.author.id == self.bot.user.id and sticky_data.get("message_id") == msg.id: return

        lock = self._locks.setdefault(msg.channel.id, asyncio.Lock())
        if lock.locked(): return

        async with lock:
            old_id = sticky_data.get("message_id", 0)
            if old_id:
                try:
                    old = await msg.channel.fetch_message(old_id)
                    await old.delete()
                except discord.HTTPException: pass

            if sticky_data["is_embed"]:
                col_val = sticky_data.get("color", COLORS["primary"])
                if isinstance(col_val, str):
                    try: col_val = int(col_val.lstrip("#"),16)
                    except ValueError: col_val = COLORS["primary"]
                em = discord.Embed(description=sticky_data["content"],color=col_val)
                em.set_footer(text="📌 Sticky Message")
                new = await msg.channel.send(embed=em)
            else:
                new = await msg.channel.send(f"📌 {sticky_data['content']}")

            sticky_data["message_id"] = new.id

async def setup(bot):
    await bot.add_cog(StickyCog(bot))
    log.info("  ✓ StickyCog loaded")
