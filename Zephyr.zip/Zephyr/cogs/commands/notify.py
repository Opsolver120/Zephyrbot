"""
Notification System (Stream Alerts) — /setnotif twitch/youtube/list/reset
Monitors on_presence_update for Streaming activities matching monitored roles.
DB: db/notify.db — tables: notify_config(guild_id, platform, role_id, channel_id)
"""
from __future__ import annotations
import logging
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.notify")


class NotifyCog(commands.Cog):
    """Stream notification system for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot
        self._notified: dict[int, set[int]] = {}  # guild_id -> set of notified user_ids (avoid spam)

    notif = app_commands.Group(name="setnotif", description="Stream notification configuration")

    @notif.command(name="twitch", description="Set up Twitch stream alerts")
    @app_commands.describe(role="Role to monitor for streaming", channel="Channel to send alerts in")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def notif_twitch(self, it: discord.Interaction, role: discord.Role, channel: discord.TextChannel):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/notify.db") as db:
            await db.execute(
                "INSERT OR REPLACE INTO notify_config(guild_id, platform, role_id, channel_id) VALUES(?,?,?,?)",
                (g.id, "twitch", role.id, channel.id),
            )
            await db.commit()
        self.bot.cache.setdefault("notify", {}).setdefault(g.id, {})["twitch"] = {"role_id": role.id, "channel_id": channel.id}
        em = create_embed(

            description=(
                f"## {EMOJIS['a_live']} Twitch Alerts Configured\n{EMOJIS['role']} **Monitoring Role:** {role.mention}\n"
                f"{EMOJIS['channel']} **Alert Channel:** {channel.mention}\n\n"
                f"{EMOJIS['info']} When a member with this role starts streaming on Twitch, "
                f"an alert will be sent to {channel.mention}."
            ),
            color=COLORS["premium"],
        )
        em.set_footer(text="Zephyr Notifications", icon_url=self.bot.user.display_avatar.url if self.bot.user else None)
        await it.response.send_message(embed=em)

    @notif.command(name="youtube", description="Set up YouTube stream alerts")
    @app_commands.describe(role="Role to monitor for streaming", channel="Channel to send alerts in")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def notif_youtube(self, it: discord.Interaction, role: discord.Role, channel: discord.TextChannel):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/notify.db") as db:
            await db.execute(
                "INSERT OR REPLACE INTO notify_config(guild_id, platform, role_id, channel_id) VALUES(?,?,?,?)",
                (g.id, "youtube", role.id, channel.id),
            )
            await db.commit()
        self.bot.cache.setdefault("notify", {}).setdefault(g.id, {})["youtube"] = {"role_id": role.id, "channel_id": channel.id}
        em = create_embed(

            description=(
                f"## {EMOJIS['a_live']} YouTube Alerts Configured\n{EMOJIS['role']} **Monitoring Role:** {role.mention}\n"
                f"{EMOJIS['channel']} **Alert Channel:** {channel.mention}\n\n"
                f"{EMOJIS['info']} When a member with this role starts streaming on YouTube, "
                f"an alert will be sent to {channel.mention}."
            ),
            color=COLORS["premium"],
        )
        em.set_footer(text="Zephyr Notifications", icon_url=self.bot.user.display_avatar.url if self.bot.user else None)
        await it.response.send_message(embed=em)

    @notif.command(name="list", description="List notification configurations")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def notif_list(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        configs = self.bot.cache.get("notify", {}).get(g.id, {})
        if not configs:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No notifications configured.", color=COLORS["info"]), ephemeral=True)
        lines = []
        for platform, data in configs.items():
            lines.append(f"{EMOJIS['a_live']} **{platform.title()}** — Role: <@&{data['role_id']}> → Channel: <#{data['channel_id']}>")
        em = create_embed(
            description=f"## {EMOJIS['settings']} Notification Configs\n" + "\n".join(lines),
            color=COLORS["primary"],
        )
        em.set_footer(text="✦ Zephyr Notifications", icon_url=self.bot.user.display_avatar.url if self.bot.user else None)
        await it.response.send_message(embed=em, ephemeral=True)

    @notif.command(name="reset", description="Clear all notification configurations")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def notif_reset(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/notify.db") as db:
            await db.execute("DELETE FROM notify_config WHERE guild_id=?", (g.id,))
            await db.commit()
        self.bot.cache.get("notify", {}).pop(g.id, None)
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} All notification configs cleared.", color=COLORS["success"]))

    # ── Stream detection listener ──────────────────────────────
    @commands.Cog.listener()
    async def on_presence_update(self, before: discord.Member, after: discord.Member):
        guild = after.guild

        # Check streaming transitions
        was_streaming = any(isinstance(a, discord.Streaming) for a in before.activities)
        is_streaming = any(isinstance(a, discord.Streaming) for a in after.activities)

        # Clear notified status when user stops streaming
        if was_streaming and not is_streaming:
            self._notified.get(guild.id, set()).discard(after.id)
            return

        if was_streaming or not is_streaming:
            return  # not a new stream start

        configs = self.bot.cache.get("notify", {}).get(guild.id, {})
        if not configs:
            return

        # Prevent duplicate alerts
        guild_notified = self._notified.setdefault(guild.id, set())
        if after.id in guild_notified:
            return
        guild_notified.add(after.id)

        streaming_activity = next((a for a in after.activities if isinstance(a, discord.Streaming)), None)
        if not streaming_activity:
            return

        platform = streaming_activity.platform.lower() if streaming_activity.platform else "unknown"

        for p_key, data in configs.items():
            if p_key not in platform:
                continue
            role = guild.get_role(data["role_id"])
            if not role or role not in after.roles:
                continue
            channel = guild.get_channel(data["channel_id"])
            if not channel or not isinstance(channel, discord.TextChannel):
                continue

            em = create_embed(

                description=(
                    f"## {EMOJIS['a_live']} {after.display_name} is now LIVE!\n{EMOJIS['member']} **Streamer:** {after.mention}\n"
                    f"{EMOJIS['a_star']} **Title:** {streaming_activity.name or 'No title'}\n"
                    f"{EMOJIS['link']} **Watch:** [{streaming_activity.url}]({streaming_activity.url})"
                ),
                color=COLORS["premium"],
            )
            if after.display_avatar:
                em.add_field(name="Avatar", value=f"[View Avatar]({after.display_avatar.url})", inline=False)
            em.set_footer(text=f"Platform: {platform.title()}", icon_url=self.bot.user.display_avatar.url if self.bot.user else None)

            try:
                await channel.send(embed=em)
            except discord.HTTPException:
                pass


async def setup(bot: Zephyr):
    await bot.add_cog(NotifyCog(bot))
    log.info("  ✓ NotifyCog (Stream Alerts) loaded")
