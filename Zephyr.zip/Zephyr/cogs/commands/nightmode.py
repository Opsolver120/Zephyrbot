"""
Nightmode — /nightmode enable/disable
Strips/restores Administrator permission from all roles below the bot.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

import aiosqlite
import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.nightmode")


class NightmodeCog(commands.Cog):
    """Nightmode — temporarily strip admin from all roles."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    nightmode = app_commands.Group(name="nightmode", description="Nightmode security commands")

    @nightmode.command(name="enable", description="Strip Administrator from all roles below the bot")
    @app_commands.checks.has_permissions(administrator=True)
    async def nm_enable(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return

        if interaction.user.id != guild.owner_id and interaction.user.id not in self.bot.owner_ids_set:
            return await interaction.followup.send(
                embed=create_embed(description=f"{EMOJIS['denied']} Only the Server Owner can enable Nightmode.", color=COLORS["error"]),
                ephemeral=True,
            )

        backup = []
        stripped = 0

        for role in guild.roles:
            if role.is_default() or role.managed:
                continue
            if guild.me and role >= guild.me.top_role:
                continue
            if role.permissions.administrator:
                backup.append(role.id)
                new_perms = role.permissions
                new_perms.administrator = False
                try:
                    await role.edit(permissions=new_perms, reason="Zephyr Nightmode — Admin stripped")
                    stripped += 1
                except discord.HTTPException:
                    pass

        async with aiosqlite.connect("db/anti.db") as db:
            await db.execute(
                "INSERT INTO nightmode (guild_id, enabled, backup) VALUES (?, 1, ?) ON CONFLICT(guild_id) DO UPDATE SET enabled = 1, backup = ?",
                (guild.id, json.dumps(backup), json.dumps(backup)),
            )
            await db.commit()

        em = create_embed(

            description=(
                f"## {EMOJIS['nightmode']} Nightmode Activated\n{EMOJIS['shield_on']} Stripped **Administrator** from **{stripped}** role(s).\n\n"
                f"{EMOJIS['info']} Use `/nightmode disable` to restore permissions."
            ),
            color=COLORS["zephyr"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    @nightmode.command(name="disable", description="Restore Administrator to previously stripped roles")
    @app_commands.checks.has_permissions(administrator=True)
    async def nm_disable(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return

        if interaction.user.id != guild.owner_id and interaction.user.id not in self.bot.owner_ids_set:
            return await interaction.followup.send(
                embed=create_embed(description=f"{EMOJIS['denied']} Only the Server Owner can disable Nightmode.", color=COLORS["error"]),
                ephemeral=True,
            )

        async with aiosqlite.connect("db/anti.db") as db:
            async with db.execute(
                "SELECT backup FROM nightmode WHERE guild_id = ?", (guild.id,)
            ) as cur:
                row = await cur.fetchone()

        if not row:
            return await interaction.followup.send(
                embed=create_embed(description=f"{EMOJIS['error']} Nightmode was not active.", color=COLORS["error"]),
                ephemeral=True,
            )

        role_ids = json.loads(row[0])
        restored = 0

        for rid in role_ids:
            role = guild.get_role(rid)
            if not role:
                continue
            new_perms = role.permissions
            new_perms.administrator = True
            try:
                await role.edit(permissions=new_perms, reason="Zephyr Nightmode — Admin restored")
                restored += 1
            except discord.HTTPException:
                pass

        async with aiosqlite.connect("db/anti.db") as db:
            await db.execute(
                "UPDATE nightmode SET enabled = 0, backup = '[]' WHERE guild_id = ?",
                (guild.id,),
            )
            await db.commit()

        em = create_embed(

            description=f"## {EMOJIS['success']} Nightmode Deactivated\n{EMOJIS['shield']} Restored **Administrator** to **{restored}** role(s).",
            color=COLORS["success"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)


async def setup(bot: Zephyr):
    await bot.add_cog(NightmodeCog(bot))
    log.info("  ✓ NightmodeCog loaded")
