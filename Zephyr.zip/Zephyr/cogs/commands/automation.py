"""
Automation System — /automation vcrole set/remove, /automation statusrole set/remove
Refactored to use subgroups for cleaner "space-based" commands instead of underscores.
DB: db/automation.db
"""
from __future__ import annotations
import asyncio, logging
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.automation")

class AutomationCog(commands.Cog):
    def __init__(self, bot: Zephyr):
        self.bot = bot

    # Base command group: /automation
    auto = app_commands.Group(name="automation", description="Automation system")

    # ── Subgroup: /automation vcrole ... ───────────────────────
    vcrole_group = app_commands.Group(name="vcrole", description="Manage VC roles", parent=auto)

    @vcrole_group.command(name="set", description="Set a role to assign when users join any VC")
    @app_commands.describe(role="Role to assign on VC join")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def vcrole_set(self, it: discord.Interaction, role: discord.Role):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/automation.db") as db:
            await db.execute("INSERT OR REPLACE INTO automation_vcrole(guild_id,role_id) VALUES(?,?)",(g.id,role.id))
            await db.commit()
        self.bot.cache.setdefault("automation_vcrole",{})[g.id] = role.id
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} VC role set to {role.mention}. Users joining any VC will receive it.",color=COLORS["success"]))

    @vcrole_group.command(name="remove", description="Remove the VC role config")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def vcrole_remove(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/automation.db") as db:
            await db.execute("DELETE FROM automation_vcrole WHERE guild_id=?",(g.id,))
            await db.commit()
        self.bot.cache.get("automation_vcrole",{}).pop(g.id,None)
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} VC role config removed.",color=COLORS["success"]))

    # ── Subgroup: /automation statusrole ... ───────────────────
    statusrole_group = app_commands.Group(name="statusrole", description="Manage status roles", parent=auto)

    @statusrole_group.command(name="set", description="Assign a role if user status contains text")
    @app_commands.describe(text="Text to match in custom status",role="Role to assign")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def statusrole_set(self, it: discord.Interaction, text: str, role: discord.Role):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/automation.db") as db:
            await db.execute("INSERT OR REPLACE INTO automation_status(guild_id,text,role_id) VALUES(?,?,?)",(g.id,text.lower(),role.id))
            await db.commit()
        self.bot.cache.setdefault("automation_status",{}).setdefault(g.id,[]).append({"text":text.lower(),"role_id":role.id})
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Status role: users with `{text}` in status get {role.mention}.",color=COLORS["success"]))

    @statusrole_group.command(name="remove", description="Remove a status role trigger")
    @app_commands.describe(text="Text trigger to remove")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def statusrole_remove(self, it: discord.Interaction, text: str):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/automation.db") as db:
            await db.execute("DELETE FROM automation_status WHERE guild_id=? AND text=?",(g.id,text.lower()))
            await db.commit()
        entries = self.bot.cache.get("automation_status",{}).get(g.id,[])
        self.bot.cache.get("automation_status",{})[g.id] = [e for e in entries if e["text"]!=text.lower()]
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Status role trigger `{text}` removed.",color=COLORS["success"]))

    # ── VC Role Listener ───────────────────────────────────────
    @commands.Cog.listener()
    async def on_voice_state_update(self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState):
        role_id = self.bot.cache.get("automation_vcrole",{}).get(member.guild.id)
        if not role_id: return
        role = member.guild.get_role(role_id)
        if not role: return

        if before.channel is None and after.channel is not None:
            if role not in member.roles:
                for attempt in range(5):
                    try:
                        await member.add_roles(role, reason="Zephyr — VC Role")
                        break
                    except discord.HTTPException:
                        await asyncio.sleep(1)
        elif before.channel is not None and after.channel is None:
            if role in member.roles:
                for attempt in range(5):
                    try:
                        await member.remove_roles(role, reason="Zephyr — VC Role")
                        break
                    except discord.HTTPException:
                        await asyncio.sleep(1)

    # ── Status Role Listener ──────────────────────────────────
    @commands.Cog.listener()
    async def on_presence_update(self, before: discord.Member, after: discord.Member):
        entries = self.bot.cache.get("automation_status",{}).get(after.guild.id,[])
        if not entries: return

        def get_status_text(member: discord.Member) -> str:
            for a in member.activities:
                if isinstance(a, discord.CustomActivity) and a.name:
                    return a.name.lower()
            return ""

        before_text = get_status_text(before)
        after_text = get_status_text(after)
        if before_text == after_text: return

        for entry in entries:
            role = after.guild.get_role(entry["role_id"])
            if not role: continue
            if entry["text"] in after_text:
                if role not in after.roles:
                    try: await after.add_roles(role, reason="Zephyr — Status Role")
                    except discord.HTTPException: pass
            else:
                if role in after.roles:
                    try: await after.remove_roles(role, reason="Zephyr — Status Role")
                    except discord.HTTPException: pass

async def setup(bot):
    await bot.add_cog(AutomationCog(bot))
    log.info("  ✓ AutomationCog loaded")
