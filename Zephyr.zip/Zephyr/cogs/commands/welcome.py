"""
Welcome / Greeter System — Fully Customizable
Advanced welcome system with embed builder, placeholders, images, and flexible options.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Optional

import aiosqlite
import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.welcome")


def replace_placeholders(text: str, member: discord.Member) -> str:
    """Replace template placeholders with actual values."""
    guild = member.guild
    created_at = int(member.created_at.timestamp())
    joined_at = int(member.joined_at.timestamp()) if member.joined_at else 0
    
    return (
        text.replace("{user}", str(member))
        .replace("{user.mention}", member.mention)
        .replace("{user.name}", member.name)
        .replace("{user.display}", member.display_name)
        .replace("{user.id}", str(member.id))
        .replace("{user.tag}", f"{member.name}#{member.discriminator}" if member.discriminator != "0" else member.name)
        .replace("{user.avatar}", member.display_avatar.url)
        .replace("{user.created}", f"<t:{created_at}:R>")
        .replace("{server}", guild.name)
        .replace("{server.name}", guild.name)
        .replace("{server.id}", str(guild.id))
        .replace("{server.count}", str(guild.member_count or 0))
        .replace("{server.members}", str(guild.member_count or 0))
        .replace("{member.count}", str(guild.member_count or 0))
        .replace("{joined.at}", f"<t:{joined_at}:F>")
    )


class WelcomeConfigModal(discord.ui.Modal, title="Welcome Message Configuration"):
    """Modal for configuring welcome message content."""
    
    message_content = discord.ui.TextInput(
        label="Message Content (Optional)",
        placeholder="Welcome {user.mention} to {server}! You are member #{member.count}",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=2000,
    )
    
    embed_title = discord.ui.TextInput(
        label="Embed Title (Optional)",
        placeholder="Welcome to {server}!",
        style=discord.TextStyle.short,
        required=False,
        max_length=256,
    )
    
    embed_description = discord.ui.TextInput(
        label="Embed Description (Optional)",
        placeholder="Hey {user.mention}! Welcome to our server!\nYou are member #{member.count}",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=4000,
    )
    
    embed_color = discord.ui.TextInput(
        label="Embed Color (Hex, e.g., #5865F2)",
        placeholder="#5865F2",
        style=discord.TextStyle.short,
        required=False,
        max_length=7,
    )
    
    embed_footer = discord.ui.TextInput(
        label="Embed Footer (Optional)",
        placeholder="Member #{member.count} • Joined {joined.at}",
        style=discord.TextStyle.short,
        required=False,
        max_length=2048,
    )
    
    def __init__(self, cog: WelcomeCog, channel: discord.TextChannel):
        super().__init__()
        self.cog = cog
        self.channel = channel
    
    async def on_submit(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return
        
        # Build config
        config = {
            "channel_id": self.channel.id,
            "message_content": self.message_content.value or None,
            "embed": {
                "enabled": bool(self.embed_title.value or self.embed_description.value),
                "title": self.embed_title.value or None,
                "description": self.embed_description.value or None,
                "color": self.embed_color.value or "#5865F2",
                "footer": self.embed_footer.value or None,
                "thumbnail": None,  # Set via separate command
                "image": None,  # Set via separate command
            }
        }
        
        # Save to database
        async with aiosqlite.connect("db/welcome.db") as db:
            await db.execute(
                """INSERT INTO welcome (guild_id, channel_id, message, enabled, welcome_type, embed_data) 
                   VALUES (?, ?, ?, 1, 'custom', ?) 
                   ON CONFLICT(guild_id) DO UPDATE SET 
                   channel_id = ?, message = ?, enabled = 1, welcome_type = 'custom', embed_data = ?""",
                (guild.id, self.channel.id, self.message_content.value or "", json.dumps(config), 
                 self.channel.id, self.message_content.value or "", json.dumps(config)),
            )
            await db.commit()
        
        em = create_embed(
            description=(
                f"## {EMOJIS['success']} Welcome Message Configured!\n"
                f"{EMOJIS['channel']} **Channel:** {self.channel.mention}\n"
                f"{EMOJIS['edit']} **Type:** Custom {'Embed' if config['embed']['enabled'] else 'Message'}\n\n"
                f"**Available Placeholders:**\n"
                f"`{{user}}` `{{user.mention}}` `{{user.name}}` `{{user.display}}`\n"
                f"`{{user.id}}` `{{user.tag}}` `{{user.avatar}}` `{{user.created}}`\n"
                f"`{{server}}` `{{server.name}}` `{{server.id}}` `{{member.count}}`\n"
                f"`{{joined.at}}`\n\n"
                f"-# Use `/greet test` to preview • `/greet image` to add images"
            ),
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)


class WelcomeCog(commands.Cog):
    """Advanced Welcome/Greeter system for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    greet = app_commands.Group(name="greet", description="Welcome/Greeter configuration")

    @greet.command(name="setup", description="Setup welcome messages with full customization")
    @app_commands.describe(channel="Channel to send welcome messages in")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_setup(self, interaction: discord.Interaction, channel: discord.TextChannel):
        """Open interactive welcome message builder."""
        modal = WelcomeConfigModal(self, channel)
        await interaction.response.send_modal(modal)

    @greet.command(name="quick", description="Quick setup with a simple message")
    @app_commands.describe(
        channel="Channel to send welcome messages in",
        message="Welcome message (use placeholders like {user.mention}, {server}, {member.count})",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_quick(self, interaction: discord.Interaction, channel: discord.TextChannel, message: str):
        """Quick setup for simple welcome messages."""
        guild = interaction.guild
        if not guild:
            return

        config = {
            "channel_id": channel.id,
            "message_content": message,
            "embed": {"enabled": False}
        }

        async with aiosqlite.connect("db/welcome.db") as db:
            await db.execute(
                """INSERT INTO welcome (guild_id, channel_id, message, enabled, welcome_type, embed_data) 
                   VALUES (?, ?, ?, 1, 'simple', ?) 
                   ON CONFLICT(guild_id) DO UPDATE SET 
                   channel_id = ?, message = ?, enabled = 1, welcome_type = 'simple', embed_data = ?""",
                (guild.id, channel.id, message, json.dumps(config), 
                 channel.id, message, json.dumps(config)),
            )
            await db.commit()

        em = create_embed(
            description=(
                f"## {EMOJIS['success']} Quick Welcome Set!\n"
                f"{EMOJIS['channel']} **Channel:** {channel.mention}\n"
                f"{EMOJIS['edit']} **Message:** {message}\n\n"
                f"-# Use `/greet test` to preview"
            ),
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)

    @greet.command(name="image", description="Set welcome embed thumbnail or image")
    @app_commands.describe(
        image_type="Type of image to set",
        url="Image URL (or use 'avatar' for user's avatar, 'banner' for server banner)",
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_image(
        self, 
        interaction: discord.Interaction, 
        image_type: str,
        url: str
    ):
        """Set thumbnail or image for welcome embed."""
        guild = interaction.guild
        if not guild:
            return

        # Get current config
        async with aiosqlite.connect("db/welcome.db") as db:
            async with db.execute(
                "SELECT embed_data FROM welcome WHERE guild_id = ?", (guild.id,)
            ) as cur:
                row = await cur.fetchone()
        
        if not row or not row[0]:
            return await interaction.response.send_message(
                embed=create_embed(
                    description=f"{EMOJIS['error']} Please setup welcome messages first using `/greet setup`",
                    color=COLORS["error"]
                ),
                ephemeral=True
            )
        
        config = json.loads(row[0])
        
        # Update image
        if image_type == "thumbnail":
            config["embed"]["thumbnail"] = url
        else:
            config["embed"]["image"] = url
        
        # Save
        async with aiosqlite.connect("db/welcome.db") as db:
            await db.execute(
                "UPDATE welcome SET embed_data = ? WHERE guild_id = ?",
                (json.dumps(config), guild.id)
            )
            await db.commit()
        
        em = create_embed(
            description=(
                f"## {EMOJIS['success']} Image Updated!\n"
                f"**Type:** {image_type.name}\n"
                f"**URL:** {url}\n\n"
                f"-# Use `/greet test` to preview"
            ),
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)

    @greet_image.autocomplete("image_type")
    async def image_type_autocomplete(
        self, interaction: discord.Interaction, current: str
    ) -> list[app_commands.Choice[str]]:
        choices = [
            app_commands.Choice(name="Thumbnail (small image in corner)", value="thumbnail"),
            app_commands.Choice(name="Image (large image at bottom)", value="image"),
        ]
        return choices

    @greet.command(name="autodelete", description="Auto-delete welcome messages after X seconds")
    @app_commands.describe(seconds="Seconds before deletion (0 to disable, max 300)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_autodelete(self, interaction: discord.Interaction, seconds: int):
        """Set auto-delete timer for welcome messages."""
        guild = interaction.guild
        if not guild:
            return
        
        if seconds < 0 or seconds > 300:
            return await interaction.response.send_message(
                embed=create_embed(
                    description=f"{EMOJIS['error']} Seconds must be between 0-300",
                    color=COLORS["error"]
                ),
                ephemeral=True
            )
        
        async with aiosqlite.connect("db/welcome.db") as db:
            await db.execute(
                "UPDATE welcome SET auto_delete_duration = ? WHERE guild_id = ?",
                (seconds, guild.id)
            )
            await db.commit()
        
        if seconds == 0:
            msg = "Auto-delete **disabled**"
        else:
            msg = f"Welcome messages will be deleted after **{seconds}** seconds"
        
        em = create_embed(
            description=f"## {EMOJIS['success']} Auto-Delete Updated\n{msg}",
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)

    @greet.command(name="disable", description="Disable welcome messages")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_disable(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/welcome.db") as db:
            await db.execute(
                "UPDATE welcome SET enabled = 0 WHERE guild_id = ?", (guild.id,)
            )
            await db.commit()

        em = create_embed(
            description=f"## {EMOJIS['success']} Greeter Disabled\nWelcome messages have been **disabled** for this server",
            color=COLORS["warning"],
        )
        await interaction.response.send_message(embed=em)

    @greet.command(name="enable", description="Enable welcome messages")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_enable(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/welcome.db") as db:
            await db.execute(
                "UPDATE welcome SET enabled = 1 WHERE guild_id = ?", (guild.id,)
            )
            await db.commit()

        em = create_embed(
            description=f"## {EMOJIS['success']} Greeter Enabled\nWelcome messages have been **enabled** for this server",
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)

    @greet.command(name="test", description="Preview the welcome message")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_test(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild or not isinstance(interaction.user, discord.Member):
            return

        async with aiosqlite.connect("db/welcome.db") as db:
            async with db.execute(
                "SELECT channel_id, message, embed_data, auto_delete_duration FROM welcome WHERE guild_id = ?",
                (guild.id,),
            ) as cur:
                row = await cur.fetchone()

        if not row:
            return await interaction.response.send_message(
                embed=create_embed(
                    description=f"{EMOJIS['error']} No welcome message configured. Use `/greet setup` or `/greet quick`",
                    color=COLORS["error"]
                ),
                ephemeral=True,
            )

        ch_id, msg_template, embed_data_str, auto_delete = row
        
        # Parse config
        config = json.loads(embed_data_str) if embed_data_str else {"message_content": msg_template, "embed": {"enabled": False}}
        
        # Build message
        content = None
        embed = None
        
        if config.get("message_content"):
            content = replace_placeholders(config["message_content"], interaction.user)
        
        if config.get("embed", {}).get("enabled"):
            embed_config = config["embed"]
            
            # Parse color
            color_hex = embed_config.get("color", "#5865F2")
            try:
                if color_hex.startswith("#"):
                    color = int(color_hex[1:], 16)
                else:
                    color = int(color_hex, 16)
            except:
                color = COLORS["primary"]
            
            # Build embed
            embed = discord.Embed(color=color)
            
            if embed_config.get("title"):
                embed.title = replace_placeholders(embed_config["title"], interaction.user)
            
            if embed_config.get("description"):
                embed.description = replace_placeholders(embed_config["description"], interaction.user)
            
            if embed_config.get("footer"):
                embed.set_footer(text=replace_placeholders(embed_config["footer"], interaction.user))
            
            # Handle images
            thumbnail_url = embed_config.get("thumbnail")
            if thumbnail_url:
                if thumbnail_url.lower() == "avatar":
                    embed.set_thumbnail(url=interaction.user.display_avatar.url)
                elif thumbnail_url.lower() == "banner" and guild.banner:
                    embed.set_thumbnail(url=guild.banner.url)
                else:
                    embed.set_thumbnail(url=thumbnail_url)
            
            image_url = embed_config.get("image")
            if image_url:
                if image_url.lower() == "avatar":
                    embed.set_image(url=interaction.user.display_avatar.url)
                elif image_url.lower() == "banner" and guild.banner:
                    embed.set_image(url=guild.banner.url)
                else:
                    embed.set_image(url=image_url)
        
        # Send preview
        preview_embed = create_embed(
            description=f"## {EMOJIS['a_wave']} Welcome Preview\n-# This is how your welcome message will look:",
            color=COLORS["info"],
        )
        
        await interaction.response.send_message(embed=preview_embed, ephemeral=True)
        await interaction.followup.send(content=content, embed=embed, ephemeral=True)

    @greet.command(name="config", description="View current welcome configuration")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def greet_config(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/welcome.db") as db:
            async with db.execute(
                "SELECT channel_id, enabled, welcome_type, embed_data, auto_delete_duration FROM welcome WHERE guild_id = ?",
                (guild.id,),
            ) as cur:
                row = await cur.fetchone()

        if not row:
            return await interaction.response.send_message(
                embed=create_embed(
                    description=f"{EMOJIS['info']} No welcome configuration found.\nUse `/greet setup` to get started!",
                    color=COLORS["info"]
                ),
                ephemeral=True,
            )

        ch_id, enabled, welcome_type, embed_data_str, auto_delete = row
        channel = guild.get_channel(ch_id)
        
        config = json.loads(embed_data_str) if embed_data_str else {}
        
        status = f"{EMOJIS['success']} Enabled" if enabled else f"{EMOJIS['error']} Disabled"
        channel_text = channel.mention if channel else f"{EMOJIS['error']} Channel not found (ID: {ch_id})"
        auto_delete_text = f"{auto_delete}s" if auto_delete else "Disabled"
        
        has_content = bool(config.get("message_content"))
        has_embed = config.get("embed", {}).get("enabled", False)
        
        em = create_embed(
            description=(
                f"## {EMOJIS['settings']} Welcome Configuration\n\n"
                f"**Status:** {status}\n"
                f"**Channel:** {channel_text}\n"
                f"**Type:** {welcome_type or 'simple'}\n"
                f"**Auto-Delete:** {auto_delete_text}\n\n"
                f"**Components:**\n"
                f"{EMOJIS['success'] if has_content else EMOJIS['error']} Message Content\n"
                f"{EMOJIS['success'] if has_embed else EMOJIS['error']} Embed\n\n"
                f"-# Use `/greet test` to preview"
            ),
            color=COLORS["primary"],
        )
        await interaction.response.send_message(embed=em, ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Send welcome message when a new member joins."""
        guild = member.guild

        async with aiosqlite.connect("db/welcome.db") as db:
            async with db.execute(
                "SELECT channel_id, message, embed_data, enabled, auto_delete_duration FROM welcome WHERE guild_id = ?",
                (guild.id,),
            ) as cur:
                row = await cur.fetchone()

        if not row or not row[3]:  # Check if enabled
            return

        ch_id, msg_template, embed_data_str, enabled, auto_delete = row
        channel = guild.get_channel(ch_id)
        if not channel or not isinstance(channel, discord.TextChannel):
            return

        # Parse config
        config = json.loads(embed_data_str) if embed_data_str else {"message_content": msg_template, "embed": {"enabled": False}}
        
        # Build message
        content = None
        embed = None
        
        if config.get("message_content"):
            content = replace_placeholders(config["message_content"], member)
        
        if config.get("embed", {}).get("enabled"):
            embed_config = config["embed"]
            
            # Parse color
            color_hex = embed_config.get("color", "#5865F2")
            try:
                if color_hex.startswith("#"):
                    color = int(color_hex[1:], 16)
                else:
                    color = int(color_hex, 16)
            except:
                color = COLORS["primary"]
            
            # Build embed
            embed = discord.Embed(color=color)
            
            if embed_config.get("title"):
                embed.title = replace_placeholders(embed_config["title"], member)
            
            if embed_config.get("description"):
                embed.description = replace_placeholders(embed_config["description"], member)
            
            if embed_config.get("footer"):
                embed.set_footer(text=replace_placeholders(embed_config["footer"], member))
            
            # Handle images
            thumbnail_url = embed_config.get("thumbnail")
            if thumbnail_url:
                if thumbnail_url.lower() == "avatar":
                    embed.set_thumbnail(url=member.display_avatar.url)
                elif thumbnail_url.lower() == "banner" and guild.banner:
                    embed.set_thumbnail(url=guild.banner.url)
                else:
                    embed.set_thumbnail(url=thumbnail_url)
            
            image_url = embed_config.get("image")
            if image_url:
                if image_url.lower() == "avatar":
                    embed.set_image(url=member.display_avatar.url)
                elif image_url.lower() == "banner" and guild.banner:
                    embed.set_image(url=guild.banner.url)
                else:
                    embed.set_image(url=image_url)

        try:
            msg = await channel.send(content=content, embed=embed)
            
            # Auto-delete if configured
            if auto_delete and auto_delete > 0:
                await msg.delete(delay=auto_delete)
        except discord.HTTPException as e:
            log.error(f"Failed to send welcome message in {guild.name}: {e}")


async def setup(bot: Zephyr):
    await bot.add_cog(WelcomeCog(bot))
    log.info("  ✓ WelcomeCog loaded")
