"""
Configuration — /autorole, /ignore, /autoreact
Server configuration management.
"""
from __future__ import annotations
import logging
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.config")

class ConfigCog(commands.Cog):
    def __init__(self, bot: Zephyr):
        self.bot = bot

    autorole = app_commands.Group(name="autorole", description="Auto role assignment")

    @autorole.command(name="human", description="Auto-assign role to new humans")
    @app_commands.describe(role="Role to assign")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def autorole_human(self, it: discord.Interaction, role: discord.Role):
        async with aiosqlite.connect("db/autorole.db") as db:
            await db.execute("INSERT INTO autorole(guild_id,type,role_id) VALUES(?,?,?) ON CONFLICT(guild_id,type) DO UPDATE SET role_id=?",(it.guild.id,"human",role.id,role.id))
            await db.commit()
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['success']} Autorole Set\n👤 New **humans** will receive {role.mention}",color=COLORS["success"]))

    @autorole.command(name="bot", description="Auto-assign role to new bots")
    @app_commands.describe(role="Role to assign")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def autorole_bot(self, it: discord.Interaction, role: discord.Role):
        async with aiosqlite.connect("db/autorole.db") as db:
            await db.execute("INSERT INTO autorole(guild_id,type,role_id) VALUES(?,?,?) ON CONFLICT(guild_id,type) DO UPDATE SET role_id=?",(it.guild.id,"bot",role.id,role.id))
            await db.commit()
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['success']} Autorole Set\n🤖 New **bots** will receive {role.mention}",color=COLORS["success"]))

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        t = "bot" if member.bot else "human"
        async with aiosqlite.connect("db/autorole.db") as db:
            async with db.execute("SELECT role_id FROM autorole WHERE guild_id=? AND type=?",(member.guild.id,t)) as c:
                row = await c.fetchone()
        if row:
            role = member.guild.get_role(row[0])
            if role:
                try: await member.add_roles(role, reason="Zephyr Autorole")
                except discord.HTTPException: pass

    ignore_group = app_commands.Group(name="ignore", description="Ignore channels/users")

    @ignore_group.command(name="channel", description="Ignore a channel")
    @app_commands.describe(channel="Channel to ignore")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ignore_ch(self, it: discord.Interaction, channel: discord.TextChannel):
        async with aiosqlite.connect("db/ignore.db") as db:
            await db.execute("INSERT OR IGNORE INTO ignore_channels(guild_id,channel_id) VALUES(?,?)",(it.guild.id,channel.id))
            await db.commit()
        self.bot.cache["ignore_channels"].setdefault(it.guild.id,set()).add(channel.id)
        await it.response.send_message(embed=create_embed(description=f"## 🔇 Channel Ignored\n{EMOJIS['success']} {channel.mention} is now **ignored** by Zephyr\n-# Commands will not work in this channel",color=COLORS["success"]))

    @ignore_group.command(name="user", description="Ignore a user")
    @app_commands.describe(user="User to ignore")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ignore_usr(self, it: discord.Interaction, user: discord.Member):
        async with aiosqlite.connect("db/ignore.db") as db:
            await db.execute("INSERT OR IGNORE INTO ignore_users(guild_id,user_id) VALUES(?,?)",(it.guild.id,user.id))
            await db.commit()
        self.bot.cache["ignore_users"].setdefault(it.guild.id,set()).add(user.id)
        await it.response.send_message(embed=create_embed(description=f"## 🔇 User Ignored\n{EMOJIS['success']} {user.mention} is now **ignored** by Zephyr\n-# This user cannot use commands",color=COLORS["success"]))

    @app_commands.command(name="autoreact", description="Set auto-reactions for a channel")
    @app_commands.describe(channel="Channel", emojis="Space-separated emojis (max 5)")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def autoreact(self, it: discord.Interaction, channel: discord.TextChannel, emojis: str):
        elist = emojis.strip().split()[:5]
        async with aiosqlite.connect("db/autoreact.db") as db:
            await db.execute("DELETE FROM autoreact WHERE guild_id=? AND channel_id=?",(it.guild.id,channel.id))
            for e in elist:
                await db.execute("INSERT INTO autoreact(guild_id,channel_id,emoji) VALUES(?,?,?)",(it.guild.id,channel.id,e))
            await db.commit()
        await it.response.send_message(embed=create_embed(description=f"## ✨ Auto-Reactions Set\n{EMOJIS['success']} Reactions for {channel.mention}:\n{' '.join(elist)}",color=COLORS["success"]))

    @commands.Cog.listener("on_message")
    async def autoreact_listener(self, msg: discord.Message):
        if msg.author.bot or not msg.guild: return
        async with aiosqlite.connect("db/autoreact.db") as db:
            async with db.execute("SELECT emoji FROM autoreact WHERE guild_id=? AND channel_id=?",(msg.guild.id,msg.channel.id)) as c:
                rows = await c.fetchall()
        for (e,) in rows:
            try: await msg.add_reaction(e)
            except discord.HTTPException: pass

async def setup(bot):
    await bot.add_cog(ConfigCog(bot))
    log.info("  ✓ ConfigCog loaded")
