"""
Moderation — /warn, /clearwarns, /nuke, /lockall, /unlockall, /hideall, /unhideall, /prefix
Standard server moderation tools.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import aiosqlite
import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS
from utils.Tools import blacklist_check, ignore_check, create_embed, is_admin

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.moderation")


class ModerationCog(commands.Cog):
    """Standard moderation commands for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(user="User to ban", reason="Reason for ban", delete_days="Days of messages to delete (0-7)")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban_cmd(self, interaction: discord.Interaction, user: discord.Member, reason: str = "No reason provided", delete_days: int = 0):
        if delete_days < 0 or delete_days > 7:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Delete days must be between 0-7.", color=COLORS["error"]),
                ephemeral=True
            )
        try:
            await user.ban(reason=f"Zephyr — {reason}", delete_message_seconds=delete_days * 86400)
            em = create_embed(
                description=(
                    f"## {EMOJIS['ban_hammer']} User Banned\n"
                    f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                    f"{EMOJIS['info']} **Reason:** `{reason}`\n"
                    f"-# Moderator: {interaction.user.mention}"
                ),
                color=COLORS["mod"],
            )
            await interaction.response.send_message(embed=em)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to ban this user.", color=COLORS["error"]),
                ephemeral=True
            )

    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.describe(user="User to kick", reason="Reason for kick")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick_cmd(self, interaction: discord.Interaction, user: discord.Member, reason: str = "No reason provided"):
        try:
            await user.kick(reason=f"Zephyr — {reason}")
            em = create_embed(
                description=(
                    f"## {EMOJIS['kick']} User Kicked\n"
                    f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                    f"{EMOJIS['info']} **Reason:** `{reason}`\n"
                    f"-# Moderator: {interaction.user.mention}"
                ),
                color=COLORS["mod"],
            )
            await interaction.response.send_message(embed=em)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to kick this user.", color=COLORS["error"]),
                ephemeral=True
            )

    @app_commands.command(name="timeout", description="Timeout a member")
    @app_commands.describe(user="User to timeout", duration="Duration (e.g. 10m, 1h, 1d) or minutes", reason="Reason for timeout")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def timeout_cmd(self, interaction: discord.Interaction, user: discord.Member, duration: str, reason: str = "No reason provided"):
        from utils.Tools import parse_duration, format_duration
        
        parsed_sec = parse_duration(duration)
        if parsed_sec is not None:
            seconds = parsed_sec
        else:
            try:
                seconds = int(duration) * 60
            except ValueError:
                return await interaction.response.send_message(
                    embed=create_embed(description=f"{EMOJIS['error']} Invalid duration format. Try `10m`, `1h`, or just a number for minutes.", color=COLORS["error"]),
                    ephemeral=True
                )

        if seconds < 1 or seconds > 2419200:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Duration must be between 1 second and 28 days.", color=COLORS["error"]),
                ephemeral=True
            )
            
        try:
            import datetime
            await user.timeout(datetime.timedelta(seconds=seconds), reason=f"Zephyr — {reason}")
            em = create_embed(
                description=(
                    f"## {EMOJIS['timeout']} User Timed Out\n"
                    f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                    f"⏱️ **Duration:** `{format_duration(seconds)}`\n"
                    f"{EMOJIS['info']} **Reason:** `{reason}`\n"
                    f"-# Moderator: {interaction.user.mention}"
                ),
                color=COLORS["mod"],
            )
            await interaction.response.send_message(embed=em)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to timeout this user.", color=COLORS["error"]),
                ephemeral=True
            )

    @app_commands.command(name="untimeout", description="Remove timeout from a member")
    @app_commands.describe(user="User to remove timeout from")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def untimeout_cmd(self, interaction: discord.Interaction, user: discord.Member):
        try:
            await user.timeout(None, reason="Zephyr — Timeout removed")
            em = create_embed(
                description=f"## {EMOJIS['success']} Timeout Removed\n{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n-# Moderator: {interaction.user.mention}",
                color=COLORS["success"],
            )
            await interaction.response.send_message(embed=em)
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to remove timeout.", color=COLORS["error"]),
                ephemeral=True
            )

    @app_commands.command(name="purge", description="Delete multiple messages")
    @app_commands.describe(amount="Number of messages to delete (1-100)")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def purge_cmd(self, interaction: discord.Interaction, amount: int):
        if amount < 1 or amount > 100:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Amount must be between 1-100.", color=COLORS["error"]),
                ephemeral=True
            )
        await interaction.response.defer(ephemeral=True)
        try:
            deleted = await interaction.channel.purge(limit=amount)
            em = create_embed(
                description=f"## {EMOJIS['purge']} Messages Purged\n🗑️ Deleted **`{len(deleted)}`** message(s) from {interaction.channel.mention}\n-# Moderator: {interaction.user.mention}",
                color=COLORS["mod"],
            )
            await interaction.followup.send(embed=em, ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send(
                embed=create_embed(description=f"{EMOJIS['error']} I don't have permission to delete messages.", color=COLORS["error"]),
                ephemeral=True
            )

    @app_commands.command(name="unban", description="Unban a user from the server")
    @app_commands.describe(user_id="User ID to unban")
    @app_commands.checks.has_permissions(ban_members=True)
    async def unban_cmd(self, interaction: discord.Interaction, user_id: str):
        try:
            user_id_int = int(user_id)
            user = await self.bot.fetch_user(user_id_int)
            await interaction.guild.unban(user, reason="Zephyr — Unbanned")
            em = create_embed(
                description=f"## {EMOJIS['unban']} User Unbanned\n{EMOJIS['member']} **User:** `{user.name}` (`{user.id}`)\n-# Moderator: {interaction.user.mention}",
                color=COLORS["success"],
            )
            await interaction.response.send_message(embed=em)
        except ValueError:
            await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Invalid user ID.", color=COLORS["error"]),
                ephemeral=True
            )
        except discord.NotFound:
            await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} User not found or not banned.", color=COLORS["error"]),
                ephemeral=True
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} I don't have permission to unban users.", color=COLORS["error"]),
                ephemeral=True
            )

    @app_commands.command(name="warn", description="Warn a user")
    @app_commands.describe(user="User to warn", reason="Reason for warning")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn_cmd(self, interaction: discord.Interaction, user: discord.Member, reason: str = "No reason provided"):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/warn.db") as db:
            async with db.execute(
                "SELECT warns FROM warns WHERE guild_id = ? AND user_id = ?",
                (guild.id, user.id),
            ) as cur:
                row = await cur.fetchone()
                current = row[0] if row else 0

            new_count = current + 1
            await db.execute(
                "INSERT INTO warns (guild_id, user_id, warns) VALUES (?, ?, ?) ON CONFLICT(guild_id, user_id) DO UPDATE SET warns = ?",
                (guild.id, user.id, new_count, new_count),
            )
            await db.commit()

        # DM the user
        try:
            dm_em = create_embed(
                description=f"## {EMOJIS['warn']} Warning Received\n{EMOJIS['info']} You have been warned in **{guild.name}**\n📝 **Reason:** `{reason}`\n⚠️ **Total Warnings:** `{new_count}`",
                color=COLORS["warning"],
            )
            await user.send(embed=dm_em)
        except discord.HTTPException:
            pass

        em = create_embed(
            description=(
                f"## {EMOJIS['warn']} User Warned\n"
                f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                f"📝 **Reason:** `{reason}`\n"
                f"⚠️ **Total Warnings:** `{new_count}`\n"
                f"-# Moderator: {interaction.user.mention}"
            ),
            color=COLORS["warning"],
        )
        await interaction.response.send_message(embed=em)


    @app_commands.command(name="clearwarns", description="Clear all warnings for a user")
    @app_commands.describe(user="User to clear warnings for")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def clearwarns_cmd(self, interaction: discord.Interaction, user: discord.Member):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/warn.db") as db:
            await db.execute("DELETE FROM warns WHERE guild_id = ? AND user_id = ?", (guild.id, user.id))
            await db.commit()

        em = create_embed(
            description=f"## {EMOJIS['success']} Warnings Cleared\n{EMOJIS['member']} Cleared **all** warnings for {user.mention}\n-# Moderator: {interaction.user.mention}",
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)

    @app_commands.command(name="nuke", description="Nuke (clone + delete) the current channel")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def nuke_cmd(self, interaction: discord.Interaction):
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel):
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Can only nuke text channels.", color=COLORS["error"]),
                ephemeral=True,
            )

        await interaction.response.defer(ephemeral=True)

        try:
            new_channel = await channel.clone(reason="Zephyr — Channel nuked")
            await new_channel.edit(position=channel.position)
            await channel.delete(reason="Zephyr — Channel nuked")

            em = create_embed(
                description=f"## {EMOJIS['nuke']} Channel Nuked\n{EMOJIS['success']} This channel has been **nuked** by {interaction.user.mention}\n-# All previous messages have been wiped",
                color=COLORS["mod"],
            )
            await new_channel.send(embed=em)
        except discord.HTTPException as e:
            log.error(f"Nuke failed: {e}")

    @app_commands.command(name="lockall", description="Lock all channels in the server")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def lockall_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return

        locked = 0
        for channel in guild.text_channels:
            try:
                await channel.set_permissions(
                    guild.default_role, send_messages=False,
                    reason="Zephyr — Lockall",
                )
                locked += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass

        em = create_embed(
            description=f"## {EMOJIS['lock']} Server Locked\n🔒 Locked **`{locked}`** channel(s)\n-# Moderator: {interaction.user.mention}",
            color=COLORS["mod"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    @app_commands.command(name="unlockall", description="Unlock all channels in the server")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def unlockall_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return

        unlocked = 0
        for channel in guild.text_channels:
            try:
                await channel.set_permissions(
                    guild.default_role, send_messages=True,
                    reason="Zephyr — Unlockall",
                )
                unlocked += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass

        em = create_embed(
            description=f"## {EMOJIS['unlock']} Server Unlocked\n🔓 Unlocked **`{unlocked}`** channel(s)\n-# Moderator: {interaction.user.mention}",
            color=COLORS["success"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    @app_commands.command(name="hideall", description="Hide all channels in the server")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def hideall_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return

        hidden = 0
        for channel in guild.channels:
            try:
                await channel.set_permissions(guild.default_role, view_channel=False, reason="Zephyr — Hideall")
                hidden += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass

        em = create_embed(
            description=f"## 👁️ Channels Hidden\n{EMOJIS['success']} Hidden **`{hidden}`** channel(s)\n-# Moderator: {interaction.user.mention}",
            color=COLORS["mod"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    @app_commands.command(name="unhideall", description="Unhide all channels in the server")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def unhideall_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return

        shown = 0
        for channel in guild.channels:
            try:
                await channel.set_permissions(guild.default_role, view_channel=True, reason="Zephyr — Unhideall")
                shown += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass

        em = create_embed(
            description=f"## 👁️ Channels Revealed\n{EMOJIS['success']} Revealed **`{shown}`** channel(s)\n-# Moderator: {interaction.user.mention}",
            color=COLORS["success"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    @app_commands.command(name="prefix", description="Change the bot's command prefix for this server")
    @app_commands.describe(new_prefix="New prefix (max 5 chars)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def prefix_cmd(self, interaction: discord.Interaction, new_prefix: str):
        guild = interaction.guild
        if not guild:
            return

        if len(new_prefix) > 5:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Prefix must be 5 characters or less.", color=COLORS["error"]),
                ephemeral=True,
            )

        async with aiosqlite.connect("db/prefix.db") as db:
            await db.execute(
                "INSERT INTO prefixes (guild_id, prefix) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET prefix = ?",
                (guild.id, new_prefix, new_prefix),
            )
            await db.commit()

        self.bot.cache["prefixes"][guild.id] = new_prefix

        em = create_embed(
            description=f"## {EMOJIS['settings']} Prefix Updated\n{EMOJIS['success']} Server prefix changed to `{new_prefix}`\n-# Use `{new_prefix}help` to see commands",
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)


    # ═══════════════════════════════════════════════════════════
    #  PREFIX COMMAND ALIASES
    # ═══════════════════════════════════════════════════════════

    @commands.command(name="ban", aliases=["b"])
    @commands.has_permissions(ban_members=True)
    async def ban_prefix(self, ctx: commands.Context, user: discord.Member, *, reason: str = "No reason provided"):
        try:
            await user.ban(reason=f"Zephyr — {reason}", delete_message_seconds=0)
            em = create_embed(
                description=(
                    f"## {EMOJIS['ban_hammer']} User Banned\n"
                    f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                    f"{EMOJIS['info']} **Reason:** `{reason}`\n"
                    f"-# Moderator: {ctx.author.mention}"
                ),
                color=COLORS["mod"],
            )
            await ctx.send(embed=em)
        except discord.Forbidden:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to ban this user.", color=COLORS["error"]))

    @commands.command(name="kick", aliases=["k"])
    @commands.has_permissions(kick_members=True)
    async def kick_prefix(self, ctx: commands.Context, user: discord.Member, *, reason: str = "No reason provided"):
        try:
            await user.kick(reason=f"Zephyr — {reason}")
            em = create_embed(
                description=(
                    f"## {EMOJIS['kick']} User Kicked\n"
                    f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                    f"{EMOJIS['info']} **Reason:** `{reason}`\n"
                    f"-# Moderator: {ctx.author.mention}"
                ),
                color=COLORS["mod"],
            )
            await ctx.send(embed=em)
        except discord.Forbidden:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to kick this user.", color=COLORS["error"]))

    @commands.command(name="timeout", aliases=["to", "mute"])
    @commands.has_permissions(moderate_members=True)
    async def timeout_prefix(self, ctx: commands.Context, user: discord.Member, duration: str, *, reason: str = "No reason provided"):
        from utils.Tools import parse_duration, format_duration
        
        parsed_sec = parse_duration(duration)
        if parsed_sec is not None:
            seconds = parsed_sec
        else:
            try:
                seconds = int(duration) * 60
            except ValueError:
                return await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} Invalid duration format. Try `10m`, `1h`, or just a number for minutes.", color=COLORS["error"]))

        if seconds < 1 or seconds > 2419200:
            return await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} Duration must be between `1` second and `28` days.", color=COLORS["error"]))
            
        try:
            import datetime
            await user.timeout(datetime.timedelta(seconds=seconds), reason=f"Zephyr — {reason}")
            em = create_embed(
                description=(
                    f"## {EMOJIS['timeout']} User Timed Out\n"
                    f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                    f"⏱️ **Duration:** `{format_duration(seconds)}`\n"
                    f"{EMOJIS['info']} **Reason:** `{reason}`\n"
                    f"-# Moderator: {ctx.author.mention}"
                ),
                color=COLORS["mod"],
            )
            await ctx.send(embed=em)
        except discord.Forbidden:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to timeout this user.", color=COLORS["error"]))

    @commands.command(name="untimeout", aliases=["uto", "unmute"])
    @commands.has_permissions(moderate_members=True)
    async def untimeout_prefix(self, ctx: commands.Context, user: discord.Member):
        try:
            await user.timeout(None, reason="Zephyr — Timeout removed")
            em = create_embed(
                description=f"## {EMOJIS['success']} Timeout Removed\n{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n-# Moderator: {ctx.author.mention}",
                color=COLORS["success"],
            )
            await ctx.send(embed=em)
        except discord.Forbidden:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to remove timeout.", color=COLORS["error"]))

    @commands.command(name="purge", aliases=["clear", "prune"])
    @commands.has_permissions(manage_messages=True)
    async def purge_prefix(self, ctx: commands.Context, amount: int):
        if amount < 1 or amount > 100:
            return await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} Amount must be between `1`-`100`.", color=COLORS["error"]))
        try:
            await ctx.message.delete()
            deleted = await ctx.channel.purge(limit=amount)
            em = create_embed(
                description=f"## {EMOJIS['purge']} Messages Purged\n🗑️ Deleted **`{len(deleted)}`** message(s) from {ctx.channel.mention}\n-# Moderator: {ctx.author.mention}",
                color=COLORS["mod"],
            )
            msg = await ctx.send(embed=em)
            import asyncio
            await asyncio.sleep(3)
            try:
                await msg.delete()
            except discord.HTTPException:
                pass
        except discord.Forbidden:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to delete messages.", color=COLORS["error"]))

    @commands.command(name="unban")
    @commands.has_permissions(ban_members=True)
    async def unban_prefix(self, ctx: commands.Context, user_id: str):
        try:
            user_id_int = int(user_id)
            user = await self.bot.fetch_user(user_id_int)
            await ctx.guild.unban(user, reason="Zephyr — Unbanned")
            em = create_embed(
                description=f"## {EMOJIS['unban']} User Unbanned\n{EMOJIS['member']} **User:** `{user.name}` (`{user.id}`)\n-# Moderator: {ctx.author.mention}",
                color=COLORS["success"],
            )
            await ctx.send(embed=em)
        except ValueError:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} Invalid user ID.", color=COLORS["error"]))
        except discord.NotFound:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} User not found or not banned.", color=COLORS["error"]))
        except discord.Forbidden:
            await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} I don't have **permission** to unban users.", color=COLORS["error"]))

    @commands.command(name="warn", aliases=["w"])
    @commands.has_permissions(moderate_members=True)
    async def warn_prefix(self, ctx: commands.Context, user: discord.Member, *, reason: str = "No reason provided"):
        guild = ctx.guild
        if not guild:
            return

        async with aiosqlite.connect("db/warn.db") as db:
            async with db.execute(
                "SELECT warns FROM warns WHERE guild_id = ? AND user_id = ?",
                (guild.id, user.id),
            ) as cur:
                row = await cur.fetchone()
                current = row[0] if row else 0

            new_count = current + 1
            await db.execute(
                "INSERT INTO warns (guild_id, user_id, warns) VALUES (?, ?, ?) ON CONFLICT(guild_id, user_id) DO UPDATE SET warns = ?",
                (guild.id, user.id, new_count, new_count),
            )
            await db.commit()

        try:
            dm_em = create_embed(
                description=f"## {EMOJIS['warn']} Warning Received\n{EMOJIS['info']} You have been warned in **{guild.name}**\n📝 **Reason:** `{reason}`\n⚠️ **Total Warnings:** `{new_count}`",
                color=COLORS["warning"],
            )
            await user.send(embed=dm_em)
        except discord.HTTPException:
            pass

        em = create_embed(
            description=(
                f"## {EMOJIS['warn']} User Warned\n"
                f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                f"📝 **Reason:** `{reason}`\n"
                f"⚠️ **Total Warnings:** `{new_count}`\n"
                f"-# Moderator: {ctx.author.mention}"
            ),
            color=COLORS["warning"],
        )
        await ctx.send(embed=em)

    @commands.command(name="clearwarns", aliases=["cw"])
    @commands.has_permissions(moderate_members=True)
    async def clearwarns_prefix(self, ctx: commands.Context, user: discord.Member):
        guild = ctx.guild
        if not guild:
            return
        async with aiosqlite.connect("db/warn.db") as db:
            await db.execute("DELETE FROM warns WHERE guild_id = ? AND user_id = ?", (guild.id, user.id))
            await db.commit()
        em = create_embed(
            description=f"## {EMOJIS['success']} Warnings Cleared\n{EMOJIS['member']} Cleared **all** warnings for {user.mention}\n-# Moderator: {ctx.author.mention}",
            color=COLORS["success"],
        )
        await ctx.send(embed=em)

    @commands.command(name="nuke")
    @commands.has_permissions(manage_channels=True)
    async def nuke_prefix(self, ctx: commands.Context):
        channel = ctx.channel
        if not isinstance(channel, discord.TextChannel):
            return await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} Can only nuke **text** channels.", color=COLORS["error"]))
        try:
            new_channel = await channel.clone(reason="Zephyr — Channel nuked")
            await new_channel.edit(position=channel.position)
            await channel.delete(reason="Zephyr — Channel nuked")
            em = create_embed(
                description=f"## {EMOJIS['nuke']} Channel Nuked\n{EMOJIS['success']} This channel has been **nuked** by {ctx.author.mention}\n-# All previous messages have been wiped",
                color=COLORS["mod"],
            )
            await new_channel.send(embed=em)
        except discord.HTTPException as e:
            log.error(f"Nuke failed: {e}")

    @commands.command(name="lockall")
    @commands.has_permissions(manage_channels=True)
    async def lockall_prefix(self, ctx: commands.Context):
        guild = ctx.guild
        if not guild:
            return
        locked = 0
        for channel in guild.text_channels:
            try:
                await channel.set_permissions(guild.default_role, send_messages=False, reason="Zephyr — Lockall")
                locked += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass
        em = create_embed(
            description=f"## {EMOJIS['lock']} Server Locked\n🔒 Locked **`{locked}`** channel(s)\n-# Moderator: {ctx.author.mention}",
            color=COLORS["mod"],
        )
        await ctx.send(embed=em)

    @commands.command(name="unlockall")
    @commands.has_permissions(manage_channels=True)
    async def unlockall_prefix(self, ctx: commands.Context):
        guild = ctx.guild
        if not guild:
            return
        unlocked = 0
        for channel in guild.text_channels:
            try:
                await channel.set_permissions(guild.default_role, send_messages=True, reason="Zephyr — Unlockall")
                unlocked += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass
        em = create_embed(
            description=f"## {EMOJIS['unlock']} Server Unlocked\n🔓 Unlocked **`{unlocked}`** channel(s)\n-# Moderator: {ctx.author.mention}",
            color=COLORS["success"],
        )
        await ctx.send(embed=em)

    @commands.command(name="hideall")
    @commands.has_permissions(manage_channels=True)
    async def hideall_prefix(self, ctx: commands.Context):
        guild = ctx.guild
        if not guild:
            return
        hidden = 0
        for channel in guild.channels:
            try:
                await channel.set_permissions(guild.default_role, view_channel=False, reason="Zephyr — Hideall")
                hidden += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass
        em = create_embed(
            description=f"## 👁️ Channels Hidden\n{EMOJIS['success']} Hidden **`{hidden}`** channel(s)\n-# Moderator: {ctx.author.mention}",
            color=COLORS["mod"],
        )
        await ctx.send(embed=em)

    @commands.command(name="unhideall")
    @commands.has_permissions(manage_channels=True)
    async def unhideall_prefix(self, ctx: commands.Context):
        guild = ctx.guild
        if not guild:
            return
        shown = 0
        for channel in guild.channels:
            try:
                await channel.set_permissions(guild.default_role, view_channel=True, reason="Zephyr — Unhideall")
                shown += 1
                await asyncio.sleep(0.5)  # Rate limit protection
            except discord.HTTPException:
                pass
        em = create_embed(
            description=f"## 👁️ Channels Revealed\n{EMOJIS['success']} Revealed **`{shown}`** channel(s)\n-# Moderator: {ctx.author.mention}",
            color=COLORS["success"],
        )
        await ctx.send(embed=em)

    @commands.command(name="prefix", aliases=["setprefix"])
    @commands.has_permissions(manage_guild=True)
    async def prefix_prefix(self, ctx: commands.Context, new_prefix: str):
        guild = ctx.guild
        if not guild:
            return
        if len(new_prefix) > 5:
            return await ctx.send(embed=create_embed(description=f"{EMOJIS['error']} Prefix must be **5 characters** or less.", color=COLORS["error"]))
        async with aiosqlite.connect("db/prefix.db") as db:
            await db.execute(
                "INSERT INTO prefixes (guild_id, prefix) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET prefix = ?",
                (guild.id, new_prefix, new_prefix),
            )
            await db.commit()
        self.bot.cache["prefixes"][guild.id] = new_prefix
        em = create_embed(
            description=f"## {EMOJIS['settings']} Prefix Updated\n{EMOJIS['success']} Server prefix changed to `{new_prefix}`\n-# Use `{new_prefix}help` to see commands",
            color=COLORS["success"],
        )
        await ctx.send(embed=em)


async def setup(bot: Zephyr):
    await bot.add_cog(ModerationCog(bot))
    log.info("  ✓ ModerationCog loaded")
