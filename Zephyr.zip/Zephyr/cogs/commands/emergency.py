"""
Emergency System — /emergency enable/disable/authorise/role, /emergencysituation, /emergencyrestore
Panic button for raids and rogue admin attacks.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

import aiosqlite
import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed, is_extra_owner
from utils.paginator import ConfirmView

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.emergency")

DANGEROUS_PERMS = [
    "administrator", "ban_members", "kick_members",
    "manage_channels", "manage_roles", "manage_guild",
]


class EmergencyCog(commands.Cog):
    """Emergency / Raid Mode system for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    emergency = app_commands.Group(name="emergency", description="Emergency system commands")

    @emergency.command(name="enable", description="Enable emergency mode and detect dangerous roles")
    @app_commands.checks.has_permissions(administrator=True)
    async def emg_enable(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        if not guild:
            return

        dangerous_roles = []
        for role in guild.roles:
            if role.is_default() or role.managed:
                continue
            if guild.me and role >= guild.me.top_role:
                continue
            perms = role.permissions
            if any(getattr(perms, p, False) for p in DANGEROUS_PERMS):
                dangerous_roles.append(role)

        async with aiosqlite.connect("db/emergency.db") as db:
            for role in dangerous_roles:
                await db.execute(
                    "INSERT OR IGNORE INTO emergency_roles (guild_id, role_id) VALUES (?, ?)",
                    (guild.id, role.id),
                )
            await db.commit()

        role_list = "\n".join(f"{EMOJIS['role']} {r.mention}" for r in dangerous_roles[:20]) or "None detected"

        em = create_embed(

            description=(
                f"## {EMOJIS['emergency']} Emergency Mode Enabled\n{EMOJIS['shield_on']} The emergency system is now **active**.\n\n"
                f"**Detected Dangerous Roles ({len(dangerous_roles)}):**\n{role_list}\n\n"
                f"{EMOJIS['info']} Use `/emergencysituation` to activate the panic button."
            ),
            color=COLORS["error"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    @emergency.command(name="disable", description="Disable the emergency system")
    @app_commands.checks.has_permissions(administrator=True)
    async def emg_disable(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/emergency.db") as db:
            await db.execute("DELETE FROM emergency_roles WHERE guild_id = ?", (guild.id,))
            await db.commit()

        em = create_embed(

            description=f"## {EMOJIS['shield_off']} Emergency System Disabled\n{EMOJIS['warning']} The emergency system has been deactivated.",
            color=COLORS["warning"],
        )
        await interaction.response.send_message(embed=em, ephemeral=True)

    @emergency.command(name="authorise", description="Manage authorized users for emergency commands")
    @app_commands.describe(action="Add or remove a user", user="The user to manage")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add", value="add"),
        app_commands.Choice(name="Remove", value="remove"),
        app_commands.Choice(name="List", value="list"),
    ])
    @app_commands.checks.has_permissions(administrator=True)
    async def emg_authorise(
        self, interaction: discord.Interaction,
        action: app_commands.Choice[str],
        user: discord.Member | None = None,
    ):
        guild = interaction.guild
        if not guild:
            return

        if action.value == "list":
            async with aiosqlite.connect("db/emergency.db") as db:
                async with db.execute(
                    "SELECT user_id FROM authorised_users WHERE guild_id = ?", (guild.id,)
                ) as cur:
                    rows = await cur.fetchall()

            if not rows:
                desc = f"{EMOJIS['info']} No authorized users."
            else:
                desc = "\n".join(f"{EMOJIS['member']} <@{r[0]}>" for r in rows)

            em = create_embed(
                description=f"## {EMOJIS['emergency']} Authorized Users\n{desc}",
                color=COLORS["primary"],
            )
            return await interaction.response.send_message(embed=em, ephemeral=True)

        if not user:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Please specify a user.", color=COLORS["error"]),
                ephemeral=True,
            )

        async with aiosqlite.connect("db/emergency.db") as db:
            if action.value == "add":
                # Max 5
                async with db.execute(
                    "SELECT COUNT(*) FROM authorised_users WHERE guild_id = ?", (guild.id,)
                ) as cur:
                    count = (await cur.fetchone())[0]
                if count >= 5:
                    return await interaction.response.send_message(
                        embed=create_embed(description=f"{EMOJIS['error']} Maximum 5 authorized users.", color=COLORS["error"]),
                        ephemeral=True,
                    )
                await db.execute(
                    "INSERT OR IGNORE INTO authorised_users (guild_id, user_id) VALUES (?, ?)",
                    (guild.id, user.id),
                )
                msg = f"{EMOJIS['success']} {user.mention} has been authorized for emergency commands."
            else:
                await db.execute(
                    "DELETE FROM authorised_users WHERE guild_id = ? AND user_id = ?",
                    (guild.id, user.id),
                )
                msg = f"{EMOJIS['success']} {user.mention} has been removed from authorized users."
            await db.commit()

        em = create_embed(description=msg, color=COLORS["success"])
        await interaction.response.send_message(embed=em, ephemeral=True)

    @app_commands.command(name="emergencysituation", description="🚨 PANIC BUTTON — Strip dangerous permissions from all tracked roles")
    async def emg_situation(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        # Auth check
        is_auth = False
        if interaction.user.id == guild.owner_id:
            is_auth = True
        elif interaction.user.id in self.bot.owner_ids_set:
            is_auth = True
        else:
            extras = self.bot.cache["extra_owners"].get(guild.id, set())
            if interaction.user.id in extras:
                is_auth = True
            else:
                async with aiosqlite.connect("db/emergency.db") as db:
                    async with db.execute(
                        "SELECT 1 FROM authorised_users WHERE guild_id = ? AND user_id = ?",
                        (guild.id, interaction.user.id),
                    ) as cur:
                        if await cur.fetchone():
                            is_auth = True

        if not is_auth:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['denied']} You are not authorized.", color=COLORS["error"]),
                ephemeral=True,
            )

        await interaction.response.defer(ephemeral=True)

        # Get tracked roles
        async with aiosqlite.connect("db/emergency.db") as db:
            async with db.execute(
                "SELECT role_id FROM emergency_roles WHERE guild_id = ?", (guild.id,)
            ) as cur:
                role_ids = [r[0] for r in await cur.fetchall()]

        if not role_ids:
            return await interaction.followup.send(
                embed=create_embed(description=f"{EMOJIS['error']} No roles tracked. Use `/emergency enable` first.", color=COLORS["error"]),
                ephemeral=True,
            )

        stripped = 0
        async with aiosqlite.connect("db/emergency.db") as db:
            for rid in role_ids:
                role = guild.get_role(rid)
                if not role or role.managed or role.is_default():
                    continue
                if guild.me and role >= guild.me.top_role:
                    continue

                # Backup permissions
                await db.execute(
                    "INSERT OR REPLACE INTO restore_roles (guild_id, role_id, permissions) VALUES (?, ?, ?)",
                    (guild.id, role.id, role.permissions.value),
                )

                # Strip dangerous perms
                new_perms = role.permissions
                for p in DANGEROUS_PERMS:
                    setattr(new_perms, p, False)

                try:
                    await role.edit(permissions=new_perms, reason="Zephyr Emergency — Permissions stripped")
                    stripped += 1
                except discord.HTTPException:
                    pass

            await db.commit()

        em = create_embed(

            description=(
                f"## {EMOJIS['a_alert']} EMERGENCY ACTIVATED\n{EMOJIS['shield_on']} Stripped dangerous permissions from **{stripped}** role(s).\n\n"
                f"{EMOJIS['info']} Use `/emergencyrestore` to restore permissions when safe."
            ),
            color=COLORS["error"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    @app_commands.command(name="emergencyrestore", description="Restore permissions after an emergency")
    async def emg_restore(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        if interaction.user.id != guild.owner_id and interaction.user.id not in self.bot.owner_ids_set:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['denied']} Only the **Server Owner** can restore.", color=COLORS["error"]),
                ephemeral=True,
            )

        confirm_view = ConfirmView(interaction.user)
        em = create_embed(

            description=f"## {EMOJIS['warning']} Restore Permissions?\n{EMOJIS['info']} This will restore all permissions that were stripped during the emergency. Are you sure?",
            color=COLORS["warning"],
        )
        await interaction.response.send_message(embed=em, view=confirm_view, ephemeral=True)
        confirm_view.message = await interaction.original_response()

        await confirm_view.wait()
        if not confirm_view.value:
            return

        restored = 0
        async with aiosqlite.connect("db/emergency.db") as db:
            async with db.execute(
                "SELECT role_id, permissions FROM restore_roles WHERE guild_id = ?", (guild.id,)
            ) as cur:
                rows = await cur.fetchall()

            for rid, perms_val in rows:
                role = guild.get_role(rid)
                if not role:
                    continue
                try:
                    await role.edit(
                        permissions=discord.Permissions(perms_val),
                        reason="Zephyr Emergency — Permissions restored",
                    )
                    restored += 1
                except discord.HTTPException:
                    pass

            await db.execute("DELETE FROM restore_roles WHERE guild_id = ?", (guild.id,))
            await db.commit()

        em = create_embed(

            description=f"## {EMOJIS['success']} Permissions Restored\n{EMOJIS['shield']} Restored permissions for **{restored}** role(s).",
            color=COLORS["success"],
        )
        await interaction.edit_original_response(embed=em, view=None)


async def setup(bot: Zephyr):
    await bot.add_cog(EmergencyCog(bot))
    log.info("  ✓ EmergencyCog loaded")
