"""
Media Channels — /media enable/disable/bypass/config
Only allows messages with attachments in designated channels.
Features: bypass list, auto-blacklist spam, config view.
DB: db/media.db — tables:
  media_channels (guild_id PK, channel_id) — one media channel per guild
  media_bypass (guild_id, user_id) — user bypass only
"""
from __future__ import annotations
import asyncio, logging, time
from collections import defaultdict
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.media")


class MediaCog(commands.Cog):
    """Media-only channel system for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot
        self._violations: dict[int, dict[int, list[float]]] = defaultdict(lambda: defaultdict(list))

    media = app_commands.Group(name="media", description="Media channel management")
    bypass = app_commands.Group(name="bypass", description="Media bypass management", parent=media)

    @media.command(name="enable", description="Set a channel as media-only")
    @app_commands.describe(channel="Channel to make media-only")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def media_enable(self, it: discord.Interaction, channel: discord.TextChannel):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/media.db") as db:
            await db.execute("INSERT OR REPLACE INTO media_channels (guild_id, channel_id) VALUES (?, ?)", (g.id, channel.id))
            await db.commit()
        self.bot.cache["media_channels"][g.id] = channel.id
        em = create_embed(

            description=f"## {EMOJIS['settings']} Media Channel Set\n{EMOJIS['success']} {channel.mention} is now a **media-only** channel.\n{EMOJIS['info']} Only messages with attachments will be allowed.",
            color=COLORS["success"],
        )
        await it.response.send_message(embed=em)

    @media.command(name="disable", description="Remove media-only restriction")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def media_disable(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/media.db") as db:
            await db.execute("DELETE FROM media_channels WHERE guild_id = ?", (g.id,))
            await db.commit()
        self.bot.cache["media_channels"].pop(g.id, None)
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Media-only channel removed.", color=COLORS["success"]))

    @media.command(name="config", description="View media channel and bypass list")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def media_config(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        ch_id = self.bot.cache["media_channels"].get(g.id)
        if not ch_id:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No media channel configured.", color=COLORS["info"]), ephemeral=True)

        bp_users = self.bot.cache["media_bypass"].get(g.id, set())
        bp_list = "\n".join(f"{EMOJIS['member']} <@{uid}>" for uid in bp_users) if bp_users else "None"

        em = create_embed(

            description=f"## {EMOJIS['settings']} Media Config\n**Media Channel:** <#{ch_id}>\n\n**Bypassed Users:**\n{bp_list}",
            color=COLORS["primary"],
        )
        await it.response.send_message(embed=em, ephemeral=True)

    # ── Bypass subgroup ───────────────────────────────────────
    @bypass.command(name="add", description="Add a user to the media bypass list")
    @app_commands.describe(user="User to bypass")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def bp_add(self, it: discord.Interaction, user: discord.Member):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/media.db") as db:
            await db.execute("INSERT OR IGNORE INTO media_bypass(guild_id,user_id) VALUES(?,?)", (g.id, user.id))
            await db.commit()
        self.bot.cache["media_bypass"].setdefault(g.id, set()).add(user.id)
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} {user.mention} added to media bypass.", color=COLORS["success"]))

    @bypass.command(name="remove", description="Remove a user from the media bypass list")
    @app_commands.describe(user="User to remove")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def bp_remove(self, it: discord.Interaction, user: discord.Member):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/media.db") as db:
            await db.execute("DELETE FROM media_bypass WHERE guild_id=? AND user_id=?", (g.id, user.id))
            await db.commit()
        self.bot.cache["media_bypass"].get(g.id, set()).discard(user.id)
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} {user.mention} removed from media bypass.", color=COLORS["success"]))

    @bypass.command(name="show", description="Show all media bypassed users")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def bp_show(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        bp_users = self.bot.cache["media_bypass"].get(g.id, set())
        if not bp_users:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No bypassed users.", color=COLORS["info"]), ephemeral=True)
        lines = [f"{EMOJIS['member']} <@{uid}>" for uid in bp_users]
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['settings']} Media Bypasses\n" + "\n".join(lines), color=COLORS["primary"]), ephemeral=True)

    # ── Listener ──────────────────────────────────────────────
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild: return
        media_ch = self.bot.cache["media_channels"].get(message.guild.id)
        if message.channel.id != media_ch: return

        # Allow if has media
        if message.attachments or message.embeds: return

        # Check bypass
        if isinstance(message.author, discord.Member):
            if message.author.guild_permissions.manage_messages: return
            bypassed = self.bot.cache["media_bypass"].get(message.guild.id, set())
            if message.author.id in bypassed: return

        # Anti-spam: track violations (3 in 30s = timeout)
        now = time.time()
        user_viols = self._violations[message.guild.id][message.author.id]
        user_viols.append(now)
        self._violations[message.guild.id][message.author.id] = [t for t in user_viols if now - t < 30]
        if len(self._violations[message.guild.id][message.author.id]) >= 3:
            try:
                if isinstance(message.author, discord.Member):
                    from datetime import timedelta
                    await message.author.timeout(timedelta(minutes=5), reason="Zephyr — Media channel spam")
                    self._violations[message.guild.id][message.author.id].clear()
            except discord.HTTPException: pass

        try:
            await message.delete()
            em = discord.Embed(
                description=f"{EMOJIS['error']} {message.author.mention}, this channel only allows **media content** (images, videos, files).",
                color=COLORS["warning"],
            )
            msg = await message.channel.send(embed=em)
            await asyncio.sleep(3)
            await msg.delete()
        except discord.HTTPException: pass


async def setup(bot: Zephyr):
    await bot.add_cog(MediaCog(bot))
    log.info("  ✓ MediaCog loaded")
