"""
Antinuke Commands — /antinuke enable/disable, /whitelist, /whitelisted, /whitelistreset
Advanced Whitelist System with 3 Select Menu panels (codeconfig.md §3):
  1. Antinuke Bypass — Ban, Kick, Channel, Role, Webhook, etc.
  2. Automod Immunity — Spam, Links, Caps, Invites, Mass Mention
  3. Command Access — Warn, Ban, Mute, Purge, Lock, Hide
Supports both users AND roles as targets.
DB: anti.db (whitelisted_users), whitelist.db (whitelist_automod, whitelist_commands)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import aiosqlite
import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS, LINKS
from utils.Tools import blacklist_check, ignore_check, is_extra_owner, create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.antinuke")

# ── Permission definitions ─────────────────────────────────────

ANTINUKE_PERMS = [
    ("ban", "Ban Members"),
    ("kick", "Kick Members"),
    ("prune", "Prune Members"),
    ("botadd", "Add Bots"),
    ("serverup", "Server Update"),
    ("memup", "Member Update"),
    ("chcr", "Channel Create"),
    ("chdl", "Channel Delete"),
    ("chup", "Channel Update"),
    ("rlcr", "Role Create"),
    ("rlup", "Role Update"),
    ("rldl", "Role Delete"),
    ("meneve", "Mention Everyone"),
    ("mngweb", "Manage Webhooks"),
    ("mngstemo", "Manage Stickers/Emojis"),
]

AUTOMOD_PERMS = [
    ("spam", "Anti Spam"),
    ("links", "Anti Links"),
    ("caps", "Anti Caps"),
    ("invites", "Anti Invites"),
    ("mass_mention", "Anti Mass Mention"),
]

COMMAND_PERMS = [
    ("warn_cmd", "Warn Command"),
    ("ban_cmd", "Ban Command"),
    ("mute_cmd", "Mute Command"),
    ("purge_cmd", "Purge Command"),
    ("lock_cmd", "Lock Command"),
    ("hide_cmd", "Hide Command"),
]


# ═══════════════════════════════════════════════════════════════
#  UNIFIED 3-PANEL WHITELIST VIEW (codeconfig.md §3)
# ═══════════════════════════════════════════════════════════════

class UnifiedWhitelistView(discord.ui.View):
    """
    Ultra-Premium whitelist configuration panel with 3 distinct select menus:
    1. Antinuke Bypass — [Ban, Kick, Channel, Role, Webhook, etc.]
    2. Automod Immunity — [Spam, Links, Caps, Invites, Mass Mention]
    3. Command Access — [Warn, Ban, Mute, Purge, Lock, Hide]

    Supports both user and role targets.
    """

    def __init__(
        self,
        author_id: int,
        guild_id: int,
        target_id: int,
        target_type: str,  # "user" or "role"
        current_an: dict,
        current_am: dict,
        current_cmd: dict,
    ):
        super().__init__(timeout=180)
        self.author_id = author_id
        self.guild_id = guild_id
        self.target_id = target_id
        self.target_type = target_type
        self.antinuke_perms: list[str] = []
        self.automod_perms: list[str] = []
        self.command_perms: list[str] = []
        self.saved = False

        # ── Panel 1: Antinuke Bypass ──
        an_options = []
        for key, label in ANTINUKE_PERMS:
            is_on = bool(current_an.get(key, 0))
            an_options.append(discord.SelectOption(
                label=label, value=key,
                emoji=EMOJIS.get("checkmark", EMOJIS['success']) if is_on else EMOJIS.get("crossmark", EMOJIS['error']),
                default=is_on,
                description="✓ Allowed" if is_on else "✗ Blocked",
            ))
        self._an_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('antinuke', EMOJIS['antinuke'])} Antinuke Bypass Permissions",
            options=an_options, min_values=0, max_values=len(an_options), row=0,
        )
        self._an_select.callback = self._an_callback
        self.add_item(self._an_select)

        # ── Panel 2: Automod Immunity ──
        am_options = []
        for key, label in AUTOMOD_PERMS:
            is_on = bool(current_am.get(key, 0))
            am_options.append(discord.SelectOption(
                label=label, value=key,
                emoji=EMOJIS.get("checkmark", EMOJIS['success']) if is_on else EMOJIS.get("crossmark", EMOJIS['error']),
                default=is_on,
                description="✓ Immune" if is_on else "✗ Not immune",
            ))
        self._am_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('automod', EMOJIS['automod'])} Automod Immunity",
            options=am_options, min_values=0, max_values=len(am_options), row=1,
        )
        self._am_select.callback = self._am_callback
        self.add_item(self._am_select)

        # ── Panel 3: Command Access ──
        cmd_options = []
        for key, label in COMMAND_PERMS:
            is_on = bool(current_cmd.get(key, 0))
            cmd_options.append(discord.SelectOption(
                label=label, value=key,
                emoji=EMOJIS.get("checkmark", EMOJIS['success']) if is_on else EMOJIS.get("crossmark", EMOJIS['error']),
                default=is_on,
                description="✓ Granted" if is_on else "✗ Denied",
            ))
        self._cmd_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('staff', EMOJIS['staff'])} Command Access (Prefix + Slash)",
            options=cmd_options, min_values=0, max_values=len(cmd_options), row=2,
        )
        self._cmd_select.callback = self._cmd_callback
        self.add_item(self._cmd_select)

        # ── Save button ──
        save_btn = discord.ui.Button(
            label="Save Configuration", style=discord.ButtonStyle.success,
            emoji="💾", row=3,
        )
        save_btn.callback = self._save_callback
        self.add_item(save_btn)

        # ── Link buttons ──
        self.add_item(discord.ui.Button(
            label="Support", emoji=EMOJIS.get("support", EMOJIS['support']),
            url=LINKS["support"], style=discord.ButtonStyle.link, row=4,
        ))
        self.add_item(discord.ui.Button(
            label="Docs", emoji=EMOJIS.get("link", EMOJIS['link']),
            url=LINKS["docs"], style=discord.ButtonStyle.link, row=4,
        ))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(
                f"{EMOJIS['denied']} This panel is not for you.", ephemeral=True,
            )
            return False
        return True

    async def _an_callback(self, interaction: discord.Interaction):
        self.antinuke_perms = self._an_select.values
        await interaction.response.defer()

    async def _am_callback(self, interaction: discord.Interaction):
        self.automod_perms = self._am_select.values
        await interaction.response.defer()

    async def _cmd_callback(self, interaction: discord.Interaction):
        self.command_perms = self._cmd_select.values
        await interaction.response.defer()

    async def _save_callback(self, interaction: discord.Interaction):
        bot: Zephyr = interaction.client  # type: ignore
        gid = self.guild_id
        tid = self.target_id
        ttype = self.target_type

        # ── 1. Save Antinuke Bypass → anti.db / whitelisted_users ──
        an_updates = {key: (1 if key in self.antinuke_perms else 0) for key, _ in ANTINUKE_PERMS}
        cols = ", ".join(f"{k} = ?" for k in an_updates)
        vals = list(an_updates.values())

        if ttype == "user":
            async with aiosqlite.connect("db/anti.db") as db:
                await db.execute(
                    f"""INSERT INTO whitelisted_users (guild_id, user_id, {', '.join(an_updates.keys())})
                        VALUES (?, ?, {', '.join('?' * len(an_updates))})
                        ON CONFLICT(guild_id, user_id) DO UPDATE SET {cols}""",
                    [gid, tid] + vals + vals,
                )
                await db.commit()
            bot.cache["whitelist"].setdefault(gid, {})[tid] = an_updates

        # ── 2. Save Automod Immunity → whitelist.db / whitelist_automod ──
        am_updates = {key: (1 if key in self.automod_perms else 0) for key, _ in AUTOMOD_PERMS}
        am_cols = ", ".join(f"{k} = ?" for k in am_updates)
        am_vals = list(am_updates.values())

        async with aiosqlite.connect("db/whitelist.db") as db:
            await db.execute(
                f"""INSERT INTO whitelist_automod (guild_id, target_id, target_type, {', '.join(am_updates.keys())})
                    VALUES (?, ?, ?, {', '.join('?' * len(am_updates))})
                    ON CONFLICT(guild_id, target_id) DO UPDATE SET target_type = ?, {am_cols}""",
                [gid, tid, ttype] + am_vals + [ttype] + am_vals,
            )
            await db.commit()

        # ── 3. Save Command Access → whitelist.db / whitelist_commands ──
        cmd_updates = {key: (1 if key in self.command_perms else 0) for key, _ in COMMAND_PERMS}
        cmd_cols = ", ".join(f"{k} = ?" for k in cmd_updates)
        cmd_vals = list(cmd_updates.values())

        async with aiosqlite.connect("db/whitelist.db") as db:
            await db.execute(
                f"""INSERT INTO whitelist_commands (guild_id, target_id, target_type, {', '.join(cmd_updates.keys())})
                    VALUES (?, ?, ?, {', '.join('?' * len(cmd_updates))})
                    ON CONFLICT(guild_id, target_id) DO UPDATE SET target_type = ?, {cmd_cols}""",
                [gid, tid, ttype] + cmd_vals + [ttype] + cmd_vals,
            )
            await db.commit()

        # ── Build summary embed ──
        an_granted = [label for key, label in ANTINUKE_PERMS if key in self.antinuke_perms]
        am_granted = [label for key, label in AUTOMOD_PERMS if key in self.automod_perms]
        cmd_granted = [label for key, label in COMMAND_PERMS if key in self.command_perms]

        an_str = "\n".join(f"  {EMOJIS.get('checkmark', EMOJIS['success'])} {p}" for p in an_granted) if an_granted else f"  {EMOJIS.get('crossmark', EMOJIS['error'])} None"
        am_str = "\n".join(f"  {EMOJIS.get('checkmark', EMOJIS['success'])} {p}" for p in am_granted) if am_granted else f"  {EMOJIS.get('crossmark', EMOJIS['error'])} None"
        cmd_str = "\n".join(f"  {EMOJIS.get('checkmark', EMOJIS['success'])} {p}" for p in cmd_granted) if cmd_granted else f"  {EMOJIS.get('crossmark', EMOJIS['error'])} None"

        target_mention = f"<@{tid}>" if ttype == "user" else f"<@&{tid}>"

        em = create_embed(

            description=(
                f"## {EMOJIS.get('shield_on', EMOJIS['shield'])} Whitelist Configuration Saved\n{EMOJIS.get('success', EMOJIS['success'])} Permissions for {target_mention} have been saved.\n\n"
                f"**{EMOJIS.get('antinuke', EMOJIS['antinuke'])} Antinuke Bypass:**\n{an_str}\n\n"
                f"**{EMOJIS.get('automod', EMOJIS['automod'])} Automod Immunity:**\n{am_str}\n\n"
                f"**{EMOJIS.get('staff', EMOJIS['staff'])} Command Access:**\n{cmd_str}"
            ),
            color=COLORS["success"],
        )

        self.saved = True
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(embed=em, view=self)

    async def on_timeout(self):
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True


# ═══════════════════════════════════════════════════════════════
#  COG
# ═══════════════════════════════════════════════════════════════

class AntinukeCog(commands.Cog):
    """Antinuke system — core security module for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    antinuke_group = app_commands.Group(
        name="antinuke", description="Manage the Zephyr antinuke system"
    )

    # ═══════════════════════════════════════════════════════════
    #  /antinuke logging — Set logging channel
    # ═══════════════════════════════════════════════════════════

    @antinuke_group.command(name="logging", description="Set the antinuke logging channel")
    @app_commands.describe(channel="Channel to send antinuke logs to")
    @app_commands.checks.has_permissions(administrator=True)
    async def antinuke_logging(self, interaction: discord.Interaction, channel: discord.TextChannel):
        guild = interaction.guild
        if not guild:
            return

        # Save to database
        async with aiosqlite.connect("db/anti.db") as db:
            await db.execute(
                "INSERT INTO antinuke_logging (guild_id, channel_id) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET channel_id = ?",
                (guild.id, channel.id, channel.id),
            )
            await db.commit()

        # Update cache
        if "antinuke_logging" not in self.bot.cache:
            self.bot.cache["antinuke_logging"] = {}
        self.bot.cache["antinuke_logging"][guild.id] = channel.id

        em = create_embed(
            description=(
                f"## {EMOJIS['success']} Antinuke Logging Configured\n"
                f"{EMOJIS['channel']} **Channel:** {channel.mention}\n\n"
                f"{EMOJIS['info']} All antinuke actions will be logged here with full details."
            ),
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em, ephemeral=True)

    # ── Enable ─────────────────────────────────────────────────
    @antinuke_group.command(name="enable", description="Enable the antinuke system")
    @app_commands.checks.has_permissions(administrator=True)
    async def antinuke_enable(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        guild = interaction.guild
        if not guild:
            return

        if interaction.user.id != guild.owner_id and interaction.user.id not in self.bot.owner_ids_set:
            extras = self.bot.cache["extra_owners"].get(guild.id, set())
            if interaction.user.id not in extras:
                em = create_embed(
                    description=f"{EMOJIS['denied']} Only the **Server Owner** or **Extra Owners** can enable Antinuke.",
                    color=COLORS["error"],
                )
                return await interaction.followup.send(embed=em, ephemeral=True)

        # Create / find "Zephyr Supreme™" role
        supreme_role = discord.utils.get(guild.roles, name="Zephyr Supreme™")
        if not supreme_role:
            try:
                supreme_role = await guild.create_role(
                    name="Zephyr Supreme™",
                    color=COLORS["zephyr"],
                    reason="Zephyr Antinuke — Security role",
                )
            except discord.Forbidden:
                pass

        # Move role to highest possible position
        if supreme_role and guild.me:
            try:
                bot_top = guild.me.top_role.position
                await supreme_role.edit(position=max(1, bot_top - 1))
            except (discord.Forbidden, discord.HTTPException):
                pass

        # Enable in DB + cache
        async with aiosqlite.connect("db/anti.db") as db:
            await db.execute(
                "INSERT INTO antinuke (guild_id, status) VALUES (?, 1) ON CONFLICT(guild_id) DO UPDATE SET status = 1",
                (guild.id,),
            )
            await db.commit()

        self.bot.cache["antinuke"][guild.id] = True

        em = create_embed(

            description=(
                f"## {EMOJIS['shield_on']} Antinuke Enabled\n{EMOJIS['success']} The antinuke system is now **active** for this server.\n\n"
                f"{EMOJIS['shield']} All unauthorized destructive actions will be **blocked and reversed**.\n"
                f"{EMOJIS['info']} Use `/whitelist @user` to grant specific bypasses."
            ),
            color=COLORS["success"],
        )
        if guild.icon:
            em.add_field(name="Server Icon", value=f"[View Icon]({guild.icon.url})", inline=False)
        await interaction.followup.send(embed=em, ephemeral=True)

    # ── Disable ────────────────────────────────────────────────
    @antinuke_group.command(name="disable", description="Disable the antinuke system")
    @app_commands.checks.has_permissions(administrator=True)
    async def antinuke_disable(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        guild = interaction.guild
        if not guild:
            return

        if interaction.user.id != guild.owner_id and interaction.user.id not in self.bot.owner_ids_set:
            extras = self.bot.cache["extra_owners"].get(guild.id, set())
            if interaction.user.id not in extras:
                em = create_embed(
                    description=f"{EMOJIS['denied']} Only the **Server Owner** or **Extra Owners** can disable Antinuke.",
                    color=COLORS["error"],
                )
                return await interaction.followup.send(embed=em, ephemeral=True)

        async with aiosqlite.connect("db/anti.db") as db:
            await db.execute(
                "INSERT INTO antinuke (guild_id, status) VALUES (?, 0) ON CONFLICT(guild_id) DO UPDATE SET status = 0",
                (guild.id,),
            )
            await db.commit()

        self.bot.cache["antinuke"][guild.id] = False

        em = create_embed(

            description=f"## {EMOJIS['shield_off']} Antinuke Disabled\n{EMOJIS['warning']} The antinuke system has been **deactivated**.\n{EMOJIS['info']} Your server is no longer protected against unauthorized actions.",
            color=COLORS["warning"],
        )
        await interaction.followup.send(embed=em, ephemeral=True)

    # ═══════════════════════════════════════════════════════════
    #  /whitelist — Unified 3-Panel Dashboard (codeconfig.md §3)
    # ═══════════════════════════════════════════════════════════

    @app_commands.command(name="whitelist", description="Configure whitelist for a user or role (3-panel dashboard)")
    @app_commands.describe(user="User to whitelist", role="Role to whitelist")
    @app_commands.checks.has_permissions(administrator=True)
    async def whitelist_cmd(
        self,
        interaction: discord.Interaction,
        user: discord.Member | None = None,
        role: discord.Role | None = None,
    ):
        guild = interaction.guild
        if not guild:
            return

        # Must supply one target
        if not user and not role:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must specify a **user** or a **role** to whitelist.", color=COLORS["error"]),
                ephemeral=True,
            )
        if user and role:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} Specify only **one** target — a user OR a role, not both.", color=COLORS["error"]),
                ephemeral=True,
            )

        # Permission check: owner / extra owner / bot owner only
        if interaction.user.id != guild.owner_id and interaction.user.id not in self.bot.owner_ids_set:
            extras = self.bot.cache["extra_owners"].get(guild.id, set())
            if interaction.user.id not in extras:
                return await interaction.response.send_message(
                    embed=create_embed(description=f"{EMOJIS['denied']} Only the **Server Owner** can manage the whitelist.", color=COLORS["error"]),
                    ephemeral=True,
                )

        target_id = user.id if user else role.id  # type: ignore
        target_type = "user" if user else "role"
        target_display = user.mention if user else role.mention  # type: ignore
        target_icon = (user.display_avatar.url if user else (role.icon.url if role and role.icon else None))  # type: ignore

        # Load current perms from each DB
        current_an: dict = {}
        if target_type == "user":
            current_an = self.bot.cache["whitelist"].get(guild.id, {}).get(target_id, {})

        current_am: dict = {}
        async with aiosqlite.connect("db/whitelist.db") as db:
            async with db.execute(
                "SELECT spam, links, caps, invites, mass_mention FROM whitelist_automod WHERE guild_id=? AND target_id=?",
                (guild.id, target_id),
            ) as cur:
                row = await cur.fetchone()
            if row:
                current_am = dict(zip([k for k, _ in AUTOMOD_PERMS], row))

        current_cmd: dict = {}
        async with aiosqlite.connect("db/whitelist.db") as db:
            async with db.execute(
                "SELECT warn_cmd, ban_cmd, mute_cmd, purge_cmd, lock_cmd, hide_cmd FROM whitelist_commands WHERE guild_id=? AND target_id=?",
                (guild.id, target_id),
            ) as cur:
                row = await cur.fetchone()
            if row:
                current_cmd = dict(zip([k for k, _ in COMMAND_PERMS], row))

        # Build the embed
        type_icon = EMOJIS.get("member", EMOJIS['member']) if target_type == "user" else EMOJIS.get("role", EMOJIS['role'])
        em = create_embed(

            description=(
                f"## {EMOJIS.get('whitelist', EMOJIS['shield'])} Whitelist Configuration\n{type_icon} **Target:** {target_display}\n"
                f"{EMOJIS.get('info', EMOJIS['info'])} **Type:** {target_type.title()}\n\n"
                f"{EMOJIS.get('antinuke', EMOJIS['antinuke'])} **Panel 1** — Antinuke bypass permissions\n"
                f"{EMOJIS.get('automod', EMOJIS['automod'])} **Panel 2** — Automod filter immunity\n"
                f"{EMOJIS.get('staff', EMOJIS['staff'])} **Panel 3** — Moderation command access\n\n"
                f"*Select permissions in each panel, then click* **Save Configuration** *to apply.*"
            ),
            color=COLORS["primary"],
        )

        view = UnifiedWhitelistView(
            author_id=interaction.user.id,
            guild_id=guild.id,
            target_id=target_id,
            target_type=target_type,
            current_an=current_an,
            current_am=current_am,
            current_cmd=current_cmd,
        )
        await interaction.response.send_message(embed=em, view=view, ephemeral=True)

    # ═══════════════════════════════════════════════════════════
    #  /whitelisted — View all whitelisted users & roles
    # ═══════════════════════════════════════════════════════════

    @app_commands.command(name="whitelisted", description="View all whitelisted users and roles")
    @app_commands.checks.has_permissions(administrator=True)
    async def whitelisted_cmd(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        # Antinuke whitelist (users only, from cache)
        wl = self.bot.cache["whitelist"].get(guild.id, {})

        # Automod + Command whitelist (users + roles, from DB)
        am_entries: list[tuple[int, str]] = []
        cmd_entries: list[tuple[int, str]] = []

        async with aiosqlite.connect("db/whitelist.db") as db:
            async with db.execute(
                "SELECT target_id, target_type FROM whitelist_automod WHERE guild_id=?", (guild.id,)
            ) as cur:
                am_entries = [(r[0], r[1]) for r in await cur.fetchall()]
            async with db.execute(
                "SELECT target_id, target_type FROM whitelist_commands WHERE guild_id=?", (guild.id,)
            ) as cur:
                cmd_entries = [(r[0], r[1]) for r in await cur.fetchall()]

        if not wl and not am_entries and not cmd_entries:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['info']} No whitelist entries for this server.", color=COLORS["info"]),
                ephemeral=True,
            )

        parts = []

        # Antinuke section
        if wl:
            lines = []
            for uid, perms in wl.items():
                active = [label for key, label in ANTINUKE_PERMS if perms.get(key)]
                perm_str = ", ".join(active[:5]) if active else "None"
                if len(active) > 5:
                    perm_str += f" +{len(active)-5} more"
                lines.append(f"{EMOJIS.get('member', EMOJIS['member'])} <@{uid}> — {perm_str}")
            parts.append(f"**{EMOJIS.get('antinuke', EMOJIS['antinuke'])} Antinuke Bypass** ({len(wl)})\n" + "\n".join(lines[:10]))

        # Automod Immunity section
        if am_entries:
            lines = []
            for tid, ttype in am_entries[:10]:
                mention = f"<@{tid}>" if ttype == "user" else f"<@&{tid}>"
                lines.append(f"{EMOJIS.get('automod', EMOJIS['automod'])} {mention}")
            parts.append(f"**{EMOJIS.get('automod', EMOJIS['automod'])} Automod Immunity** ({len(am_entries)})\n" + "\n".join(lines))

        # Command Access section
        if cmd_entries:
            lines = []
            for tid, ttype in cmd_entries[:10]:
                mention = f"<@{tid}>" if ttype == "user" else f"<@&{tid}>"
                lines.append(f"{EMOJIS.get('staff', EMOJIS['staff'])} {mention}")
            parts.append(f"**{EMOJIS.get('staff', EMOJIS['staff'])} Command Access** ({len(cmd_entries)})\n" + "\n".join(lines))

        em = create_embed(
            description=f"## {EMOJIS.get('whitelist', EMOJIS['shield'])} Whitelist Overview\n" + "\n\n".join(parts),
            color=COLORS["primary"],
        )
        total = len(wl) + len(am_entries) + len(cmd_entries)
        em.set_footer(text=f"✦ Zephyr • {total} total whitelist entries")
        await interaction.response.send_message(embed=em, ephemeral=True)

    # ═══════════════════════════════════════════════════════════
    #  /whitelistreset — Reset ALL whitelist entries
    # ═══════════════════════════════════════════════════════════

    @app_commands.command(name="whitelistreset", description="Reset all whitelist entries for this server")
    @app_commands.checks.has_permissions(administrator=True)
    async def whitelistreset_cmd(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        if interaction.user.id != guild.owner_id and interaction.user.id not in self.bot.owner_ids_set:
            em = create_embed(
                description=f"{EMOJIS['denied']} Only the **Server Owner** can reset the whitelist.",
                color=COLORS["error"],
            )
            return await interaction.response.send_message(embed=em, ephemeral=True)

        # Clear all 3 tables
        async with aiosqlite.connect("db/anti.db") as db:
            await db.execute("DELETE FROM whitelisted_users WHERE guild_id = ?", (guild.id,))
            await db.commit()

        async with aiosqlite.connect("db/whitelist.db") as db:
            await db.execute("DELETE FROM whitelist_automod WHERE guild_id = ?", (guild.id,))
            await db.execute("DELETE FROM whitelist_commands WHERE guild_id = ?", (guild.id,))
            await db.commit()

        self.bot.cache["whitelist"].pop(guild.id, None)

        em = create_embed(

            description=(
                f"## {EMOJIS['success']} Whitelist Reset\n{EMOJIS['delete']} All whitelist entries for this server have been cleared.\n\n"
                f"This includes:\n"
                f"  {EMOJIS.get('antinuke', EMOJIS['antinuke'])} Antinuke bypass permissions\n"
                f"  {EMOJIS.get('automod', EMOJIS['automod'])} Automod immunity entries\n"
                f"  {EMOJIS.get('staff', EMOJIS['staff'])} Command access grants"
            ),
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em, ephemeral=True)

    # ═══════════════════════════════════════════════════════════
    #  Prefix command alias: ?wl / !wl (codeconfig.md §3)
    # ═══════════════════════════════════════════════════════════

    @commands.command(name="wl", aliases=["whitelist"])
    @commands.has_permissions(administrator=True)
    async def wl_prefix(self, ctx: commands.Context, target: discord.Member | discord.Role | None = None):
        """Prefix alias for the /whitelist command. Usage: ?wl @user or ?wl @role"""
        guild = ctx.guild
        if not guild or not target:
            return await ctx.send(
                embed=create_embed(description=f"{EMOJIS['error']} Usage: `{ctx.prefix}wl @user` or `{ctx.prefix}wl @role`", color=COLORS["error"]),
            )

        # Permission check
        if ctx.author.id != guild.owner_id and ctx.author.id not in self.bot.owner_ids_set:
            extras = self.bot.cache["extra_owners"].get(guild.id, set())
            if ctx.author.id not in extras:
                return await ctx.send(
                    embed=create_embed(description=f"{EMOJIS['denied']} Only the **Server Owner** can manage the whitelist.", color=COLORS["error"]),
                )

        if isinstance(target, discord.Member):
            target_id = target.id
            target_type = "user"
            target_display = target.mention
            target_icon = target.display_avatar.url
        else:
            target_id = target.id
            target_type = "role"
            target_display = target.mention
            target_icon = target.icon.url if target.icon else None

        # Load current perms
        current_an = self.bot.cache["whitelist"].get(guild.id, {}).get(target_id, {}) if target_type == "user" else {}
        current_am: dict = {}
        current_cmd: dict = {}

        async with aiosqlite.connect("db/whitelist.db") as db:
            async with db.execute("SELECT spam, links, caps, invites, mass_mention FROM whitelist_automod WHERE guild_id=? AND target_id=?", (guild.id, target_id)) as cur:
                row = await cur.fetchone()
            if row:
                current_am = dict(zip([k for k, _ in AUTOMOD_PERMS], row))

            async with db.execute("SELECT warn_cmd, ban_cmd, mute_cmd, purge_cmd, lock_cmd, hide_cmd FROM whitelist_commands WHERE guild_id=? AND target_id=?", (guild.id, target_id)) as cur:
                row = await cur.fetchone()
            if row:
                current_cmd = dict(zip([k for k, _ in COMMAND_PERMS], row))

        type_icon = EMOJIS.get("member", EMOJIS['member']) if target_type == "user" else EMOJIS.get("role", EMOJIS['role'])
        em = create_embed(

            description=(
                f"## {EMOJIS.get('whitelist', EMOJIS['shield'])} Whitelist Configuration\n{type_icon} **Target:** {target_display}\n"
                f"{EMOJIS.get('info', EMOJIS['info'])} **Type:** {target_type.title()}\n\n"
                f"{EMOJIS.get('antinuke', EMOJIS['antinuke'])} **Panel 1** — Antinuke bypass permissions\n"
                f"{EMOJIS.get('automod', EMOJIS['automod'])} **Panel 2** — Automod filter immunity\n"
                f"{EMOJIS.get('staff', EMOJIS['staff'])} **Panel 3** — Moderation command access\n\n"
                f"*Select permissions in each panel, then click* **Save Configuration** *to apply.*"
            ),
            color=COLORS["primary"],
        )

        view = UnifiedWhitelistView(
            author_id=ctx.author.id,
            guild_id=guild.id,
            target_id=target_id,
            target_type=target_type,
            current_an=current_an,
            current_am=current_am,
            current_cmd=current_cmd,
        )
        await ctx.send(embed=em, view=view)


async def setup(bot: Zephyr):
    await bot.add_cog(AntinukeCog(bot))
    log.info("  ✓ AntinukeCog loaded")
