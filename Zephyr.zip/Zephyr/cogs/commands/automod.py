"""
Automod Commands — /automod enable/disable/punishment/ignore
Configurable chat filters with native Discord AutoMod integration.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import aiosqlite
import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS
from utils.Tools import blacklist_check, ignore_check, create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.automod")

FILTER_OPTIONS = [
    ("antispam", "Anti Spam", "Block rapid message spam"),
    ("antilink", "Anti Link", "Block external links"),
    ("anticaps", "Anti Caps", "Block excessive CAPS messages"),
    ("antiinvite", "Anti Invite", "Block Discord invite links"),
    ("antinsfw", "Anti NSFW", "Block NSFW content (Discord AutoMod)"),
    ("antimention", "Anti Mass Mention", "Block mass mentions"),
]

PUNISHMENT_OPTIONS = [
    ("mute", "Mute (Timeout)", "Timeout the user for 5 minutes"),
    ("kick", "Kick", "Kick the user from the server"),
    ("ban", "Ban", "Ban the user from the server"),
    ("warn", "Warn", "Issue a warning to the user"),
]


class FilterSelect(discord.ui.Select):
    def __init__(self, guild_id: int, current_filters: set):
        options = [
            discord.SelectOption(
                label=label,
                value=key,
                description=desc,
                emoji=EMOJIS["checkmark"] if key in current_filters else EMOJIS["crossmark"],
                default=key in current_filters,
            )
            for key, label, desc in FILTER_OPTIONS
        ]
        super().__init__(
            placeholder=f"{EMOJIS['automod']} Select filters to enable",
            min_values=0,
            max_values=len(FILTER_OPTIONS),
            options=options,
        )
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction):
        bot: Zephyr = interaction.client  # type: ignore
        selected = set(self.values)

        async with aiosqlite.connect("db/automod.db") as db:
            await db.execute(
                "INSERT INTO automod (guild_id, enabled) VALUES (?, 1) ON CONFLICT(guild_id) DO UPDATE SET enabled = 1",
                (self.guild_id,),
            )
            # Store selected filters as punishments with default
            for key, _, _ in FILTER_OPTIONS:
                if key in selected:
                    await db.execute(
                        "INSERT INTO automod_punishments (guild_id, event, punishment) VALUES (?, ?, 'mute') ON CONFLICT DO NOTHING",
                        (self.guild_id, key),
                    )
                else:
                    await db.execute(
                        "DELETE FROM automod_punishments WHERE guild_id = ? AND event = ?",
                        (self.guild_id, key),
                    )
            await db.commit()

        bot.cache["automod"][self.guild_id] = {
            "enabled": True,
            "filters": selected,
        }

        enabled_list = "\n".join(
            f"{EMOJIS['checkmark']} **{label}**"
            for key, label, _ in FILTER_OPTIONS
            if key in selected
        ) or f"{EMOJIS['crossmark']} No filters enabled"

        em = create_embed(

            description=f"## {EMOJIS['automod']} Automod Configured\n{EMOJIS['success']} Filters updated:\n\n{enabled_list}",
            color=COLORS["success"],
        )
        await interaction.response.edit_message(embed=em, view=None)


class PunishmentSelect(discord.ui.Select):
    def __init__(self, guild_id: int):
        options = [
            discord.SelectOption(
                label=label,
                value=key,
                description=desc,
                emoji=EMOJIS["ban_hammer"] if key == "ban" else EMOJIS["warn"],
            )
            for key, label, desc in PUNISHMENT_OPTIONS
        ]
        super().__init__(
            placeholder="Select punishment type",
            min_values=1,
            max_values=1,
            options=options,
        )
        self.guild_id = guild_id

    async def callback(self, interaction: discord.Interaction):
        punishment = self.values[0]

        async with aiosqlite.connect("db/automod.db") as db:
            await db.execute(
                "UPDATE automod_punishments SET punishment = ? WHERE guild_id = ?",
                (punishment, self.guild_id),
            )
            await db.commit()

        label = next(l for k, l, _ in PUNISHMENT_OPTIONS if k == punishment)
        em = create_embed(

            description=f"## {EMOJIS['success']} Punishment Updated\n{EMOJIS['automod']} All automod violations will now result in: **{label}**",
            color=COLORS["success"],
        )
        await interaction.response.edit_message(embed=em, view=None)


class AutomodView(discord.ui.View):
    def __init__(self, guild_id: int, current_filters: set, author_id: int):
        super().__init__(timeout=120)
        self.author_id = author_id
        self.add_item(FilterSelect(guild_id, current_filters))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(f"{EMOJIS['denied']} Not your menu.", ephemeral=True)
            return False
        return True


class PunishmentView(discord.ui.View):
    def __init__(self, guild_id: int, author_id: int):
        super().__init__(timeout=60)
        self.author_id = author_id
        self.add_item(PunishmentSelect(guild_id))

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author_id:
            await interaction.response.send_message(f"{EMOJIS['denied']} Not your menu.", ephemeral=True)
            return False
        return True


class AutomodCog(commands.Cog):
    """Automod system — chat filtering and moderation for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    automod_group = app_commands.Group(
        name="automod", description="Manage the Zephyr automod system"
    )

    @automod_group.command(name="enable", description="Enable and configure automod filters")
    @app_commands.checks.has_permissions(administrator=True)
    async def automod_enable(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        current = self.bot.cache["automod"].get(guild.id, {})
        current_filters = current.get("filters", set())

        em = create_embed(

            description=(
                f"## {EMOJIS['automod']} Automod Setup\n{EMOJIS['settings']} Select the filters you want to enable.\n"
                f"{EMOJIS['info']} Each filter can be configured with its own punishment."
            ),
            color=COLORS["primary"],
        )

        view = AutomodView(guild.id, current_filters, interaction.user.id)
        await interaction.response.send_message(embed=em, view=view, ephemeral=True)

    @automod_group.command(name="disable", description="Disable the automod system")
    @app_commands.checks.has_permissions(administrator=True)
    async def automod_disable(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/automod.db") as db:
            await db.execute(
                "INSERT INTO automod (guild_id, enabled) VALUES (?, 0) ON CONFLICT(guild_id) DO UPDATE SET enabled = 0",
                (guild.id,),
            )
            await db.commit()

        self.bot.cache["automod"][guild.id] = {"enabled": False, "filters": set()}

        em = create_embed(

            description=f"## {EMOJIS['automod']} Automod Disabled\n{EMOJIS['warning']} All automod filters have been deactivated.",
            color=COLORS["warning"],
        )
        await interaction.response.send_message(embed=em, ephemeral=True)

    @automod_group.command(name="punishment", description="Set the punishment for automod violations")
    @app_commands.checks.has_permissions(administrator=True)
    async def automod_punishment(self, interaction: discord.Interaction):
        guild = interaction.guild
        if not guild:
            return

        em = create_embed(

            description=f"## {EMOJIS['settings']} Automod Punishment\n{EMOJIS['info']} Select the punishment to apply when a user triggers an automod filter.",
            color=COLORS["primary"],
        )

        view = PunishmentView(guild.id, interaction.user.id)
        await interaction.response.send_message(embed=em, view=view, ephemeral=True)

    @automod_group.command(name="ignore", description="Whitelist a channel or role from automod")
    @app_commands.describe(
        channel="Channel to whitelist (optional)",
        role="Role to whitelist (optional)",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def automod_ignore(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel | None = None,
        role: discord.Role | None = None,
    ):
        guild = interaction.guild
        if not guild:
            return

        if not channel and not role:
            em = create_embed(
                description=f"{EMOJIS['error']} Please specify a **channel** or **role** to whitelist.",
                color=COLORS["error"],
            )
            return await interaction.response.send_message(embed=em, ephemeral=True)

        async with aiosqlite.connect("db/automod.db") as db:
            if channel:
                await db.execute(
                    "INSERT OR IGNORE INTO automod_ignored (guild_id, type, id) VALUES (?, 'channel', ?)",
                    (guild.id, channel.id),
                )
            if role:
                await db.execute(
                    "INSERT OR IGNORE INTO automod_ignored (guild_id, type, id) VALUES (?, 'role', ?)",
                    (guild.id, role.id),
                )
            await db.commit()

        target = channel.mention if channel else role.mention  # type: ignore
        em = create_embed(

            description=f"## {EMOJIS['success']} Automod Ignore Added\n{EMOJIS['checkmark']} {target} is now exempt from all automod filters.",
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em, ephemeral=True)


async def setup(bot: Zephyr):
    await bot.add_cog(AutomodCog(bot))
    log.info("  ✓ AutomodCog loaded")
