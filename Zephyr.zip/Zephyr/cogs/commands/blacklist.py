"""
Word Blacklist + Global Blacklist
/blacklistword add/remove/config/bypass
/blacklist user/guild add/remove/show
DB: db/blword.db (blacklisted_words, blword_bypass)
DB: db/block.db (blocked_users, blocked_guilds)
"""
from __future__ import annotations
import logging
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.blacklist")

class BlacklistCog(commands.Cog):
    def __init__(self, bot: Zephyr):
        self.bot = bot

    blword = app_commands.Group(name="blacklistword", description="Word blacklist management")
    bl = app_commands.Group(name="blacklist", description="Global user/guild blacklist")

    # ── Word Blacklist ─────────────────────────────────────────
    @blword.command(name="add", description="Add a word to the blacklist")
    @app_commands.describe(word="Word/phrase to block")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def bw_add(self, it: discord.Interaction, word: str):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/blword.db") as db:
            await db.execute("INSERT OR IGNORE INTO blacklisted_words(guild_id,word) VALUES(?,?)",(g.id,word.lower()))
            await db.commit()
        self.bot.cache.setdefault("blacklisted_words",{}).setdefault(g.id,set()).add(word.lower())
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['success']} Word Added\n🚫 Added `{word}` to the word blacklist",color=COLORS["success"]))

    @blword.command(name="remove", description="Remove a word from the blacklist")
    @app_commands.describe(word="Word to unblock")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def bw_remove(self, it: discord.Interaction, word: str):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/blword.db") as db:
            await db.execute("DELETE FROM blacklisted_words WHERE guild_id=? AND word=?",(g.id,word.lower()))
            await db.commit()
        self.bot.cache.get("blacklisted_words",{}).get(g.id,set()).discard(word.lower())
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['success']} Word Removed\n✅ Removed `{word}` from the blacklist",color=COLORS["success"]))

    @blword.command(name="config", description="List all blacklisted words")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def bw_config(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        words = self.bot.cache.get("blacklisted_words",{}).get(g.id,set())
        if not words:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No blacklisted words.",color=COLORS["info"]),ephemeral=True)
        wl = ", ".join(f"`{w}`" for w in sorted(words))
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['automod']} Blacklisted Words\n{wl}",color=COLORS["primary"]),ephemeral=True)

    @blword.command(name="bypass", description="Add/remove user or role bypass for word blacklist")
    @app_commands.describe(action="Add or Remove",user="User to bypass",role="Role to bypass")
    @app_commands.choices(action=[app_commands.Choice(name="Add",value="add"),app_commands.Choice(name="Remove",value="remove")])
    @app_commands.checks.has_permissions(manage_guild=True)
    async def bw_bypass(self, it: discord.Interaction, action: app_commands.Choice[str], user: discord.Member | None = None, role: discord.Role | None = None):
        g = it.guild
        if not g: return
        if not user and not role:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Specify a user or role.",color=COLORS["error"]),ephemeral=True)
        # DB schema: blword_bypass(guild_id, type, id)
        async with aiosqlite.connect("db/blword.db") as db:
            if user:
                if action.value=="add":
                    await db.execute("INSERT OR IGNORE INTO blword_bypass(guild_id,type,id) VALUES(?,?,?)",(g.id,"user",user.id))
                else:
                    await db.execute("DELETE FROM blword_bypass WHERE guild_id=? AND type=? AND id=?",(g.id,"user",user.id))
            if role:
                if action.value=="add":
                    await db.execute("INSERT OR IGNORE INTO blword_bypass(guild_id,type,id) VALUES(?,?,?)",(g.id,"role",role.id))
                else:
                    await db.execute("DELETE FROM blword_bypass WHERE guild_id=? AND type=? AND id=?",(g.id,"role",role.id))
            await db.commit()
        target = user.mention if user else role.mention
        status = "**added to**" if action.value=='add' else "**removed from**"
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['success']} Bypass Updated\n{target} {status} word blacklist bypass",color=COLORS["success"]))

    @commands.Cog.listener()
    async def on_message(self, msg: discord.Message):
        if msg.author.bot or not msg.guild: return
        words = self.bot.cache.get("blacklisted_words",{}).get(msg.guild.id,set())
        if not words: return
        if isinstance(msg.author, discord.Member) and msg.author.guild_permissions.administrator: return
        content = msg.content.lower()
        for w in words:
            if w in content:
                try:
                    await msg.delete()
                    em = create_embed(description=f"🚫 {msg.author.mention}, that word is **blacklisted**.",color=COLORS["mod"])
                    warn = await msg.channel.send(embed=em)
                    import asyncio
                    await asyncio.sleep(3)
                    await warn.delete()
                except discord.HTTPException: pass
                return

    # ── Global Blacklist ───────────────────────────────────────
    @bl.command(name="user", description="Blacklist a user globally")
    @app_commands.describe(action="Add or Remove",user="User")
    @app_commands.choices(action=[app_commands.Choice(name="Add",value="add"),app_commands.Choice(name="Remove",value="remove"),app_commands.Choice(name="Show",value="show")])
    async def bl_user(self, it: discord.Interaction, action: app_commands.Choice[str], user: discord.User | None = None):
        if it.user.id not in it.client.owner_ids_set:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['denied']} Owner only.",color=COLORS["error"]),ephemeral=True)
        async with aiosqlite.connect("db/block.db") as db:
            if action.value=="show":
                async with db.execute("SELECT user_id FROM blocked_users") as c:
                    rows = await c.fetchall()
                desc = "\n".join(f"{EMOJIS['member']} <@{r[0]}>" for r in rows) if rows else "`None`"
                return await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['ban_hammer']} Blacklisted Users\n{desc}",color=COLORS["primary"]),ephemeral=True)
            if not user:
                return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Specify user.",color=COLORS["error"]),ephemeral=True)
            if action.value=="add":
                await db.execute("INSERT OR IGNORE INTO blocked_users(user_id) VALUES(?)",(user.id,))
                self.bot.cache["blocked_users"].add(user.id)
            else:
                await db.execute("DELETE FROM blocked_users WHERE user_id=?",(user.id,))
                self.bot.cache["blocked_users"].discard(user.id)
            await db.commit()
        status = "**blacklisted**" if action.value=='add' else "**unblacklisted**"
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['success']} User Updated\n{user.mention} has been {status}",color=COLORS["success"]),ephemeral=True)

    @bl.command(name="guild", description="Blacklist a guild globally")
    @app_commands.describe(action="Add or Remove",guild_id="Guild ID")
    @app_commands.choices(action=[app_commands.Choice(name="Add",value="add"),app_commands.Choice(name="Remove",value="remove")])
    async def bl_guild(self, it: discord.Interaction, action: app_commands.Choice[str], guild_id: str):
        if it.user.id not in it.client.owner_ids_set:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['denied']} Owner only.",color=COLORS["error"]),ephemeral=True)
        gid = int(guild_id)
        async with aiosqlite.connect("db/block.db") as db:
            if action.value=="add":
                await db.execute("INSERT OR IGNORE INTO blocked_guilds(guild_id) VALUES(?)",(gid,))
                self.bot.cache["blocked_guilds"].add(gid)
            else:
                await db.execute("DELETE FROM blocked_guilds WHERE guild_id=?",(gid,))
                self.bot.cache["blocked_guilds"].discard(gid)
            await db.commit()
        status = "**blacklisted**" if action.value=='add' else "**unblacklisted**"
        await it.response.send_message(embed=create_embed(description=f"## {EMOJIS['success']} Guild Updated\nGuild `{gid}` has been {status}",color=COLORS["success"]),ephemeral=True)

async def setup(bot):
    await bot.add_cog(BlacklistCog(bot))
    log.info("  ✓ BlacklistCog loaded")
