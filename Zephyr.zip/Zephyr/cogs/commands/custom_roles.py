"""
Custom Roles — /customrole setup/create/delete/list/reqrole
Predefined role "slots" (Staff, VIP, etc.) + custom prefix commands.
DB: db/customrole.db — tables: roles (slots), custom_roles (guild_id, cmd_name, role_id)
"""
from __future__ import annotations
import logging
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.customroles")

SLOT_COLUMNS = ["staff", "girl", "vip", "guest", "frnd", "reqrole"]

class CustomRolesCog(commands.Cog):
    """Custom role management system for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    cr = app_commands.Group(name="customrole", description="Custom role management")

    @cr.command(name="setup", description="Configure a role slot (staff/vip/etc)")
    @app_commands.describe(slot="Slot type", role="Role to assign to this slot")
    @app_commands.choices(slot=[app_commands.Choice(name=s.title(), value=s) for s in SLOT_COLUMNS if s != "reqrole"])
    @app_commands.checks.has_permissions(administrator=True)
    async def cr_setup(self, it: discord.Interaction, slot: app_commands.Choice[str], role: discord.Role):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/customrole.db") as db:
            # Upsert into roles table
            await db.execute(f"""
                INSERT INTO roles (guild_id, {slot.value}) VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET {slot.value} = ?
            """, (g.id, role.id, role.id))
            await db.commit()
        self.bot.cache.setdefault("role_slots", {}).setdefault(g.id, {})[slot.value] = role.id
        await it.response.send_message(embed=create_embed(
            description=f"{EMOJIS['success']} **{slot.name}** slot set to {role.mention}.",
            color=COLORS["success"],
        ))

    @cr.command(name="reqrole", description="Set the required role to use custom role commands")
    @app_commands.describe(role="Role required to use custom role commands")
    @app_commands.checks.has_permissions(administrator=True)
    async def cr_reqrole(self, it: discord.Interaction, role: discord.Role):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/customrole.db") as db:
            await db.execute("""
                INSERT INTO roles (guild_id, reqrole) VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET reqrole = ?
            """, (g.id, role.id, role.id))
            await db.commit()
        self.bot.cache.setdefault("role_slots", {}).setdefault(g.id, {})["reqrole"] = role.id
        await it.response.send_message(embed=create_embed(
            description=f"{EMOJIS['success']} Required role set to {role.mention}.",
            color=COLORS["success"],
        ))

    @cr.command(name="create", description="Create a custom role command")
    @app_commands.describe(name="Command name (no spaces)", role="Role to assign")
    @app_commands.checks.has_permissions(administrator=True)
    async def cr_create(self, it: discord.Interaction, name: str, role: discord.Role):
        g = it.guild
        if not g: return
        if " " in name:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Name cannot contain spaces.", color=COLORS["error"]), ephemeral=True)

        async with aiosqlite.connect("db/customrole.db") as db:
            async with db.execute("SELECT COUNT(*) FROM custom_roles WHERE guild_id=?", (g.id,)) as c:
                cnt = (await c.fetchone())[0]
            if cnt >= 25:
                return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Max 25 custom role commands.", color=COLORS["error"]), ephemeral=True)
            await db.execute(
                "INSERT OR REPLACE INTO custom_roles(guild_id,cmd_name,role_id) VALUES(?,?,?)",
                (g.id, name.lower(), role.id),
            )
            await db.commit()

        self.bot.cache.setdefault("custom_role_cmds", {}).setdefault(g.id, {})[name.lower()] = role.id
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Custom command `{name}` created → {role.mention}", color=COLORS["success"]))

    @cr.command(name="delete", description="Delete a custom role command")
    @app_commands.describe(name="Command name to delete")
    @app_commands.checks.has_permissions(administrator=True)
    async def cr_delete(self, it: discord.Interaction, name: str):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/customrole.db") as db:
            await db.execute("DELETE FROM custom_roles WHERE guild_id=? AND cmd_name=?", (g.id, name.lower()))
            await db.commit()
        self.bot.cache.get("custom_role_cmds", {}).get(g.id, {}).pop(name.lower(), None)
        await it.response.send_message(embed=create_embed(description=f"{EMOJIS['success']} Custom command `{name}` deleted.", color=COLORS["success"]))

    @cr.command(name="list", description="List all custom role commands and slots")
    async def cr_list(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        slots = self.bot.cache.get("role_slots", {}).get(g.id, {})
        cmds = self.bot.cache.get("custom_role_cmds", {}).get(g.id, {})

        desc_parts = []
        if slots:
            desc_parts.append("**Role Slots:**")
            for s, rid in slots.items():
                if s == "reqrole":
                    desc_parts.append(f"{EMOJIS['role']} **Required Role** → <@&{rid}>")
                else:
                    desc_parts.append(f"{EMOJIS['role']} **{s.title()}** → <@&{rid}>")
        if cmds:
            desc_parts.append("\n**Custom Commands:**")
            for n, rid in cmds.items():
                desc_parts.append(f"{EMOJIS['dot']} `{n}` → <@&{rid}>")

        if not desc_parts:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No custom roles configured.", color=COLORS["info"]), ephemeral=True)

        em = create_embed(description=f"## {EMOJIS['role']} Custom Roles\n" + "\n".join(desc_parts), color=COLORS["primary"])
        await it.response.send_message(embed=em)

    # ── Prefix command handler for custom role commands ────────
    @commands.Cog.listener()
    async def on_message(self, msg: discord.Message):
        if msg.author.bot or not msg.guild: return
        prefix = self.bot.cache["prefixes"].get(msg.guild.id, self.bot._default_prefix)
        if not msg.content.startswith(prefix): return

        cmd_name = msg.content[len(prefix):].split()[0].lower()
        cmds = self.bot.cache.get("custom_role_cmds", {}).get(msg.guild.id, {})
        role_id = cmds.get(cmd_name)
        if role_id is None: return

        member = msg.author
        if not isinstance(member, discord.Member): return

        # Check required role
        slots = self.bot.cache.get("role_slots", {}).get(msg.guild.id, {})
        reqrole_id = slots.get("reqrole")
        if reqrole_id:
            req_role = msg.guild.get_role(reqrole_id)
            if req_role and req_role not in member.roles:
                em = create_embed(description=f"{EMOJIS['denied']} You need {req_role.mention} to use this command.", color=COLORS["error"])
                return await msg.channel.send(embed=em, delete_after=5)

        role = msg.guild.get_role(role_id)
        if not role:
            return await msg.channel.send(embed=create_embed(description=f"{EMOJIS['error']} Role not found.", color=COLORS["error"]), delete_after=5)

        # Toggle role
        if role in member.roles:
            await member.remove_roles(role, reason=f"Zephyr Custom Role — {cmd_name}")
            em = create_embed(description=f"{EMOJIS['success']} Removed {role.mention}.", color=COLORS["success"])
        else:
            await member.add_roles(role, reason=f"Zephyr Custom Role — {cmd_name}")
            em = create_embed(description=f"{EMOJIS['success']} Granted {role.mention}.", color=COLORS["success"])

        await msg.channel.send(embed=em, delete_after=5)

async def setup(bot):
    await bot.add_cog(CustomRolesCog(bot))
    log.info("  ✓ CustomRolesCog loaded")
