"""
No-Prefix (NP) System — Prefix-only, Owner-only
$np add <user> <duration>  |  $np remove <user>  |  $np list
Only bot owners (from config) can use these commands.
DB: db/np.db — table: np_users (user_id, expires_at)
"""
from __future__ import annotations
import logging, time
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed, parse_duration
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.np")

DURATION_MAP = {
    "10m": ("10 Minutes", "10m"),
    "1h":  ("1 Hour", "1h"),
    "1d":  ("1 Day", "1d"),
    "7d":  ("1 Week", "7d"),
    "30d": ("1 Month", "30d"),
    "60d": ("2 Months", "60d"),
    "lifetime": ("Lifetime", "lifetime"),
}


def _is_owner(ctx: commands.Context) -> bool:
    """Check if the user is a bot owner."""
    return ctx.author.id in ctx.bot.owner_ids_set


class NoPrefixCog(commands.Cog):
    """No-Prefix system — Owner-only, prefix-only commands."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    @commands.group(name="np", invoke_without_command=True, brief="No-Prefix management")
    async def np_group(self, ctx: commands.Context):
        if not _is_owner(ctx):
            return
        em = create_embed(
            description=(
                f"## ⚡ No-Prefix System\n"
                f"`$np add <user> <duration>` — Grant NP access\n"
                f"`$np remove <user>` — Revoke NP access\n"
                f"`$np list` — List all NP users\n\n"
                f"-# Durations: `10m` `1h` `1d` `7d` `30d` `60d` `lifetime`"
            ),
            color=COLORS["premium"],
        )
        await ctx.send(embed=em)

    @np_group.command(name="add", brief="Grant NP access")
    async def np_add(self, ctx: commands.Context, user: discord.User, duration: str = "lifetime"):
        if not _is_owner(ctx):
            return

        dur_key = duration.lower()
        if dur_key not in DURATION_MAP:
            return await ctx.send(embed=create_embed(
                description=f"{EMOJIS['error']} Invalid duration `{duration}`\n-# Valid: `10m` `1h` `1d` `7d` `30d` `60d` `lifetime`",
                color=COLORS["error"],
            ))

        label, _ = DURATION_MAP[dur_key]

        if dur_key == "lifetime":
            expires_at = None
        else:
            seconds = parse_duration(dur_key)
            if not seconds:
                return await ctx.send(embed=create_embed(
                    description=f"{EMOJIS['error']} Could not parse duration.",
                    color=COLORS["error"],
                ))
            expires_at = time.time() + seconds

        async with aiosqlite.connect("db/np.db") as db:
            await db.execute("INSERT OR REPLACE INTO np_users(user_id, expires_at) VALUES(?,?)", (user.id, expires_at))
            await db.commit()
        self.bot.cache["np_users"][user.id] = expires_at

        em = create_embed(
            description=(
                f"## ⚡ No-Prefix Granted\n"
                f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                f"⏱️ **Duration:** `{label}`\n"
                f"-# They can now use commands without prefix"
            ),
            color=COLORS["premium"],
        )
        await ctx.send(embed=em)

    @np_group.command(name="remove", brief="Revoke NP access")
    async def np_remove(self, ctx: commands.Context, user: discord.User):
        if not _is_owner(ctx):
            return

        async with aiosqlite.connect("db/np.db") as db:
            await db.execute("DELETE FROM np_users WHERE user_id=?", (user.id,))
            await db.commit()
        self.bot.cache["np_users"].pop(user.id, None)

        em = create_embed(
            description=(
                f"## ⚡ No-Prefix Revoked\n"
                f"{EMOJIS['member']} {user.mention} no longer has NP access"
            ),
            color=COLORS["success"],
        )
        await ctx.send(embed=em)

    @np_group.command(name="list", brief="List all NP users")
    async def np_list(self, ctx: commands.Context):
        if not _is_owner(ctx):
            return

        np_users = self.bot.cache.get("np_users", {})
        if not np_users:
            return await ctx.send(embed=create_embed(
                description=f"{EMOJIS['info']} No users have no-prefix access.",
                color=COLORS["info"],
            ))

        now = time.time()
        lines = []
        for uid, expires_at in np_users.items():
            if expires_at is None:
                exp_str = "`Lifetime`"
            elif expires_at > now:
                exp_str = f"<t:{int(expires_at)}:R>"
            else:
                exp_str = "~~Expired~~"
            lines.append(f"⚡ <@{uid}> — {exp_str}")

        em = create_embed(
            description=f"## ⚡ No-Prefix Users — `{len(lines)}`\n" + "\n".join(lines[:25]),
            color=COLORS["premium"],
        )
        await ctx.send(embed=em)


async def setup(bot: Zephyr):
    await bot.add_cog(NoPrefixCog(bot))
    log.info("  ✓ NoPrefixCog loaded")
