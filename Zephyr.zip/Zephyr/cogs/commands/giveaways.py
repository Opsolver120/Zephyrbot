"""
Giveaway System — /giveaway start, /giveaway end, /giveaway reroll, /giveaway list
Full giveaway management with button entries.
Max 15 winners, 5 concurrent giveaways per guild.
DB: db/giveaways.db — tables:
  giveaways (guild_id, host_id, start_time, ends_at, prize, winners, message_id, channel_id, ended)
  giveaway_entries (guild_id, message_id, user_id) — added by this cog
"""
from __future__ import annotations
import logging, random, time, asyncio
from typing import TYPE_CHECKING
import aiosqlite, discord
from discord import app_commands
from discord.ext import commands, tasks
from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed, parse_duration, format_duration
if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.giveaways")
MAX_WINNERS = 15
MAX_CONCURRENT = 5


class GiveawayButton(discord.ui.Button):
    def __init__(self, guild_id: int, message_id: int, entries: int = 0):
        super().__init__(style=discord.ButtonStyle.primary, label=f"🎉 Enter ({entries})", custom_id=f"giveaway:{guild_id}:{message_id}")
        self._guild_id = guild_id
        self._message_id = message_id

    async def callback(self, interaction: discord.Interaction):
        async with aiosqlite.connect("db/giveaways.db") as db:
            async with db.execute("SELECT 1 FROM giveaway_entries WHERE guild_id=? AND message_id=? AND user_id=?", (self._guild_id, self._message_id, interaction.user.id)) as cur:
                if await cur.fetchone():
                    return await interaction.response.send_message(f"{EMOJIS['error']} You have already entered this giveaway!", ephemeral=True)
            await db.execute("INSERT INTO giveaway_entries (guild_id, message_id, user_id) VALUES (?, ?, ?)", (self._guild_id, self._message_id, interaction.user.id))
            async with db.execute("SELECT COUNT(*) FROM giveaway_entries WHERE guild_id=? AND message_id=?", (self._guild_id, self._message_id)) as cur:
                count = (await cur.fetchone())[0]
            await db.commit()
        self.label = f"🎉 Enter ({count})"
        await interaction.response.edit_message(view=self.view)
        await interaction.followup.send(f"{EMOJIS['a_confetti']} You have entered the giveaway!", ephemeral=True)


class GiveawayView(discord.ui.View):
    def __init__(self, guild_id: int, message_id: int, entries: int = 0):
        super().__init__(timeout=None)
        self.add_item(GiveawayButton(guild_id, message_id, entries))


class GiveawayCog(commands.Cog):
    """Giveaway system for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot
        self.check_giveaways.start()

    def cog_unload(self):
        self.check_giveaways.cancel()

    async def cog_load(self):
        """Ensure giveaway_entries table exists."""
        async with aiosqlite.connect("db/giveaways.db") as db:
            await db.execute("""CREATE TABLE IF NOT EXISTS giveaway_entries (
                guild_id INTEGER,
                message_id INTEGER,
                user_id INTEGER,
                PRIMARY KEY (guild_id, message_id, user_id)
            )""")
            await db.commit()

    giveaway = app_commands.Group(name="giveaway", description="Giveaway management")

    @giveaway.command(name="start", description="Start a new giveaway")
    @app_commands.describe(prize="What you're giving away", duration="Duration (e.g. 1h, 30m, 1d)", winners="Number of winners (max 15)", channel="Channel to host the giveaway in")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def giveaway_start(self, it: discord.Interaction, prize: str, duration: str, winners: int = 1, channel: discord.TextChannel | None = None):
        guild = it.guild
        if not guild: return

        if winners > MAX_WINNERS:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Maximum {MAX_WINNERS} winners.", color=COLORS["error"]), ephemeral=True)

        async with aiosqlite.connect("db/giveaways.db") as db:
            async with db.execute("SELECT COUNT(*) FROM giveaways WHERE guild_id=? AND ended=0", (guild.id,)) as c:
                active_count = (await c.fetchone())[0]
        if active_count >= MAX_CONCURRENT:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Maximum {MAX_CONCURRENT} active giveaways per server.", color=COLORS["error"]), ephemeral=True)

        seconds = parse_duration(duration)
        if not seconds:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['error']} Invalid duration. Use `1h`, `30m`, `1d`, etc.", color=COLORS["error"]), ephemeral=True)

        target = channel or it.channel
        if not isinstance(target, discord.TextChannel): return
        now = time.time()
        ends_at = now + seconds

        em = create_embed(

            description=(
                f"## {EMOJIS['a_giveaway']} GIVEAWAY {EMOJIS['a_giveaway']}\n{EMOJIS['a_gift']} **Prize:** {prize}\n"
                f"{EMOJIS['member']} **Winners:** {winners}\n"
                f"{EMOJIS['a_clock']} **Ends:** <t:{int(ends_at)}:R>\n"
                f"{EMOJIS['owner']} **Hosted by:** {it.user.mention}\n\n"
                f"Click the button below to enter! {EMOJIS['a_confetti']}"
            ),
            color=COLORS["premium"],
        )

        # Send message first to get message_id, then pass it to view
        msg = await target.send(embed=em)
        view = GiveawayView(guild.id, msg.id)
        await msg.edit(view=view)

        async with aiosqlite.connect("db/giveaways.db") as db:
            await db.execute(
                "INSERT INTO giveaways (guild_id, host_id, start_time, ends_at, prize, winners, message_id, channel_id, ended) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)",
                (guild.id, it.user.id, now, ends_at, prize, winners, msg.id, target.id),
            )
            await db.commit()

        confirm = create_embed(description=f"{EMOJIS['success']} Giveaway started in {target.mention}! Ends <t:{int(ends_at)}:R>", color=COLORS["success"])
        await it.response.send_message(embed=confirm, ephemeral=True)

    @giveaway.command(name="end", description="End a giveaway early")
    @app_commands.describe(message_id="The giveaway message ID")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def giveaway_end(self, it: discord.Interaction, message_id: str):
        await it.response.defer(ephemeral=True)
        await self._end_giveaway(int(message_id), it.guild)  # type: ignore
        await it.followup.send(embed=create_embed(description=f"{EMOJIS['success']} Giveaway ended!", color=COLORS["success"]), ephemeral=True)

    @giveaway.command(name="reroll", description="Reroll winners for a giveaway")
    @app_commands.describe(message_id="The giveaway message ID")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def giveaway_reroll(self, it: discord.Interaction, message_id: str):
        await it.response.defer(ephemeral=True)
        mid = int(message_id)
        async with aiosqlite.connect("db/giveaways.db") as db:
            async with db.execute("SELECT channel_id, prize, winners FROM giveaways WHERE guild_id=? AND message_id=?", (it.guild.id, mid)) as cur:
                row = await cur.fetchone()
            if not row:
                return await it.followup.send(embed=create_embed(description=f"{EMOJIS['error']} Giveaway not found.", color=COLORS["error"]), ephemeral=True)
            ch_id, prize, num_winners = row
            async with db.execute("SELECT user_id FROM giveaway_entries WHERE guild_id=? AND message_id=?", (it.guild.id, mid)) as cur:
                entries = [r[0] for r in await cur.fetchall()]
        if not entries:
            return await it.followup.send(embed=create_embed(description=f"{EMOJIS['error']} No entries found.", color=COLORS["error"]), ephemeral=True)
        winners = random.sample(entries, min(num_winners, len(entries)))
        winner_mentions = ", ".join(f"<@{w}>" for w in winners)
        channel = it.guild.get_channel(ch_id)
        if channel and isinstance(channel, discord.TextChannel):
            em = create_embed(description=f"## {EMOJIS['a_confetti']} Giveaway Rerolled!\n{EMOJIS['a_gift']} **Prize:** {prize}\n{EMOJIS['a_star']} **New Winner(s):** {winner_mentions}", color=COLORS["gold"])
            await channel.send(embed=em)
        await it.followup.send(embed=create_embed(description=f"{EMOJIS['success']} Rerolled! Winners: {winner_mentions}", color=COLORS["success"]), ephemeral=True)

    @giveaway.command(name="list", description="List all active giveaways in this server")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def giveaway_list(self, it: discord.Interaction):
        g = it.guild
        if not g: return
        async with aiosqlite.connect("db/giveaways.db") as db:
            async with db.execute("SELECT message_id, channel_id, prize, winners, ends_at, host_id FROM giveaways WHERE guild_id=? AND ended=0 ORDER BY ends_at", (g.id,)) as c:
                rows = await c.fetchall()
        if not rows:
            return await it.response.send_message(embed=create_embed(description=f"{EMOJIS['info']} No active giveaways.", color=COLORS["info"]), ephemeral=True)
        lines = []
        for mid, cid, prize, w, et, hid in rows:
            lines.append(f"{EMOJIS['a_gift']} **{prize}** in <#{cid}>\n{EMOJIS['member']} {w} winner(s) • Ends <t:{int(et)}:R> • [Jump](https://discord.com/channels/{g.id}/{cid}/{mid})")
        em = create_embed(description=f"## {EMOJIS['a_giveaway']} Active Giveaways [{len(rows)}]\n" + "\n\n".join(lines), color=COLORS["premium"])
        await it.response.send_message(embed=em, ephemeral=True)

    async def _end_giveaway(self, message_id: int, guild: discord.Guild):
        """End a giveaway and announce winners."""
        async with aiosqlite.connect("db/giveaways.db") as db:
            async with db.execute("SELECT channel_id, prize, winners, host_id FROM giveaways WHERE guild_id=? AND message_id=? AND ended=0", (guild.id, message_id)) as cur:
                row = await cur.fetchone()
            if not row: return
            ch_id, prize, num_winners, host_id = row
            async with db.execute("SELECT user_id FROM giveaway_entries WHERE guild_id=? AND message_id=?", (guild.id, message_id)) as cur:
                entries = [r[0] for r in await cur.fetchall()]
            await db.execute("UPDATE giveaways SET ended = 1 WHERE guild_id=? AND message_id=?", (guild.id, message_id))
            await db.commit()
        channel = guild.get_channel(ch_id)
        if not channel or not isinstance(channel, discord.TextChannel): return
        if not entries:
            em = create_embed(description=f"## {EMOJIS['a_giveaway']} Giveaway Ended\n{EMOJIS['a_gift']} **Prize:** {prize}\n{EMOJIS['error']} No one entered the giveaway.", color=COLORS["error"])
            await channel.send(embed=em)
            return
        winners = random.sample(entries, min(num_winners, len(entries)))
        winner_mentions = ", ".join(f"<@{w}>" for w in winners)
        em = create_embed(

            description=f"## {EMOJIS['a_confetti']} Giveaway Ended! {EMOJIS['a_confetti']}\n{EMOJIS['a_gift']} **Prize:** {prize}\n{EMOJIS['a_star']} **Winner(s):** {winner_mentions}\n{EMOJIS['owner']} **Hosted by:** <@{host_id}>",
            color=COLORS["gold"],
        )
        await channel.send(content=winner_mentions, embed=em)

    @tasks.loop(seconds=5)
    async def check_giveaways(self):
        """Check for ended giveaways every 5 seconds."""
        now = time.time()
        async with aiosqlite.connect("db/giveaways.db") as db:
            async with db.execute("SELECT message_id, guild_id FROM giveaways WHERE ended = 0 AND ends_at <= ?", (now,)) as cur:
                rows = await cur.fetchall()
        for msg_id, guild_id in rows:
            guild = self.bot.get_guild(guild_id)
            if guild:
                try: await self._end_giveaway(msg_id, guild)
                except Exception as e: log.error(f"Error ending giveaway {msg_id}: {e}")

    @check_giveaways.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()


async def setup(bot: Zephyr):
    await bot.add_cog(GiveawayCog(bot))
    log.info("  ✓ GiveawayCog loaded")
