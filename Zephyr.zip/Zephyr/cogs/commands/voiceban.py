"""
Voice Ban — /voice ban, /voice unban
Prevents specific users from joining any voice channel.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import aiosqlite
import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.voiceban")


class VoiceBanCog(commands.Cog):
    """Voice Ban system — prevent users from joining voice channels."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    vban = app_commands.Group(name="voiceban", description="Voice ban management")

    @vban.command(name="ban", description="Ban a user from all voice channels")
    @app_commands.describe(user="User to voice ban")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def vb_ban(self, interaction: discord.Interaction, user: discord.Member):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/voiceban.db") as db:
            await db.execute(
                "INSERT OR IGNORE INTO voicebans (guild_id, user_id) VALUES (?, ?)",
                (guild.id, user.id),
            )
            await db.commit()

        self.bot.cache["voice_bans"].setdefault(guild.id, set()).add(user.id)

        # Disconnect if in VC
        if user.voice:
            try:
                await user.move_to(None, reason="Zephyr — Voice banned")
            except discord.HTTPException:
                pass

        em = create_embed(
            description=(
                f"## {EMOJIS['ban_hammer']} Voice Banned\n"
                f"{EMOJIS['member']} **User:** {user.mention} (`{user.id}`)\n"
                f"{EMOJIS['info']} They will be **instantly disconnected** if they join any voice channel\n"
                f"-# Moderator: {interaction.user.mention}"
            ),
            color=COLORS["mod"],
        )
        await interaction.response.send_message(embed=em)

    @vban.command(name="unban", description="Remove a voice ban from a user")
    @app_commands.describe(user="User to unban")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def vb_unban(self, interaction: discord.Interaction, user: discord.Member):
        guild = interaction.guild
        if not guild:
            return

        async with aiosqlite.connect("db/voiceban.db") as db:
            await db.execute(
                "DELETE FROM voicebans WHERE guild_id = ? AND user_id = ?",
                (guild.id, user.id),
            )
            await db.commit()

        bans = self.bot.cache["voice_bans"].get(guild.id, set())
        bans.discard(user.id)

        em = create_embed(
            description=f"## {EMOJIS['success']} Voice Unbanned\n{EMOJIS['member']} {user.mention} has been **voice unbanned**\n-# Moderator: {interaction.user.mention}",
            color=COLORS["success"],
        )
        await interaction.response.send_message(embed=em)

    @commands.Cog.listener()
    async def on_voice_state_update(
        self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState
    ):
        """Instantly disconnect voice-banned users."""
        if after.channel is None:
            return

        bans = self.bot.cache["voice_bans"].get(member.guild.id, set())
        if member.id not in bans:
            return

        try:
            await member.move_to(None, reason="Zephyr — Voice banned user attempted to join")
        except discord.HTTPException:
            pass

        try:
            em = discord.Embed(
                description=f"{EMOJIS['denied']} You are **voice banned** from **{member.guild.name}**! 😜",
                color=COLORS["error"],
            )
            await member.send(embed=em)
        except discord.HTTPException:
            pass


async def setup(bot: Zephyr):
    await bot.add_cog(VoiceBanCog(bot))
    log.info("  ✓ VoiceBanCog loaded")
