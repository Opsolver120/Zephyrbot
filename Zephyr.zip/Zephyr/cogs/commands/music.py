import math
import re
import discord
from discord.ext import commands, tasks
from discord import app_commands
import lavalink

URL_RX = re.compile(r"https?://(?:www\.)?.+")


class LavalinkVoiceClient(discord.VoiceClient):
    """Bridges discord.py VoiceClient ↔ lavalink.py 5.x with correct channelId handling."""

    def __init__(self, client: discord.Client, channel: discord.abc.Connectable):
        self.client = client
        self.channel = channel

    @property
    def lavalink(self) -> lavalink.Client:
        return self.client.lavalink

    async def on_voice_server_update(self, data):
        await self.lavalink.voice_update_handler({"t": "VOICE_SERVER_UPDATE", "d": data})

    async def on_voice_state_update(self, data):
        await self.lavalink.voice_update_handler({"t": "VOICE_STATE_UPDATE", "d": data})

    async def connect(self, *, timeout: float, reconnect: bool,
                      self_deaf: bool = True, self_mute: bool = False):
        self.lavalink.player_manager.create(guild_id=self.channel.guild.id)
        await self.channel.guild.change_voice_state(
            channel=self.channel, self_mute=self_mute, self_deaf=self_deaf
        )

    async def disconnect(self, *, force: bool = False):
        player = self.lavalink.player_manager.get(self.channel.guild.id)
        if player:
            if not force and not player.is_connected:
                return
            player.channel_id = None
            
        try:
            await self.channel.guild.change_voice_state(channel=None)
        except Exception:
            pass
            
        self.cleanup()


def _np_embed(player: lavalink.DefaultPlayer) -> discord.Embed:
    track = player.current
    if not track:
        return discord.Embed(
            title="✨ No Active Playback",
            description="The queue is currently empty. Add some tracks with `/play`!",
            color=0x2b2d31
        )
        
    duration = track.duration
    position = player.position
    
    # Format times helper
    def format_ms(ms):
        if not ms: return "0:00"
        s = ms // 1000
        m, s = divmod(s, 60)
        h, m = divmod(m, 60)
        if h: return f"{h}:{m:02d}:{s:02d}"
        return f"{m}:{s:02d}"

    pos_str = format_ms(position)
    dur_str = format_ms(duration) if not track.stream else "LIVE"

    # Progress Bar UI
    bar_length = 15
    if track.stream or duration == 0:
        bar = "▬" * bar_length
    else:
        percent = position / duration
        filled = int(percent * bar_length)
        bar = "▬" * filled + "🔘" + "▬" * max(0, bar_length - filled - 1)

    progress_str = f"`{pos_str}` {bar} `{dur_str}`"

    embed = discord.Embed(
        title="🎧 Now Playing",
        description=f"**[{track.title}]({track.uri})**\nby **{track.author or 'Unknown Artist'}**\n\n{progress_str}",
        color=0x2b2d31,
    )
    if track.artwork_url:
        embed.set_thumbnail(url=track.artwork_url)
    
    requester = f"<@{track.requester}>" if hasattr(track, 'requester') and track.requester else "Unknown"
    
    embed.add_field(name="👤 Requested By", value=requester, inline=True)
    embed.add_field(name="📻 Autoplay", value="Enabled" if player.fetch("autoplay", False) else "Disabled", inline=True)
    embed.set_footer(text=f"Volume: {player.volume}% • Loop: {'On' if player.loop else 'Off'} • Shuffle: {'On' if player.shuffle else 'Off'}")
    
    return embed


class PlayerView(discord.ui.View):
    def __init__(self, player: lavalink.DefaultPlayer):
        super().__init__(timeout=None)
        self.player = player
        self.update_buttons()

    def update_buttons(self):
        # Dynamically change the Play/Pause emoji style
        self.children[2].emoji = "▶️" if self.player.paused else "⏸️"
        self.children[2].style = discord.ButtonStyle.secondary if self.player.paused else discord.ButtonStyle.success

        # Toggle button styles based on state
        self.children[5].style = discord.ButtonStyle.success if self.player.loop else discord.ButtonStyle.secondary
        self.children[6].style = discord.ButtonStyle.success if self.player.shuffle else discord.ButtonStyle.secondary
        self.children[7].style = discord.ButtonStyle.success if self.player.fetch("autoplay", False) else discord.ButtonStyle.secondary

    async def update_msg(self, interaction: discord.Interaction):
        if not self.player or not self.player.is_connected:
            return
        self.update_buttons()
        embed = _np_embed(self.player)
        try:
            await interaction.response.edit_message(embed=embed, view=self)
        except discord.errors.InteractionResponded:
            await interaction.message.edit(embed=embed, view=self)
            
    async def on_error(self, interaction: discord.Interaction, error: Exception, item: discord.ui.Item):
        try:
            await interaction.response.send_message(f"❌ Error: {error}", ephemeral=True)
        except:
            if not interaction.response.is_done():
                await interaction.response.defer()

    # --- ROW 0: Media Controls ---
    @discord.ui.button(emoji="🔉", style=discord.ButtonStyle.secondary, row=0)
    async def btn_voldown(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        vol = max(0, self.player.volume - 10)
        await self.player.set_volume(vol)
        await self.update_msg(interaction)

    @discord.ui.button(emoji="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def btn_prev(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        await self.player.seek(0)
        await self.update_msg(interaction)

    @discord.ui.button(emoji="⏸️", style=discord.ButtonStyle.success, row=0)
    async def btn_playpause(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        await self.player.set_pause(not self.player.paused)
        await self.update_msg(interaction)

    @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary, row=0)
    async def btn_skip(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        await self.player.skip()
        if not interaction.response.is_done():
            await interaction.response.defer()
        else:
            await self.update_msg(interaction)

    @discord.ui.button(emoji="🔊", style=discord.ButtonStyle.secondary, row=0)
    async def btn_volup(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        vol = min(100, self.player.volume + 10)
        await self.player.set_volume(vol)
        await self.update_msg(interaction)

    # --- ROW 1: Toggles & Utilities ---
    @discord.ui.button(label="Loop", emoji="🔁", style=discord.ButtonStyle.secondary, row=1)
    async def btn_loop(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        new_loop = 1 if self.player.loop == 0 else 0
        self.player.set_loop(new_loop)
        await self.update_msg(interaction)

    @discord.ui.button(label="Shuffle", emoji="🔀", style=discord.ButtonStyle.secondary, row=1)
    async def btn_shuffle(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        self.player.set_shuffle(not self.player.shuffle)
        await self.update_msg(interaction)
        
    @discord.ui.button(label="Autoplay", emoji="📻", style=discord.ButtonStyle.secondary, row=1)
    async def btn_autoplay(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        ap = self.player.fetch("autoplay", False)
        self.player.store("autoplay", not ap)
        await self.update_msg(interaction)

    @discord.ui.button(label="Stop", emoji="⏹️", style=discord.ButtonStyle.danger, row=1)
    async def btn_stop(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        self.player.queue.clear()
        await self.player.stop()
        embed = discord.Embed(title="⏹️ Playback Stopped", description="Queue cleared and playback stopped.", color=0xE74C3C)
        for child in self.children:
            child.disabled = True
        try:
            await interaction.response.edit_message(embed=embed, view=self)
        except discord.errors.InteractionResponded:
            await interaction.message.edit(embed=embed, view=self)


class Music(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # NOTE: bot.lavalink does NOT exist yet at cog load time.
        # Event hooks are registered in bot.on_ready() after lavalink is created.
        self.dashboard_updater.start()

    async def cog_unload(self):
        self.dashboard_updater.cancel()

    @tasks.loop(seconds=2)
    async def dashboard_updater(self):
        if not hasattr(self.bot, "lavalink"):
            return
            
        for player in self.bot.lavalink.player_manager.players.values():
            if player.is_playing and not player.paused:
                guild = self.bot.get_guild(player.guild_id)
                if not guild: continue
                channel_id = player.fetch("channel")
                msg_id = player.fetch("np_message")
                
                if channel_id and msg_id:
                    channel = guild.get_channel(channel_id)
                    if channel:
                        try:
                            msg = channel.get_partial_message(msg_id)
                            # To save UI resources, we only update the embed and not the view here
                            embed = _np_embed(player)
                            await msg.edit(embed=embed)
                        except discord.NotFound:
                            player.store("np_message", None)
                        except discord.HTTPException:
                            pass

    @dashboard_updater.before_loop
    async def before_dashboard_updater(self):
        await self.bot.wait_until_ready()

    def _lavalink(self) -> lavalink.Client:
        """Safe accessor — raises a clear error if lavalink isn't ready yet."""
        if not hasattr(self.bot, "lavalink"):
            raise RuntimeError("Lavalink not initialized yet — wait for on_ready.")
        return self.bot.lavalink

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.id != self.bot.user.id:
            return
        if not hasattr(self.bot, "lavalink"):
            return
            
        # Bot was disconnected from the voice channel (e.g., forcefully kicked)
        if before.channel and not after.channel:
            player = self.bot.lavalink.player_manager.get(member.guild.id)
            if player:
                player.queue.clear()
                await player.stop()
                await self.bot.lavalink.player_manager.destroy(member.guild.id)
                
            vc = member.guild.voice_client
            if vc:
                try:
                    await vc.disconnect(force=True)
                except Exception:
                    pass
                if getattr(vc, 'cleanup', None):
                    vc.cleanup()

    @lavalink.listener(lavalink.events.TrackEndEvent)
    async def on_track_end(self, event: lavalink.events.TrackEndEvent):
        if event.track:
            event.player.store("last_track", event.track)
            history = event.player.fetch("history", [])
            history.append(getattr(event.track, 'identifier', ''))
            event.player.store("history", history[-50:])

    @lavalink.listener(lavalink.events.QueueEndEvent)
    async def on_queue_end(self, event: lavalink.events.QueueEndEvent):
        if event.player.fetch("autoplay", False):
            last_track = event.player.fetch("last_track")
            if last_track:
                # 1. Try Spotify Recommendations if source is Spotify (LavaSrc feature)
                if getattr(last_track, "source_name", "") == "spotify":
                    query = f"sprec:seed_tracks={last_track.identifier}"
                else:
                    # 2. Fallback to a broader search to avoid playing the exact same singer endlessly
                    query = f"spsearch:{last_track.title} {last_track.author} mix"
                
                results = await event.player.node.get_tracks(query)
                
                # 3. If the broader search or sprec fails to return tracks, fallback to the old behavior
                if not results or not getattr(results, "tracks", None):
                    query = f"spsearch:{last_track.author}"
                    results = await event.player.node.get_tracks(query)

                if results and hasattr(results, "tracks") and results.tracks:
                    import random
                    history = event.player.fetch("history", [])
                    
                    # Filter out recently played tracks
                    new_tracks = [t for t in results.tracks if getattr(t, 'identifier', '') not in history]
                    
                    # Fallback if all typical results are already in history
                    if not new_tracks:
                        new_tracks = [t for t in results.tracks if getattr(t, 'identifier', '') != getattr(last_track, 'identifier', '')]
                        event.player.store("history", [getattr(last_track, 'identifier', '')])
                        
                    if new_tracks:
                        next_track = random.choice(new_tracks[:5])
                        event.player.add(requester=getattr(last_track, 'requester', 0), track=next_track)
                        await event.player.play()
                        return

        guild = self.bot.get_guild(event.player.guild_id)
        if guild and guild.voice_client:
            await guild.voice_client.disconnect(force=True)

    @lavalink.listener(lavalink.events.TrackStartEvent)
    async def on_track_start(self, event: lavalink.events.TrackStartEvent):
        # Seek if start_time is set
        if hasattr(event.track, 'extra') and event.track.extra and 'start_time' in event.track.extra:
            start_time = event.track.extra['start_time']
            if start_time > 0:
                await event.player.seek(start_time)

        guild = self.bot.get_guild(event.player.guild_id)
        if not guild: return
        channel_id = event.player.fetch("channel")
        if channel_id:
            channel = guild.get_channel(channel_id)
            if channel:
                old_msg_id = event.player.fetch("np_message")
                if old_msg_id:
                    try:
                        old_msg = await channel.fetch_message(old_msg_id)
                        await old_msg.delete()
                    except discord.NotFound:
                        pass
                    except discord.Forbidden:
                        pass
                
                embed = _np_embed(event.player)
                view = PlayerView(event.player)
                msg = await channel.send(embed=embed, view=view)
                event.player.store("np_message", msg.id)

    async def _ensure_voice(self, ctx: commands.Context):
        ll = self._lavalink()
        try:
            player = ll.player_manager.create(ctx.guild.id)
        except Exception as e:
            if "No available nodes" in str(e):
                await ctx.send("⏳  Connecting to the music server, please wait a few seconds and try again!")
                return None
            raise e
        is_play = ctx.command.name in ["play", "join"]

        if not ctx.author.voice or not ctx.author.voice.channel:
            await ctx.send("❌  You need to be in a voice channel.")
            return None

        v_client = ctx.voice_client
        if not v_client:
            if not is_play:
                await ctx.send("❌  I'm not connected to a voice channel.")
                return None
            perms = ctx.author.voice.channel.permissions_for(ctx.me)
            if not perms.connect or not perms.speak:
                await ctx.send("❌  I need **Connect** and **Speak** permissions.")
                return None
            player.store("channel", ctx.channel.id)
            await ctx.author.voice.channel.connect(cls=LavalinkVoiceClient)
            
            try:
                if ctx.guild.me.guild_permissions.deafen_members:
                    await ctx.guild.me.edit(deafen=True)
            except Exception:
                pass
        elif v_client.channel.id != ctx.author.voice.channel.id:
            await ctx.send("❌  You must be in my voice channel.")
            return None

        return player

    @commands.hybrid_command(name="join", aliases=["connect", "j"])
    async def join(self, ctx: commands.Context):
        """Join a voice channel."""
        player = await self._ensure_voice(ctx)
        if player:
            await ctx.send(f"✅  Joined **{ctx.author.voice.channel.name}**.")

    @commands.hybrid_command(name="play", aliases=["p"])
    @app_commands.describe(query="The song URL or search query to play.")
    async def play(self, ctx: commands.Context, *, query: str):
        """Play a song or add to queue."""
        player = await self._ensure_voice(ctx)
        if not player:
            return

        # Parse start time option from query like {2:40}
        start_time_ms = 0
        time_match = re.search(r'\{(\d+(?::\d+)*)\}', query)
        time_str_display = ""
        if time_match:
            time_str = time_match.group(1)
            time_str_display = f" starting at {time_str}"
            parts = time_str.split(':')
            if len(parts) == 1:
                start_time_ms = int(parts[0]) * 1000
            elif len(parts) == 2:
                start_time_ms = (int(parts[0]) * 60 + int(parts[1])) * 1000
            elif len(parts) == 3:
                start_time_ms = (int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])) * 1000
            
            # Remove the matched time part from the query
            query = query.replace(time_match.group(0), '').strip()

        query = query.strip("<>")
        if not query:
            return await ctx.send("❌  Please provide a search query or URL.")
            
        if not URL_RX.match(query):
            query = f"spsearch:{query}"
        async with ctx.typing():
            results = await player.node.get_tracks(query)
        if not results:
            return await ctx.send("❌  No results found.")
            
        if results.load_type == lavalink.LoadType.ERROR:
            error_msg = getattr(results.error, 'message', str(results.error)) if getattr(results, 'error', None) else "Unknown Lavalink Error"
            return await ctx.send(f"❌  Lavalink failed to load track: `{error_msg}`")
            
        if not results.tracks:
            return await ctx.send("❌  No results found.")
            
        if results.load_type == lavalink.LoadType.PLAYLIST:
            for i, track in enumerate(results.tracks):
                if start_time_ms > 0:
                    if not hasattr(track, 'extra') or not isinstance(track.extra, dict):
                        track.extra = {}
                    track.extra['start_time'] = start_time_ms
                player.add(requester=ctx.author.id, track=track)
            await ctx.send(f"📋  Added playlist **{results.playlist_info.name}** — `{len(results.tracks)}` tracks{time_str_display}.")
        else:
            track = results.tracks[0]
            if start_time_ms > 0:
                if not hasattr(track, 'extra') or not isinstance(track.extra, dict):
                    track.extra = {}
                track.extra['start_time'] = start_time_ms
            player.add(requester=ctx.author.id, track=track)
            if player.is_playing:
                dur = f"{track.duration // 60000}:{(track.duration // 1000) % 60:02d}"
                await ctx.send(f"➕  Added: **{track.title}** `[{dur}]`{time_str_display}")
                
        if not player.is_playing:
            await player.play()
            if getattr(ctx.interaction, 'response', None):
                if not ctx.interaction.response.is_done():
                    await ctx.send(f"⏳ Starting playback{time_str_display}...", ephemeral=True)
                
    @commands.hybrid_command(name="pause")
    async def pause(self, ctx: commands.Context):
        """Pauses the current track."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.is_playing:
            return await ctx.send("❌  Nothing is playing.")
        if player.paused:
            return await ctx.send("⚠️  Already paused.")
        await player.set_pause(True)
        await ctx.send("⏸️  Paused.")

    @commands.hybrid_command(name="resume", aliases=["r"])
    async def resume(self, ctx: commands.Context):
        """Resumes the current track."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.paused:
            return await ctx.send("❌  Not paused.")
        await player.set_pause(False)
        await ctx.send("▶️  Resumed.")

    @commands.hybrid_command(name="skip", aliases=["s", "next"])
    async def skip(self, ctx: commands.Context):
        """Skips the current track."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.is_playing:
            return await ctx.send("❌  Nothing to skip.")
        await player.skip()
        await ctx.send("⏭️  Skipped.")

    @commands.hybrid_command(name="stop")
    async def stop(self, ctx: commands.Context):
        """Stops playing and clears the queue."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player:
            return await ctx.send("❌  I'm not connected.")
        player.queue.clear()
        await player.stop()
        await ctx.send("⏹️  Stopped and queue cleared.")

    @commands.hybrid_command(name="queue", aliases=["q"])
    @app_commands.describe(page="Page number of the queue")
    async def queue(self, ctx: commands.Context, page: int = 1):
        """Shows the track queue."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.queue:
            return await ctx.send("📭  The queue is empty.")
        per_page = 10
        pages = math.ceil(len(player.queue) / per_page)
        page = max(1, min(page, pages))
        start = (page - 1) * per_page
        chunk = list(player.queue)[start:start + per_page]
        lines = [
            f"`{i}.` **{t.title}** — `{t.duration // 60000}:{(t.duration // 1000) % 60:02d}`"
            for i, t in enumerate(chunk, start=start + 1)
        ]
        embed = discord.Embed(title=f"📋  Queue  ({len(player.queue)} tracks)", description="\n".join(lines), color=0x3498DB)
        if player.current:
            embed.set_footer(text=f"Now playing: {player.current.title}  •  Page {page}/{pages}")
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="nowplaying", aliases=["now", "playing"])
    async def now_playing(self, ctx: commands.Context):
        """Shows the currently playing track."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.current:
            return await ctx.send("❌  Nothing is playing.")
        view = PlayerView(player)
        await ctx.send(embed=_np_embed(player), view=view)

    @commands.hybrid_command(name="volume", aliases=["vol", "v"])
    @app_commands.describe(vol="Volume percentage (0-100)")
    async def volume(self, ctx: commands.Context, vol: int):
        """Sets the player volume."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player:
            return await ctx.send("❌  I'm not connected.")
        vol = max(0, min(100, vol))
        await player.set_volume(vol)
        bar = "█" * (vol // 10) + "░" * (10 - vol // 10)
        await ctx.send(f"🔊  Volume: **{vol}%**  `[{bar}]`")

    @commands.hybrid_command(name="loop", aliases=["repeat"])
    async def loop(self, ctx: commands.Context):
        """Toggles looping of the current track."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.current:
            return await ctx.send("❌  Nothing is playing.")
        new_loop = 1 if player.loop == 0 else 0
        player.set_loop(new_loop)
        await ctx.send(f"🔁  Loop **{'enabled' if player.loop else 'disabled'}**.")

    @commands.hybrid_command(name="shuffle")
    async def shuffle(self, ctx: commands.Context):
        """Toggles a random order for the queue."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.queue:
            return await ctx.send("❌  Queue is empty.")
        player.set_shuffle(not player.shuffle)
        await ctx.send(f"🔀  Shuffle **{'enabled' if player.shuffle else 'disabled'}**.")

    @commands.hybrid_command(name="dc", aliases=["leave", "disconnect"])
    async def disconnect(self, ctx: commands.Context):
        """Disconnects the bot from the voice channel."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player or not player.is_connected:
            return await ctx.send("❌  I'm not in a voice channel.")
        player.queue.clear()
        await player.stop()
        await ctx.voice_client.disconnect(force=True)
        await ctx.send("👋  Disconnected.")

    @commands.hybrid_command(name="musicping", aliases=["mping"])
    async def ping(self, ctx: commands.Context):
        """Shows the bot's latency and Lavalink node status."""
        bot_latency = round(self.bot.latency * 1000)
        embed = discord.Embed(title="🏓 Pong!", color=0x9B59B6)
        embed.add_field(name="Bot Latency", value=f"`{bot_latency}ms`", inline=False)
        
        try:
            ll = self._lavalink()
            if getattr(ll, "node_manager", None) and getattr(ll.node_manager, "nodes", None):
                for node in ll.node_manager.nodes:
                    status = "🟢 Connected" if node.available else "🔴 Disconnected"
                    ping_text = ""
                    if getattr(node, "get_rest_latency", None):
                        try:
                            latency = await node.get_rest_latency()
                            latency_ms = int(latency * 1000) if latency < 10 else int(latency)
                            ping_text = f" - `{latency_ms}ms`"
                        except Exception:
                            pass
                    
                    stats_text = ""
                    if getattr(node, "stats", None):
                        stats_text = f" (Players: {node.stats.players}, CPU: {round(node.stats.system_load * 100, 1)}%)"
                        
                    embed.add_field(name=f"Lavalink Node ({node.name})", value=f"{status}{ping_text}{stats_text}", inline=False)
        except RuntimeError:
            embed.add_field(name="Lavalink Node", value="Not initialized yet.", inline=False)

        await ctx.send(embed=embed)

    @commands.hybrid_command(name="node")
    @app_commands.describe(node_index="Select the node by number (1 or 2)")
    async def node_select(self, ctx: commands.Context, node_index: int):
        """Switch the Lavalink node for the current player."""
        player = self._lavalink().player_manager.get(ctx.guild.id)
        if not player:
            return await ctx.send("❌  I'm not connected to a voice channel.")
            
        nodes = self._lavalink().node_manager.nodes
        if node_index < 1 or node_index > len(nodes):
            return await ctx.send(f"❌  Invalid node number. Choose between 1 and {len(nodes)}.")
            
        target_node = nodes[node_index - 1]
        
        if not target_node.available:
            return await ctx.send(f"❌  Node `{target_node.name}` is currently disconnected.")
            
        await player.change_node(target_node)
        await ctx.send(f"✅  Switched to node: **{target_node.name}**")

    @commands.hybrid_command(name="musichelp", aliases=["mhelp"])
    async def help_cmd(self, ctx: commands.Context):
        """Shows this help message."""
        prefix = getattr(self.bot, "_default_prefix", "$")
        embed = discord.Embed(title="🎵  Music Bot Commands", description=f"Prefix: `{prefix}` or `/` (Slash Commands)", color=0x9B59B6)
        for name, desc in [
            ("/play <query>",   "Play a song or add to queue"),
            ("/join",           "Join your voice channel"),
            ("/pause",          "Pause the current track"),
            ("/resume",         "Resume playback"),
            ("/skip",           "Skip to the next track"),
            ("/stop",           "Stop and clear the queue"),
            ("/queue [page]",   "View the queue"),
            ("/np",             "See what's playing now"),
            ("/volume <1-100>", "Set the volume"),
            ("/loop",           "Toggle loop on current track"),
            ("/shuffle",        "Toggle queue shuffle"),
            ("/dc",             "Disconnect from voice"),
            ("/ping",           "Check bot and Lavalink latency"),
            ("/node <1|2>",     "Switch Lavalink node"),
        ]:
            embed.add_field(name=f"`{name}`", value=desc, inline=False)
        embed.set_footer(text="Powered by Lavalink + lavalink.py 5.x")
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(Music(bot))
