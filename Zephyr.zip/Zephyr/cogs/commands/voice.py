"""
Voice Moderation — Full voice channel management commands.
/voice kick/kickall/mute/unmute/muteall/unmuteall/deafen/undeafen/move/moveall/pull/pullall/lock/unlock/private/unprivate
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS
from utils.Tools import create_embed

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.voice")


class VoiceCog(commands.Cog):
    """Voice channel management for Zephyr."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    voice = app_commands.Group(name="voice", description="Voice channel management")

    def _get_vc(self, member: discord.Member) -> discord.VoiceChannel | None:
        if member.voice and member.voice.channel and isinstance(member.voice.channel, discord.VoiceChannel):
            return member.voice.channel
        return None

    @voice.command(name="kick", description="Disconnect a user from voice")
    @app_commands.describe(member="User to disconnect")
    @app_commands.checks.has_permissions(move_members=True)
    async def vc_kick(self, interaction: discord.Interaction, member: discord.Member):
        if not member.voice:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} {member.mention} is not in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await member.move_to(None, reason=f"Zephyr — Voice kick by {interaction.user}")
        em = create_embed(description=f"## {EMOJIS['kick']} Voice Kick\n{member.mention} has been **disconnected** from voice\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="kickall", description="Disconnect everyone from your voice channel")
    @app_commands.checks.has_permissions(move_members=True)
    async def vc_kickall(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await interaction.response.defer()
        count = 0
        for m in vc.members:
            if m.id != interaction.user.id:
                try:
                    await m.move_to(None, reason="Zephyr — Voice kickall")
                    count += 1
                except discord.HTTPException:
                    pass
        em = create_embed(description=f"## {EMOJIS['kick']} Voice Kick All\nDisconnected **`{count}`** member(s) from **{vc.name}**\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.followup.send(embed=em)

    @voice.command(name="mute", description="Server mute a user")
    @app_commands.describe(member="User to mute")
    @app_commands.checks.has_permissions(mute_members=True)
    async def vc_mute(self, interaction: discord.Interaction, member: discord.Member):
        if not member.voice:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} {member.mention} is not in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await member.edit(mute=True, reason=f"Zephyr — Muted by {interaction.user}")
        em = create_embed(description=f"## {EMOJIS['mute']} Voice Mute\n{member.mention} has been **server muted**\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="unmute", description="Server unmute a user")
    @app_commands.describe(member="User to unmute")
    @app_commands.checks.has_permissions(mute_members=True)
    async def vc_unmute(self, interaction: discord.Interaction, member: discord.Member):
        if not member.voice:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} {member.mention} is not in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await member.edit(mute=False, reason=f"Zephyr — Unmuted by {interaction.user}")
        em = create_embed(description=f"## {EMOJIS['unmute']} Voice Unmute\n{member.mention} has been **server unmuted**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="muteall", description="Server mute everyone in your voice channel")
    @app_commands.checks.has_permissions(mute_members=True)
    async def vc_muteall(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await interaction.response.defer()
        count = 0
        for m in vc.members:
            if m.id != interaction.user.id:
                try:
                    await m.edit(mute=True, reason="Zephyr — Muteall")
                    count += 1
                except discord.HTTPException:
                    pass
        em = create_embed(description=f"## {EMOJIS['mute']} Voice Mute All\nMuted **`{count}`** member(s)\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.followup.send(embed=em)

    @voice.command(name="unmuteall", description="Server unmute everyone in your voice channel")
    @app_commands.checks.has_permissions(mute_members=True)
    async def vc_unmuteall(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await interaction.response.defer()
        count = 0
        for m in vc.members:
            try:
                await m.edit(mute=False, reason="Zephyr — Unmuteall")
                count += 1
            except discord.HTTPException:
                pass
        em = create_embed(description=f"## {EMOJIS['unmute']} Voice Unmute All\nUnmuted **`{count}`** member(s)\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.followup.send(embed=em)

    @voice.command(name="deafen", description="Server deafen a user")
    @app_commands.describe(member="User to deafen")
    @app_commands.checks.has_permissions(deafen_members=True)
    async def vc_deafen(self, interaction: discord.Interaction, member: discord.Member):
        if not member.voice:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} {member.mention} is not in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await member.edit(deafen=True, reason=f"Zephyr — Deafened by {interaction.user}")
        em = create_embed(description=f"## {EMOJIS['mute']} Voice Deafen\n{member.mention} has been **server deafened**\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="undeafen", description="Server undeafen a user")
    @app_commands.describe(member="User to undeafen")
    @app_commands.checks.has_permissions(deafen_members=True)
    async def vc_undeafen(self, interaction: discord.Interaction, member: discord.Member):
        if not member.voice:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} {member.mention} is not in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await member.edit(deafen=False, reason=f"Zephyr — Undeafened by {interaction.user}")
        em = create_embed(description=f"## {EMOJIS['unmute']} Voice Undeafen\n{member.mention} has been **server undeafened**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="deafenall", description="Server deafen everyone in your voice channel")
    @app_commands.checks.has_permissions(deafen_members=True)
    async def vc_deafenall(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await interaction.response.defer()
        count = 0
        for m in vc.members:
            if m.id != interaction.user.id:
                try:
                    await m.edit(deafen=True, reason="Zephyr — Deafenall")
                    count += 1
                except discord.HTTPException:
                    pass
        em = create_embed(description=f"## {EMOJIS['mute']} Voice Deafen All\nDeafened **`{count}`** member(s)\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.followup.send(embed=em)

    @voice.command(name="undeafenall", description="Server undeafen everyone in your voice channel")
    @app_commands.checks.has_permissions(deafen_members=True)
    async def vc_undeafenall(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await interaction.response.defer()
        count = 0
        for m in vc.members:
            try:
                await m.edit(deafen=False, reason="Zephyr — Undeafenall")
                count += 1
            except discord.HTTPException:
                pass
        em = create_embed(description=f"## {EMOJIS['unmute']} Voice Undeafen All\nUndeafened **`{count}`** member(s)\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.followup.send(embed=em)

    @voice.command(name="pullall", description="Pull everyone from another VC to yours")
    @app_commands.describe(channel="Source channel to pull from")
    @app_commands.checks.has_permissions(move_members=True)
    async def vc_pullall(self, interaction: discord.Interaction, channel: discord.VoiceChannel):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await interaction.response.defer()
        count = 0
        for m in channel.members:
            try:
                await m.move_to(vc, reason="Zephyr — Pullall")
                count += 1
            except discord.HTTPException:
                pass
        em = create_embed(description=f"## {EMOJIS['success']} Voice Pull All\nPulled **`{count}`** member(s) from **{channel.name}** to **{vc.name}**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.followup.send(embed=em)

    @voice.command(name="move", description="Move a user to another voice channel")
    @app_commands.describe(member="User to move", channel="Target channel")
    @app_commands.checks.has_permissions(move_members=True)
    async def vc_move(self, interaction: discord.Interaction, member: discord.Member, channel: discord.VoiceChannel):
        if not member.voice:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} {member.mention} is not in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await member.move_to(channel, reason=f"Zephyr — Moved by {interaction.user}")
        em = create_embed(description=f"## {EMOJIS['success']} Voice Move\n{member.mention} moved to **{channel.name}**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="moveall", description="Move everyone from your VC to another")
    @app_commands.describe(channel="Target channel")
    @app_commands.checks.has_permissions(move_members=True)
    async def vc_moveall(self, interaction: discord.Interaction, channel: discord.VoiceChannel):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await interaction.response.defer()
        count = 0
        for m in vc.members:
            try:
                await m.move_to(channel, reason="Zephyr — Moveall")
                count += 1
            except discord.HTTPException:
                pass
        em = create_embed(description=f"## {EMOJIS['success']} Voice Move All\nMoved **`{count}`** member(s) to **{channel.name}**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.followup.send(embed=em)

    @voice.command(name="pull", description="Pull a user to your voice channel")
    @app_commands.describe(member="User to pull")
    @app_commands.checks.has_permissions(move_members=True)
    async def vc_pull(self, interaction: discord.Interaction, member: discord.Member):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        if not member.voice:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} {member.mention} is not in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await member.move_to(vc, reason=f"Zephyr — Pulled by {interaction.user}")
        em = create_embed(description=f"## {EMOJIS['success']} Voice Pull\n{member.mention} pulled to **{vc.name}**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="lock", description="Lock your current voice channel")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def vc_lock(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await vc.set_permissions(interaction.guild.default_role, connect=False, reason="Zephyr — VC Lock")  # type: ignore
        em = create_embed(description=f"## {EMOJIS['lock']} Channel Locked\n**{vc.name}** has been **locked**\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="unlock", description="Unlock your current voice channel")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def vc_unlock(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await vc.set_permissions(interaction.guild.default_role, connect=True, reason="Zephyr — VC Unlock")  # type: ignore
        em = create_embed(description=f"## {EMOJIS['unlock']} Channel Unlocked\n**{vc.name}** has been **unlocked**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="private", description="Make your VC private (hidden + locked)")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def vc_private(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await vc.set_permissions(interaction.guild.default_role, connect=False, view_channel=False, reason="Zephyr — VC Private")  # type: ignore
        em = create_embed(description=f"## {EMOJIS['lock']} Channel Private\n**{vc.name}** is now **private**\n-# Moderator: {interaction.user.mention}", color=COLORS["mod"])
        await interaction.response.send_message(embed=em)

    @voice.command(name="unprivate", description="Make your VC public again")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def vc_unprivate(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member):
            return
        vc = self._get_vc(interaction.user)
        if not vc:
            return await interaction.response.send_message(
                embed=create_embed(description=f"{EMOJIS['error']} You must be in a voice channel.", color=COLORS["error"]),
                ephemeral=True,
            )
        await vc.set_permissions(interaction.guild.default_role, connect=True, view_channel=True, reason="Zephyr — VC Unprivate")  # type: ignore
        em = create_embed(description=f"## {EMOJIS['unlock']} Channel Public\n**{vc.name}** is now **public**\n-# Moderator: {interaction.user.mention}", color=COLORS["success"])
        await interaction.response.send_message(embed=em)


async def setup(bot: Zephyr):
    await bot.add_cog(VoiceCog(bot))
    log.info("  ✓ VoiceCog loaded")
