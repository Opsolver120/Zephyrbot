"""
Automod Event Listeners — Spam Detection
RAM-cached recent_messages for fast spam detection without DB reads.
"""

from __future__ import annotations

import logging
import time
import asyncio
from collections import defaultdict
from datetime import timedelta
from typing import TYPE_CHECKING

import discord
from discord.ext import commands, tasks

from utils.custjis import EMOJIS, COLORS

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.automod.antispam")

# Spam thresholds
SPAM_THRESHOLD = 5          # messages
SPAM_WINDOW = 5.0           # seconds
CAPS_THRESHOLD = 0.7        # 70% caps
CAPS_MIN_LENGTH = 10        # minimum message length to check caps
MENTION_THRESHOLD = 5       # max mentions per message

INVITE_PATTERN = r"(discord\.gg|discord\.com/invite|discordapp\.com/invite)/[a-zA-Z0-9]+"
LINK_PATTERN = r"https?://[^\s<>\"']+|www\.[^\s<>\"']+"


class AntiSpam(commands.Cog):
    def __init__(self, bot: Zephyr):
        self.bot = bot
        self.recent_messages: dict[int, dict[int, list[float]]] = defaultdict(lambda: defaultdict(list))
        self.cleanup_task.start()  # Start cleanup task

    def cog_unload(self):
        """Cancel cleanup task when cog is unloaded."""
        self.cleanup_task.cancel()

    @commands.Cog.listener()
    async def on_guild_remove(self, guild: discord.Guild):
        """Clean up data when bot leaves a guild."""
        if guild.id in self.recent_messages:
            del self.recent_messages[guild.id]

    @tasks.loop(minutes=5)
    async def cleanup_task(self):
        """Periodically clean up old message timestamps."""
        now = time.time()
        guilds_to_remove = []
        
        for guild_id, users in list(self.recent_messages.items()):
            users_to_remove = []
            for user_id, timestamps in list(users.items()):
                # Remove timestamps older than spam window
                users[user_id] = [t for t in timestamps if now - t < SPAM_WINDOW]
                # If user has no recent messages, mark for removal
                if not users[user_id]:
                    users_to_remove.append(user_id)
            
            # Remove inactive users
            for user_id in users_to_remove:
                del users[user_id]
            
            # If guild has no active users, mark for removal
            if not users:
                guilds_to_remove.append(guild_id)
        
        # Remove inactive guilds
        for guild_id in guilds_to_remove:
            del self.recent_messages[guild_id]
        
        log.debug(f"[AntiSpam] Cleanup: {len(guilds_to_remove)} inactive guilds removed")

    @cleanup_task.before_loop
    async def before_cleanup(self):
        """Wait until bot is ready before starting cleanup."""
        await self.bot.wait_until_ready()

    def _is_immune(self, message: discord.Message) -> bool:
        """Check if user is immune from automod."""
        if not message.guild:
            return True
        if message.author.bot:
            return True
        if message.author.id == message.guild.owner_id:
            return True
        if message.author.id in self.bot.owner_ids_set:
            return True
        if isinstance(message.author, discord.Member) and message.author.guild_permissions.administrator:
            return True

        extras = self.bot.cache["extra_owners"].get(message.guild.id, set())
        if message.author.id in extras:
            return True

        return False

    async def _punish(self, message: discord.Message, reason: str):
        """Apply punishment based on automod config."""
        guild = message.guild
        if not guild:
            return

        member = message.author
        if not isinstance(member, discord.Member):
            return

        try:
            await message.delete()
        except discord.HTTPException:
            pass

        # Default: timeout for 5 minutes
        try:
            await member.timeout(timedelta(minutes=5), reason=f"Zephyr Automod — {reason}")
        except discord.HTTPException:
            pass

        try:
            em = discord.Embed(
                description=f"{EMOJIS['automod']} {member.mention}, you triggered **{reason}** {EMOJIS['warning']}",
                color=COLORS["warning"],
            )
            msg = await message.channel.send(embed=em)
            await asyncio.sleep(5)
            await msg.delete()
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if self._is_immune(message):
            return

        if not message.guild:
            return

        guild_id = message.guild.id
        automod_cfg = self.bot.cache["automod"].get(guild_id, {})

        if not automod_cfg.get("enabled"):
            return

        filters = automod_cfg.get("filters", set())
        content = message.content

        # ── Anti Spam ──────────────────────────────────────────
        if "antispam" in filters:
            now = time.time()
            user_msgs = self.recent_messages[guild_id][message.author.id]
            user_msgs.append(now)
            # Clean old entries
            self.recent_messages[guild_id][message.author.id] = [
                t for t in user_msgs if now - t < SPAM_WINDOW
            ]
            if len(self.recent_messages[guild_id][message.author.id]) >= SPAM_THRESHOLD:
                self.recent_messages[guild_id][message.author.id] = []
                await self._punish(message, "Anti Spam")
                return

        # ── Anti Caps ──────────────────────────────────────────
        if "anticaps" in filters and len(content) >= CAPS_MIN_LENGTH:
            upper = sum(1 for c in content if c.isupper())
            if upper / len(content) >= CAPS_THRESHOLD:
                await self._punish(message, "Anti Caps")
                return

        # ── Anti Invite ────────────────────────────────────────
        if "antiinvite" in filters:
            import re
            if re.search(INVITE_PATTERN, content, re.IGNORECASE):
                await self._punish(message, "Anti Invite")
                return

        # ── Anti Link ──────────────────────────────────────────
        if "antilink" in filters:
            import re
            if re.search(LINK_PATTERN, content, re.IGNORECASE):
                await self._punish(message, "Anti Link")
                return

        # ── Anti Mass Mention ──────────────────────────────────
        if "antimention" in filters:
            if len(message.mentions) >= MENTION_THRESHOLD:
                await self._punish(message, "Anti Mass Mention")
                return


async def setup(bot: Zephyr):
    await bot.add_cog(AntiSpam(bot))
