"""
Event handlers for Zephyr bot.
"""
from __future__ import annotations
import logging
from typing import TYPE_CHECKING
import discord
from discord.ext import commands

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.events")


class EventsCog(commands.Cog):
    """Core event handlers."""

    def __init__(self, bot: Zephyr):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        """Called when bot is ready."""
        log.info(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        log.info(f"  Logged in as {self.bot.user} (ID: {self.bot.user.id})")
        log.info(f"  Connected to {len(self.bot.guilds)} guild(s)")
        log.info(f"  Prefix: {self.bot._default_prefix}")
        log.info(f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        import lavalink
        if not hasattr(self.bot, "lavalink"):
            self.bot.lavalink = lavalink.Client(self.bot.user.id)
            lavalink_config = self.bot.config.get("lavalink", {})
            if lavalink_config.get("host"):
                self.bot.lavalink.add_node(
                    host=lavalink_config["host"],
                    port=lavalink_config["port"],
                    password=lavalink_config.get("password", "youshallnotpass"),
                    region="asia",
                    name="default-node",
                )
            music_cog = self.bot.get_cog("Music")
            if music_cog:
                self.bot.lavalink.add_event_hooks(music_cog)
            log.info(f"🎵 Lavalink initialized (Node: {lavalink_config.get('host')})")


async def setup(bot: Zephyr):
    await bot.add_cog(EventsCog(bot))
    log.info("  ✓ EventsCog loaded")
