"""
Antinuke Event Listeners — Anti-Bot Add, Anti-Webhook, Anti-Server Update
With rate limiting and improved webhook handling.
"""

from __future__ import annotations

import logging
from datetime import timedelta
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from ._base import AntinukeBase

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.antinuke.antimisc")


class AntiBotAdd(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Detect unauthorized bot additions."""
        if not member.bot:
            return

        guild = member.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.bot_add)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "botadd"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking bot add by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized bot add by {perp} in {guild.name}: {member} - THRESHOLD EXCEEDED")

            # Kick the bot
            try:
                await member.kick(reason="Zephyr Antinuke — Unauthorized bot addition")
            except discord.HTTPException:
                pass

            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized bot addition")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            await self._log_action(
                guild, "Unauthorized Bot Add",
                perp, f"{member.mention} (`{member.id}`) - kicked",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antibotadd: {e}")


class AntiWebhook(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel: discord.TextChannel):
        guild = channel.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.webhook_create)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "mngweb"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking webhook create by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized webhook create by {perp} in {guild.name} - THRESHOLD EXCEEDED")

            # Delete only recent webhooks by perpetrator (created in last 10 seconds)
            threshold = discord.utils.utcnow() - timedelta(seconds=10)
            try:
                webhooks = await channel.webhooks()
                deleted_count = 0
                for wh in webhooks:
                    if wh.user and wh.user.id == perp.id:
                        # Only delete if recently created
                        if hasattr(wh, 'created_at') and wh.created_at and wh.created_at > threshold:
                            await wh.delete(reason="Zephyr Antinuke — Unauthorized webhook")
                            deleted_count += 1
            except discord.HTTPException:
                pass

            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized webhook creation")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            await self._log_action(
                guild, "Unauthorized Webhook Create",
                perp, f"#{channel.name} ({deleted_count} webhooks deleted)",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antiwebhook: {e}")


class AntiServerUpdate(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_guild_update(self, before: discord.Guild, after: discord.Guild):
        if not self.bot.cache["antinuke"].get(after.id):
            return

        try:
            entry = await self._get_audit_entry(after, discord.AuditLogAction.guild_update)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(after, perp, "serverup"):
                return
            if self._is_on_cooldown(after.id, perp.id):
                return
            if not self._should_punish(after.id, perp.id):
                log.info(f"[Antinuke] Tracking server update by {perp} in {after.name}")
                return

            log.warning(f"[Antinuke] Unauthorized server update by {perp} in {after.name} - THRESHOLD EXCEEDED")

            action_taken = await self._punish_perpetrator(after, perp, "Unauthorized server update")
            self._set_cooldown(after.id, perp.id)
            self._reset_tracker(after.id, perp.id)

            await self._log_action(
                after, "Unauthorized Server Update",
                perp, f"{after.name}",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antiserverup: {e}")


async def setup(bot: Zephyr):
    await bot.add_cog(AntiBotAdd(bot))
    await bot.add_cog(AntiWebhook(bot))
    await bot.add_cog(AntiServerUpdate(bot))
