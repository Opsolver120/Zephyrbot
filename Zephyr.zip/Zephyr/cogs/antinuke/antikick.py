"""
Antinuke Event Listeners — Anti-Kick
Detects unauthorized kicks and punishes the perpetrator with rate limiting.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from ._base import AntinukeBase

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.antinuke.antikick")


class AntiKick(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        guild = member.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.kick, member.id)
            if not entry or not entry.user:
                return  # Was a leave, not a kick

            perpetrator = entry.user

            # Check immunity
            if self._is_immune(guild, perpetrator, "kick"):
                return

            # Check cooldown
            if self._is_on_cooldown(guild.id, perpetrator.id):
                return

            # Check rate limiting
            if not self._should_punish(guild.id, perpetrator.id):
                log.info(f"[Antinuke] Tracking kick by {perpetrator} in {guild.name} ({len(self.action_tracker[guild.id][perpetrator.id])}/3)")
                return

            log.warning(
                f"[Antinuke] Unauthorized kick by {perpetrator} ({perpetrator.id}) in {guild.name} - THRESHOLD EXCEEDED"
            )

            # Punish perpetrator
            action_taken = await self._punish_perpetrator(
                guild, perpetrator, "Unauthorized kick action (rate limit exceeded)"
            )

            # Set cooldown and reset tracker
            self._set_cooldown(guild.id, perpetrator.id)
            self._reset_tracker(guild.id, perpetrator.id)

            # Log action
            await self._log_action(
                guild, "Unauthorized Kick",
                perpetrator, f"{member.mention} (`{member.id}`)",
                action_taken
            )

        except discord.Forbidden:
            log.error(f"[Antinuke] Missing audit log permissions in {guild.name}")
        except Exception as e:
            log.error(f"[Antinuke] Error in antikick: {e}")


async def setup(bot: Zephyr):
    await bot.add_cog(AntiKick(bot))
