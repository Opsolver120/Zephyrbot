"""
Antinuke Event Listeners — Anti-Role Create / Delete / Update
Detects unauthorized role modifications with complete restoration including position.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from ._base import AntinukeBase

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.antinuke.antirole")


class AntiRoleDelete(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role):
        guild = role.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.role_delete)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "rldl"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking role delete by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized role delete by {perp} in {guild.name} - THRESHOLD EXCEEDED")

            # Recreate role with position
            try:
                new_role = await guild.create_role(
                    name=role.name,
                    color=role.color,
                    hoist=role.hoist,
                    mentionable=role.mentionable,
                    permissions=role.permissions,
                    reason="Zephyr Antinuke — Role restored",
                )
                # Set position (requires separate edit)
                try:
                    await new_role.edit(position=role.position)
                except discord.HTTPException:
                    pass  # Position may be too high
            except discord.HTTPException as e:
                log.error(f"[Antinuke] Failed to restore role: {e}")

            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized role deletion")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            await self._log_action(
                guild, "Unauthorized Role Delete",
                perp, f"@{role.name} (restored)",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antirldl: {e}")


class AntiRoleCreate(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role):
        guild = role.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.role_create)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "rlcr"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking role create by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized role create by {perp} in {guild.name} - THRESHOLD EXCEEDED")

            try:
                await role.delete(reason="Zephyr Antinuke — Unauthorized role creation reversed")
            except discord.HTTPException:
                pass

            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized role creation")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            await self._log_action(
                guild, "Unauthorized Role Create",
                perp, f"@{role.name} (deleted)",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antirlcr: {e}")


class AntiRoleUpdate(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role):
        guild = after.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.role_update)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "rlup"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking role update by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized role update by {perp} in {guild.name} - THRESHOLD EXCEEDED")

            # Revert role changes
            try:
                await after.edit(
                    name=before.name,
                    color=before.color,
                    hoist=before.hoist,
                    mentionable=before.mentionable,
                    permissions=before.permissions,
                    reason="Zephyr Antinuke — Unauthorized role update reversed",
                )
            except discord.HTTPException:
                pass

            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized role update")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            await self._log_action(
                guild, "Unauthorized Role Update",
                perp, f"@{after.name} (reverted)",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antirlup: {e}")


async def setup(bot: Zephyr):
    await bot.add_cog(AntiRoleDelete(bot))
    await bot.add_cog(AntiRoleCreate(bot))
    await bot.add_cog(AntiRoleUpdate(bot))
