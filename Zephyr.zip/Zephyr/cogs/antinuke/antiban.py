"""
Antinuke Event Listeners — Anti-Ban
Detects unauthorized bans and reverses them with rate limiting and logging.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from ._base import AntinukeBase

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.antinuke.antiban")


class AntiBan(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        # Quick check: is antinuke enabled?
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        # Find who did it via audit log with retry logic
        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.ban)
            if not entry or not entry.user:
                return

            perpetrator = entry.user

            # Check immunity
            if self._is_immune(guild, perpetrator, "ban"):
                return

            # Check cooldown
            if self._is_on_cooldown(guild.id, perpetrator.id):
                return

            # Check rate limiting
            if not self._should_punish(guild.id, perpetrator.id):
                log.info(f"[Antinuke] Tracking ban by {perpetrator} in {guild.name} ({len(self.action_tracker[guild.id][perpetrator.id])}/3)")
                return

            # UNAUTHORIZED — take action
            log.warning(
                f"[Antinuke] Unauthorized ban by {perpetrator} ({perpetrator.id}) in {guild.name} - THRESHOLD EXCEEDED"
            )

            # 1. Unban the victim
            try:
                await guild.unban(user, reason="Zephyr Antinuke — Unauthorized ban reversed")
            except discord.HTTPException:
                pass

            # 2. Punish perpetrator
            action_taken = await self._punish_perpetrator(
                guild, perpetrator, "Unauthorized ban action (rate limit exceeded)"
            )

            # 3. Set cooldown and reset tracker
            self._set_cooldown(guild.id, perpetrator.id)
            self._reset_tracker(guild.id, perpetrator.id)

            # 4. Log action
            await self._log_action(
                guild, "Unauthorized Ban",
                perpetrator, f"{user.mention} (`{user.id}`)",
                action_taken
            )

        except discord.Forbidden:
            log.error(f"[Antinuke] Missing audit log permissions in {guild.name}")
        except Exception as e:
            log.error(f"[Antinuke] Error in antiban: {e}")


async def setup(bot: Zephyr):
    await bot.add_cog(AntiBan(bot))
