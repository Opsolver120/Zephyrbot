"""
Antinuke Base Class — Shared functionality for all antinuke modules
Provides rate limiting, cooldowns, logging, and audit log retry logic.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from datetime import timedelta
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.antinuke.base")

# Rate limiting constants
ACTION_THRESHOLD = 3  # actions before punishment
ACTION_WINDOW = 10.0  # seconds
COOLDOWN_DURATION = 300  # 5 minutes


class AntinukeBase(commands.Cog):
    """Base class with shared antinuke functionality."""
    
    def __init__(self, bot: Zephyr):
        self.bot = bot
        self.action_tracker: dict[int, dict[int, list[float]]] = defaultdict(lambda: defaultdict(list))
        self.punishment_cooldowns: dict[int, dict[int, float]] = defaultdict(dict)

    def _should_punish(self, guild_id: int, user_id: int) -> bool:
        """Check if user has exceeded action threshold."""
        now = time.time()
        actions = self.action_tracker[guild_id][user_id]
        
        # Clean old actions
        actions = [t for t in actions if now - t < ACTION_WINDOW]
        actions.append(now)
        self.action_tracker[guild_id][user_id] = actions
        
        # Check threshold
        return len(actions) >= ACTION_THRESHOLD

    def _is_on_cooldown(self, guild_id: int, user_id: int) -> bool:
        """Check if user is on punishment cooldown."""
        last_punish = self.punishment_cooldowns[guild_id].get(user_id, 0)
        return time.time() - last_punish < COOLDOWN_DURATION

    def _set_cooldown(self, guild_id: int, user_id: int):
        """Set punishment cooldown for user."""
        self.punishment_cooldowns[guild_id][user_id] = time.time()

    def _reset_tracker(self, guild_id: int, user_id: int):
        """Reset action tracker for user."""
        self.action_tracker[guild_id][user_id] = []

    async def _log_action(
        self, 
        guild: discord.Guild, 
        action_type: str,
        perpetrator: discord.User, 
        target: str,
        action_taken: str
    ):
        """Send log embed to configured channel."""
        log_channel_id = self.bot.cache.get("antinuke_logging", {}).get(guild.id)
        if not log_channel_id:
            return
        
        channel = guild.get_channel(log_channel_id)
        if not channel or not isinstance(channel, discord.TextChannel):
            return
        
        em = discord.Embed(
            title=f"🛡️ Antinuke Action: {action_type}",
            description=(
                f"**Perpetrator:** {perpetrator.mention} (`{perpetrator.id}`)\n"
                f"**Target:** {target}\n"
                f"**Action Taken:** {action_taken}\n"
                f"**Time:** <t:{int(time.time())}:F>"
            ),
            color=COLORS["error"],
            timestamp=discord.utils.utcnow()
        )
        em.set_footer(text=f"Zephyr Antinuke • {guild.name}")
        
        try:
            await channel.send(embed=em)
        except discord.HTTPException:
            pass

    async def _get_audit_entry(
        self, 
        guild: discord.Guild, 
        action: discord.AuditLogAction,
        target_id: int | None = None,
        max_retries: int = 3
    ) -> discord.AuditLogEntry | None:
        """Get audit log entry with retry logic."""
        threshold = discord.utils.utcnow() - timedelta(seconds=5)
        
        for attempt in range(max_retries):
            await asyncio.sleep(0.2 * (attempt + 1))
            
            try:
                async for entry in guild.audit_logs(action=action, limit=5):
                    if entry.created_at < threshold:
                        continue
                    if target_id and entry.target and hasattr(entry.target, 'id') and entry.target.id != target_id:
                        continue
                    return entry
            except discord.Forbidden:
                return None
        
        return None

    def _is_immune(self, guild: discord.Guild, user: discord.User, permission: str) -> bool:
        """Check if user is immune from antinuke."""
        if user.id == self.bot.user.id:  # type: ignore
            return True
        if user.id == guild.owner_id:
            return True
        if user.id in self.bot.owner_ids_set:
            return True

        extras = self.bot.cache["extra_owners"].get(guild.id, set())
        if user.id in extras:
            return True

        wl = self.bot.cache["whitelist"].get(guild.id, {}).get(user.id, {})
        if wl.get(permission):
            return True

        return False

    async def _punish_perpetrator(
        self, 
        guild: discord.Guild, 
        perpetrator: discord.User,
        reason: str
    ) -> str:
        """Punish perpetrator and return action taken."""
        try:
            await guild.ban(
                perpetrator,
                reason=f"Zephyr Antinuke — {reason}",
                delete_message_seconds=0,
            )
            return "Banned perpetrator"
        except discord.HTTPException:
            # If we can't ban (higher role), try to remove roles
            if isinstance(perpetrator, discord.Member):
                try:
                    await perpetrator.edit(
                        roles=[],
                        reason=f"Zephyr Antinuke — Role strip: {reason}",
                    )
                    return "Stripped roles (ban failed)"
                except discord.HTTPException:
                    return "Failed to punish (insufficient permissions)"
            return "Failed to punish (not a member)"
