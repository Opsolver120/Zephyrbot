"""
Antinuke Event Listeners — Anti-Channel Delete / Create / Update
Detects unauthorized channel modifications with rate limiting and complete restoration.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from ._base import AntinukeBase

if TYPE_CHECKING:
    from core.Zephyr import Zephyr

log = logging.getLogger("zephyr.antinuke.antichannel")


class AntiChannelDelete(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.channel_delete)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "chdl"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking channel delete by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized channel delete by {perp} in {guild.name} - THRESHOLD EXCEEDED")

            # Recreate the channel with ALL settings
            try:
                overwrites = {k: v for k, v in channel.overwrites.items()} if hasattr(channel, 'overwrites') else {}
                
                if isinstance(channel, discord.TextChannel):
                    await guild.create_text_channel(
                        name=channel.name,
                        category=channel.category,
                        overwrites=overwrites,
                        position=channel.position,
                        topic=channel.topic,
                        slowmode_delay=channel.slowmode_delay,
                        nsfw=channel.nsfw,
                        default_auto_archive_duration=channel.default_auto_archive_duration,
                        reason="Zephyr Antinuke — Channel restored",
                    )
                elif isinstance(channel, discord.VoiceChannel):
                    await guild.create_voice_channel(
                        name=channel.name,
                        category=channel.category,
                        overwrites=overwrites,
                        position=channel.position,
                        bitrate=channel.bitrate,
                        user_limit=channel.user_limit,
                        rtc_region=channel.rtc_region,
                        reason="Zephyr Antinuke — Channel restored",
                    )
                elif isinstance(channel, discord.CategoryChannel):
                    await guild.create_category(
                        name=channel.name,
                        overwrites=overwrites,
                        position=channel.position,
                        reason="Zephyr Antinuke — Category restored",
                    )
            except discord.HTTPException as e:
                log.error(f"[Antinuke] Failed to restore channel: {e}")

            # Punish perpetrator
            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized channel deletion")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            # Log action
            await self._log_action(
                guild, "Unauthorized Channel Delete",
                perp, f"#{channel.name} (restored)",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antichdl: {e}")


class AntiChannelCreate(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel):
        guild = channel.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.channel_create)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "chcr"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking channel create by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized channel create by {perp} in {guild.name} - THRESHOLD EXCEEDED")

            try:
                await channel.delete(reason="Zephyr Antinuke — Unauthorized channel creation reversed")
            except discord.HTTPException:
                pass

            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized channel creation")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            await self._log_action(
                guild, "Unauthorized Channel Create",
                perp, f"#{channel.name} (deleted)",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antichcr: {e}")


class AntiChannelUpdate(AntinukeBase):
    def __init__(self, bot: Zephyr):
        super().__init__(bot)

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        guild = after.guild
        if not self.bot.cache["antinuke"].get(guild.id):
            return

        try:
            entry = await self._get_audit_entry(guild, discord.AuditLogAction.channel_update)
            if not entry or not entry.user:
                return

            perp = entry.user
            if self._is_immune(guild, perp, "chup"):
                return
            if self._is_on_cooldown(guild.id, perp.id):
                return
            if not self._should_punish(guild.id, perp.id):
                log.info(f"[Antinuke] Tracking channel update by {perp} in {guild.name}")
                return

            log.warning(f"[Antinuke] Unauthorized channel update by {perp} in {guild.name} - THRESHOLD EXCEEDED")

            action_taken = await self._punish_perpetrator(guild, perp, "Unauthorized channel update")
            self._set_cooldown(guild.id, perp.id)
            self._reset_tracker(guild.id, perp.id)

            await self._log_action(
                guild, "Unauthorized Channel Update",
                perp, f"#{after.name}",
                action_taken
            )

        except Exception as e:
            log.error(f"[Antinuke] Error in antichup: {e}")


async def setup(bot: Zephyr):
    await bot.add_cog(AntiChannelDelete(bot))
    await bot.add_cog(AntiChannelCreate(bot))
    await bot.add_cog(AntiChannelUpdate(bot))
