# ⚡ Zephyr Bot - Quick Reference

## 🚀 Quick Start

```bash
# Windows
start.bat

# Linux/Mac
chmod +x start.sh && ./start.sh

# Manual
pip install -r requirements.txt
python main.py
```

## 📝 Configuration

Edit `config.yml`:
```yaml
bot:
  token: "YOUR_BOT_TOKEN_HERE"
  owner_ids: [YOUR_DISCORD_ID]
```

## 🎯 Essential Commands

### No-Prefix (Admin Only)
```
/np add @user 1d          - Grant 1 day no-prefix access
/np remove @user          - Revoke no-prefix access
/np list                  - List users with no-prefix
```

### Moderation
```
/warn @user reason        - Warn a user
/kick @user reason        - Kick a user
/ban @user reason         - Ban a user
/timeout @user 1h         - Timeout for 1 hour
/purge 50                 - Delete 50 messages
```

### Anti-Nuke
```
/antinuke enable          - Enable protection
/antinuke config          - Configure modules
/antinuke whitelist @user - Whitelist user
```

### Auto-Moderation
```
/automod enable           - Enable automod
/automod config           - Configure filters
/automod ignore #channel  - Ignore channel
```

### Giveaways
```
/giveaway start           - Start giveaway (interactive)
/giveaway end <id>        - End giveaway
/giveaway reroll <id>     - Reroll winners
```

### Welcome
```
/welcome setup            - Setup welcome (interactive)
/welcome test             - Test welcome message
/welcome disable          - Disable welcomes
```

### Music
```
/play <song>              - Play a song
/pause                    - Pause playback
/skip                     - Skip current song
/queue                    - View queue
/volume 50                - Set volume to 50%
```

### Utility
```
/serverinfo               - Server information
/userinfo @user           - User information
/avatar @user             - Get avatar
/ping                     - Check latency
```

## 🎨 Component Examples

### Interactive Giveaway
```python
from utils.components import GiveawaySetupView

view = GiveawaySetupView(author_id=interaction.user.id)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.confirmed:
    duration = view.duration
    winners = view.winners
```

### Whitelist Configuration
```python
from utils.components import WhitelistConfigView

view = WhitelistConfigView(author_id=interaction.user.id)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.saved:
    antinuke_perms = view.antinuke_perms
    automod_perms = view.automod_perms
    command_perms = view.command_perms
```

### Confirmation Dialog
```python
from utils.components import ConfirmView

view = ConfirmView(author_id=interaction.user.id)
await interaction.response.send_message("Are you sure?", view=view)
await view.wait()

if view.confirmed:
    # User confirmed
```

## 🎯 Emoji Reference

```python
from utils.custjis import EMOJIS, COLORS

# Status
EMOJIS["success"]    # ✅
EMOJIS["error"]      # ❌
EMOJIS["warning"]    # ⚠️
EMOJIS["loading"]    # ⏳

# Actions
EMOJIS["add"]        # ➕
EMOJIS["delete"]     # 🗑️
EMOJIS["edit"]       # ✏️
EMOJIS["settings"]   # ⚙️

# Moderation
EMOJIS["ban_hammer"] # 🔨
EMOJIS["kick"]       # 👢
EMOJIS["mute"]       # 🔇
EMOJIS["warn"]       # ⚠️

# Colors
COLORS["primary"]    # 0x5865F2
COLORS["success"]    # 0x57F287
COLORS["error"]      # 0xED4245
COLORS["warning"]    # 0xFEE75C
```

## 🔧 Troubleshooting

### Bot Won't Start
```bash
# Check Python version
python --version  # Need 3.10+

# Verify token
# Edit config.yml and check token

# Check intents
# Enable all intents in Discord Developer Portal
```

### Commands Not Showing
```bash
# Wait 1-2 hours for global sync
# Or force sync (owner only):
# Add to bot code temporarily:
await bot.tree.sync()
```

### Database Errors
```bash
# Reset databases (WARNING: deletes all data)
rm -rf db/
# Or on Windows:
rmdir /s /q db
```

### Import Errors
```bash
# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

## 📁 File Structure

```
zephyr-bot/
├── cogs/
│   ├── commands/      # Command implementations
│   ├── events/        # Event listeners
│   └── antinuke/      # Anti-nuke modules
├── core/
│   ├── Zephyr.py     # Bot core
│   └── Context.py     # Custom context
├── utils/
│   ├── components.py  # UI components
│   ├── custjis.py     # Emojis & colors
│   └── Tools.py       # Utilities
├── db/                # Databases (auto-created)
├── main.py            # Entry point
├── config.yml         # Configuration
└── requirements.txt   # Dependencies
```

## 🔗 Important Links

- [Full Documentation](README.md)
- [Setup Guide](SETUP.md)
- [Component Guide](COMPONENTS_GUIDE.md)
- [Changelog](CHANGELOG.md)

## 💡 Tips

- Test in a private server first
- Backup databases regularly
- Keep dependencies updated
- Monitor `zephyr.log` for errors
- Use `/np` for trusted users only
- Configure antinuke before enabling

## 🆘 Getting Help

1. Check [SETUP.md](SETUP.md) for detailed guides
2. Review [COMPONENTS_GUIDE.md](COMPONENTS_GUIDE.md) for component usage
3. Check logs in `zephyr.log`
4. Join support server (see config.yml)

## 📊 Quick Stats

- **Commands**: 100+ slash commands
- **Features**: 15+ categories
- **Components**: 12+ interactive views
- **Databases**: 25+ SQLite files
- **Emojis**: 50+ supported

---

**Need more help?** Check the full documentation in README.md!
