# 🎉 Welcome System - Complete Guide

The Zephyr welcome system is fully customizable, allowing you to create exactly the welcome experience you want for your server.

---

## 🚀 Quick Start

### Option 1: Quick Setup (Simple Message)
```
/greet quick channel:#welcome message:Welcome {user.mention} to {server}! You are member #{member.count}
```

### Option 2: Full Setup (Interactive Builder)
```
/greet setup channel:#welcome
```
This opens an interactive modal where you can configure:
- Message content
- Embed title
- Embed description
- Embed color
- Embed footer

---

## 📝 Available Placeholders

Use these placeholders in your welcome messages - they'll be replaced with actual values:

### User Placeholders
- `{user}` - Full username (e.g., "JohnDoe")
- `{user.mention}` - Mentions the user (e.g., @JohnDoe)
- `{user.name}` - Username without discriminator
- `{user.display}` - Display name/nickname
- `{user.id}` - User's Discord ID
- `{user.tag}` - Username with tag (e.g., "JohnDoe#1234")
- `{user.avatar}` - URL to user's avatar
- `{user.created}` - When the account was created (relative time)

### Server Placeholders
- `{server}` - Server name
- `{server.name}` - Server name (same as above)
- `{server.id}` - Server ID
- `{server.count}` - Total member count
- `{server.members}` - Total member count (same as above)
- `{member.count}` - Member number (e.g., "You are member #150")

### Time Placeholders
- `{joined.at}` - When the user joined (formatted timestamp)

---

## 🎨 Customization Options

### 1. Message Content
Plain text message sent above the embed (optional).

**Example:**
```
Welcome {user.mention}! 🎉
```

### 2. Embed Title
The title of the embed (optional).

**Example:**
```
Welcome to {server}!
```

### 3. Embed Description
Main content of the embed (optional).

**Example:**
```
Hey {user.mention}! 👋

Thanks for joining **{server}**!
You are member **#{member.count}**

Make sure to read the rules and have fun!
```

### 4. Embed Color
Hex color code for the embed (e.g., #5865F2).

**Examples:**
- `#5865F2` - Discord Blurple
- `#57F287` - Green
- `#ED4245` - Red
- `#FEE75C` - Yellow
- `#EB459E` - Pink

### 5. Embed Footer
Small text at the bottom of the embed (optional).

**Example:**
```
Member #{member.count} • Joined {joined.at}
```

### 6. Images
Add thumbnail or large image to your embed.

**Commands:**
```
/greet image image_type:Thumbnail url:https://example.com/image.png
/greet image image_type:Image url:https://example.com/banner.png
```

**Special URLs:**
- `avatar` - Uses the joining user's avatar
- `banner` - Uses the server's banner (if available)

---

## 🎯 Example Configurations

### Example 1: Simple Welcome
```
/greet quick channel:#welcome message:Welcome {user.mention} to {server}! 🎉
```

### Example 2: Detailed Embed
Using `/greet setup`:
- **Message Content:** (leave empty)
- **Embed Title:** `Welcome to {server}!`
- **Embed Description:**
  ```
  Hey {user.mention}! 👋
  
  Thanks for joining **{server}**!
  You are member **#{member.count}**
  
  📜 Read the rules in <#rules-channel>
  💬 Chat with us in <#general>
  🎮 Have fun!
  ```
- **Embed Color:** `#5865F2`
- **Embed Footer:** `Member #{member.count}`

Then add user's avatar as thumbnail:
```
/greet image image_type:Thumbnail url:avatar
```

### Example 3: Minimal Clean
Using `/greet setup`:
- **Message Content:** `{user.mention}`
- **Embed Title:** (leave empty)
- **Embed Description:** `Welcome to **{server}**! You're member #{member.count} 🎉`
- **Embed Color:** `#57F287`
- **Embed Footer:** (leave empty)

---

## ⚙️ Advanced Features

### Auto-Delete
Automatically delete welcome messages after X seconds:
```
/greet autodelete seconds:30
```
Set to `0` to disable.

**Use cases:**
- Keep welcome channel clean
- Temporary welcome messages
- Reduce clutter

### Enable/Disable
Toggle welcome messages without losing configuration:
```
/greet disable
/greet enable
```

### View Configuration
Check your current setup:
```
/greet config
```

### Test Welcome Message
Preview how it will look:
```
/greet test
```

---

## 📋 All Commands

| Command | Description |
|---------|-------------|
| `/greet setup` | Interactive welcome message builder |
| `/greet quick` | Quick setup with simple message |
| `/greet image` | Add thumbnail or image to embed |
| `/greet autodelete` | Set auto-delete timer |
| `/greet enable` | Enable welcome messages |
| `/greet disable` | Disable welcome messages |
| `/greet test` | Preview welcome message |
| `/greet config` | View current configuration |

---

## 💡 Tips & Best Practices

### 1. Use Mentions Wisely
- `{user.mention}` pings the user - use sparingly
- `{user.name}` or `{user.display}` for non-ping references

### 2. Keep It Concise
- Short, welcoming messages work best
- Use embeds for better formatting
- Don't overwhelm new members

### 3. Include Important Info
- Link to rules channel
- Mention verification steps
- Point to getting-started guides

### 4. Test Before Enabling
- Always use `/greet test` to preview
- Check on mobile and desktop
- Verify all placeholders work

### 5. Use Colors Strategically
- Match your server's branding
- Use welcoming colors (green, blue)
- Avoid harsh colors (bright red)

### 6. Consider Auto-Delete
- For high-traffic servers
- To keep welcome channel clean
- 30-60 seconds is usually good

---

## 🎨 Design Examples

### Professional Server
```
Title: Welcome to {server}
Description:
Hello {user.mention},

Welcome to our professional community!

📋 Please read our <#rules>
✅ Complete verification in <#verify>
💼 Introduce yourself in <#introductions>

We're glad to have you here!

Footer: Member #{member.count} • {server}
Color: #5865F2
Thumbnail: avatar
```

### Gaming Community
```
Message Content: {user.mention} just joined the server! 🎮

Title: Welcome Player #{member.count}!
Description:
Ready to game? Here's what to do:

🎯 Grab roles in <#roles>
🎮 Find teammates in <#lfg>
🏆 Check events in <#events>

Let's play! 🚀

Footer: GG! • {server}
Color: #FEE75C
Image: banner
```

### Friendly Community
```
Title: Hey {user.display}! 👋
Description:
Welcome to **{server}**! 

We're so happy you're here! 💖

This is a friendly space where you can:
✨ Make new friends
💬 Chat about anything
🎉 Have fun together

You're member **#{member.count}** - let's celebrate! 🎊

Footer: Joined {joined.at}
Color: #EB459E
Thumbnail: avatar
```

---

## 🔧 Troubleshooting

### Welcome messages not sending?
1. Check if enabled: `/greet config`
2. Verify bot has permissions in welcome channel
3. Ensure channel still exists
4. Test with `/greet test`

### Placeholders not working?
- Make sure you're using correct syntax: `{user.mention}` not `{{user.mention}}`
- Check spelling of placeholder names
- Some placeholders may not work in all contexts

### Images not showing?
- Verify URL is valid and accessible
- Check if using `avatar` or `banner` correctly
- Ensure bot has embed permissions

### Colors not working?
- Use hex format: `#5865F2`
- Include the `#` symbol
- Use valid hex color codes

---

## 🆘 Need Help?

- Use `/greet test` to preview changes
- Check `/greet config` for current setup
- Join our support server for assistance
- Read the placeholder list carefully

---

**Pro Tip:** Start with `/greet quick` for a simple setup, then upgrade to `/greet setup` when you want more customization!
