# 🚀 Zephyr Bot Setup Guide

Complete guide to setting up and running your Zephyr bot instance.

## 📋 Prerequisites

Before you begin, ensure you have:
- Python 3.10 or higher installed
- A Discord account
- Basic knowledge of Discord bot development
- (Optional) A server for hosting

## 🔧 Step-by-Step Setup

### 1. Create a Discord Bot

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application"
3. Give your bot a name (e.g., "Zephyr")
4. Go to the "Bot" tab
5. Click "Add Bot"
6. Under "Privileged Gateway Intents", enable:
   - ✅ Presence Intent
   - ✅ Server Members Intent
   - ✅ Message Content Intent
7. Click "Reset Token" and copy your bot token (keep it secret!)

### 2. Install Python Dependencies

```bash
# Clone the repository
git clone https://github.com/yourusername/zephyr-bot.git
cd zephyr-bot

# Install required packages
pip install -r requirements.txt

# Or using a virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Configure the Bot

1. Open `config.yml` in a text editor
2. Replace `YOUR_BOT_TOKEN_HERE` with your actual bot token
3. Update the owner IDs:
   ```yaml
   owner_ids:
     - 123456789012345678  # Your Discord user ID
   ```
   
   To get your Discord ID:
   - Enable Developer Mode in Discord (Settings → Advanced → Developer Mode)
   - Right-click your username and select "Copy ID"

4. (Optional) Configure other settings:
   - `default_prefix`: Change the default command prefix (default: `$`)
   - `spotify`: Add Spotify credentials for music features
   - `lavalink`: Configure Lavalink server for music
   - `api_keys`: Add API keys for weather and other features

### 4. Customize Emojis (Optional)

To use custom emojis instead of Unicode:

1. Upload your emojis to a Discord server where your bot is present
2. Type `\:emoji_name:` in Discord to get the emoji ID
3. Edit `utils/custjis.py`:
   ```python
   EMOJIS = {
       "success": "<:success:1234567890123456>",  # Replace with your emoji ID
       "error": "<:error:9876543210987654>",
       # ... more emojis
   }
   ```

### 5. Set Up Databases

The bot will automatically create all required databases on first run. The databases are stored in the `db/` directory.

If you want to manually initialize:
```bash
python -c "from core.Zephyr import Zephyr; import asyncio; asyncio.run(Zephyr({}).setup_hook())"
```

### 6. Run the Bot

```bash
python main.py
```

You should see output like:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
       ✦  K Y A N I T E  ✦
  Premium Discord Bot — Starting up…
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[DB] WAL mode enabled on 25 databases.
[DB] All schemas created/verified.
[Cache] Warm-up complete — all data loaded into RAM.
[Cogs] Loaded 15 cog(s), 0 failed.
[Sync] Synced 120 slash command(s) globally.
```

### 7. Invite the Bot to Your Server

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Select your application
3. Go to "OAuth2" → "URL Generator"
4. Select scopes:
   - ✅ `bot`
   - ✅ `applications.commands`
5. Select bot permissions (or use Administrator for simplicity)
6. Copy the generated URL and open it in your browser
7. Select your server and authorize

## 🎵 Music Setup (Optional)

To enable music features, you need a Lavalink server:

### Option 1: Use a Public Lavalink Server

Update `config.yml`:
```yaml
lavalink:
  host: "lava.inzeworld.com"
  port: 3128
  password: "youshallnotpass"
```

### Option 2: Host Your Own Lavalink

1. Download Lavalink from [GitHub](https://github.com/lavalink-devs/Lavalink/releases)
2. Create `application.yml`:
   ```yaml
   server:
     port: 2333
     address: 0.0.0.0
   lavalink:
     server:
       password: "youshallnotpass"
   ```
3. Run Lavalink:
   ```bash
   java -jar Lavalink.jar
   ```
4. Update `config.yml` with your Lavalink details

### Spotify Integration

1. Go to [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
2. Create a new app
3. Copy Client ID and Client Secret
4. Update `config.yml`:
   ```yaml
   spotify:
     client_id: "your_client_id"
     client_secret: "your_client_secret"
   ```

## 🔐 Security Best Practices

### Protect Your Token
- ❌ Never commit `config.yml` with your token to Git
- ✅ Add `config.yml` to `.gitignore`
- ✅ Use environment variables for production:
  ```python
  import os
  token = os.getenv("DISCORD_TOKEN")
  ```

### Database Backups
```bash
# Backup all databases
cp -r db/ db_backup_$(date +%Y%m%d)/

# Or use a cron job for automatic backups
0 0 * * * cp -r /path/to/bot/db/ /path/to/backups/db_$(date +\%Y\%m\%d)/
```

### Permissions
- Only grant Administrator permission if absolutely necessary
- Use specific permissions for better security
- Regularly audit bot permissions

## 🐛 Troubleshooting

### Bot doesn't start
- Check if your token is correct in `config.yml`
- Ensure all intents are enabled in Discord Developer Portal
- Verify Python version: `python --version` (should be 3.10+)

### Commands not showing up
- Wait 1-2 hours for global commands to sync
- Try using guild-specific sync for testing:
  ```python
  # In core/Zephyr.py, modify setup_hook:
  synced = await self.tree.sync(guild=discord.Object(id=YOUR_GUILD_ID))
  ```

### Database errors
- Delete the `db/` folder and restart (will reset all data)
- Check file permissions
- Ensure SQLite is installed

### Music not working
- Verify Lavalink server is running
- Check Lavalink credentials in `config.yml`
- Ensure bot has "Connect" and "Speak" permissions in voice channels

### Import errors
```bash
# Reinstall dependencies
pip install --upgrade -r requirements.txt

# Or force reinstall
pip install --force-reinstall -r requirements.txt
```

## 📊 Monitoring

### Logs
- Bot logs are saved to `zephyr.log`
- View real-time logs: `tail -f zephyr.log`
- Rotate logs to prevent large files

### Performance
```python
# Check bot stats
/utility stats  # Shows memory usage, uptime, etc.
```

## 🚀 Production Deployment

### Using systemd (Linux)

1. Create service file `/etc/systemd/system/zephyr.service`:
```ini
[Unit]
Description=Zephyr Discord Bot
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/zephyr-bot
ExecStart=/path/to/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

2. Enable and start:
```bash
sudo systemctl enable zephyr
sudo systemctl start zephyr
sudo systemctl status zephyr
```

### Using Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .
CMD ["python", "main.py"]
```

```bash
docker build -t zephyr-bot .
docker run -d --name zephyr --restart unless-stopped zephyr-bot
```

### Using PM2 (Node.js process manager)

```bash
npm install -g pm2
pm2 start main.py --name zephyr --interpreter python3
pm2 save
pm2 startup
```

## 🔄 Updating

```bash
# Pull latest changes
git pull origin main

# Update dependencies
pip install --upgrade -r requirements.txt

# Restart bot
# systemd: sudo systemctl restart zephyr
# pm2: pm2 restart zephyr
# docker: docker restart zephyr
```

## 📚 Additional Resources

- [discord.py Documentation](https://discordpy.readthedocs.io/)
- [Discord Developer Portal](https://discord.com/developers/docs)
- [Zephyr Documentation](https://docs.zephyr.bot)
- [Support Server](https://discord.gg/YOUR_SERVER)

## 💡 Tips

- Test commands in a private server first
- Use `/sync` command to force command sync (owner only)
- Monitor bot performance with `/utility stats`
- Regularly backup your databases
- Keep dependencies updated for security patches

---

Need help? Join our [Support Server](https://discord.gg/YOUR_SERVER)!
