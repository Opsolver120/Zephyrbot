# 🎨 Discord Components v2 Guide

Complete guide to using Zephyr's rich interactive components.

## 📚 Overview

Zephyr uses Discord Components v2 to provide a premium, interactive user experience. All components are embedded directly in messages with select menus and buttons.

## 🧩 Available Components

### 1. GemView (Base View)

The foundation for all interactive views. Automatically includes Support and Docs link buttons.

```python
from utils.components import GemView

view = GemView(timeout=180.0, add_links=True)
await interaction.response.send_message("Hello!", view=view)
```

**Features:**
- Auto-timeout handling
- Support/Docs link buttons in bottom row
- Automatic button disabling on timeout

### 2. ConfirmView

Simple confirmation dialog with Confirm/Cancel buttons.

```python
from utils.components import ConfirmView

view = ConfirmView(author_id=interaction.user.id, timeout=30.0)
await interaction.response.send_message("Are you sure?", view=view)
await view.wait()

if view.confirmed:
    # User clicked Confirm
    pass
elif view.confirmed is False:
    # User clicked Cancel
    pass
else:
    # Timeout
    pass
```

**Use Cases:**
- Dangerous actions (ban, kick, purge)
- Configuration changes
- Deletion confirmations

### 3. NPConfigView

Interactive No-Prefix management panel with duration selection.

```python
from utils.components import NPConfigView
from utils.Tools import create_embed

view = NPConfigView(author_id=interaction.user.id, target_user=user)
embed = create_embed(
    title=f"No-Prefix Configuration for {user.display_name}",
    description="Select duration and action below",
    color=COLORS["premium"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.action_taken == "grant":
    duration = view.selected_duration
    # Grant NP access with duration
elif view.action_taken == "revoke":
    # Revoke NP access
```

**Features:**
- Duration select menu (10m, 1h, 1d, 1w, 1m, lifetime)
- Grant/Revoke action buttons
- Embedded in message

### 4. GiveawaySetupView

Multi-step giveaway configuration with duration and winner selection.

```python
from utils.components import GiveawaySetupView

view = GiveawaySetupView(author_id=interaction.user.id)
embed = create_embed(
    title="🎉 Giveaway Setup",
    description="Configure your giveaway below",
    color=COLORS["gold"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.confirmed:
    duration = view.duration  # e.g., "1d"
    winners = view.winners    # e.g., 3
    # Create giveaway
```

**Features:**
- Duration select (5m to 1 week)
- Winner count select (1-10)
- Start/Cancel buttons
- Rich emoji feedback

### 5. WelcomeSetupView

Interactive welcome message configuration.

```python
from utils.components import WelcomeSetupView

view = WelcomeSetupView(author_id=interaction.user.id)
embed = create_embed(
    title="👋 Welcome Message Setup",
    description="Customize your welcome messages",
    color=COLORS["primary"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.saved:
    message_type = view.message_type    # "simple", "embed", "image"
    embed_color = view.embed_color      # "zephyr", "success", etc.
    auto_delete = view.auto_delete      # seconds, 0 = never
    # Save configuration
```

**Features:**
- Message type select (text, embed, image)
- Color picker for embeds
- Auto-delete duration
- Save button

### 6. ModerationActionView

Quick moderation panel with action buttons.

```python
from utils.components import ModerationActionView

actions = ["warn", "kick", "ban", "timeout", "mute"]
view = ModerationActionView(
    author_id=interaction.user.id,
    target=member,
    actions=actions
)
embed = create_embed(
    title=f"Moderate {member.display_name}",
    description="Select an action below",
    color=COLORS["warning"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.selected_action:
    action = view.selected_action  # "warn", "kick", etc.
    # Perform moderation action
```

**Features:**
- Dynamic action buttons
- Color-coded by severity
- Cancel button
- Embedded in message

### 7. RoleManagementView

Interactive role management with add/remove buttons.

```python
from utils.components import RoleManagementView

roles = [role for role in guild.roles if role < guild.me.top_role]
view = RoleManagementView(
    author_id=interaction.user.id,
    target=member,
    roles=roles
)
embed = create_embed(
    title=f"Manage Roles for {member.display_name}",
    description="Select roles and action",
    color=COLORS["primary"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.action == "add":
    roles_to_add = view.selected_roles
    await member.add_roles(*roles_to_add)
elif view.action == "remove":
    roles_to_remove = view.selected_roles
    await member.remove_roles(*roles_to_remove)
```

**Features:**
- Multi-select role menu
- Add/Remove buttons
- Shows member count per role
- Supports up to 25 roles

### 8. WhitelistConfigView

Ultra-premium whitelist configuration with 3 select menus.

```python
from utils.components import WhitelistConfigView

view = WhitelistConfigView(author_id=interaction.user.id)
embed = create_embed(
    title=f"Whitelist Configuration for {target.display_name}",
    description="Configure permissions across all systems",
    color=COLORS["premium"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.saved:
    antinuke_perms = view.antinuke_perms      # ["ban", "kick", ...]
    automod_perms = view.automod_perms        # ["spam", "links", ...]
    command_perms = view.command_perms        # ["warn", "ban", ...]
    # Save to database
```

**Features:**
- 3 separate select menus:
  1. Antinuke Bypass (ban, kick, channels, roles, etc.)
  2. Automod Immunity (spam, links, caps, invites)
  3. Command Access (warn, ban, mute, purge, lock)
- Save button
- Rich emoji descriptions

### 9. AntinukeSetupView

Interactive antinuke module configuration.

```python
from utils.components import AntinukeSetupView

current_settings = {
    "ban": True,
    "kick": False,
    # ... more modules
}
view = AntinukeSetupView(
    author_id=interaction.user.id,
    current_settings=current_settings
)
embed = create_embed(
    title="☢️ Antinuke Configuration",
    description="Toggle protection modules",
    color=COLORS["error"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.saved:
    enabled_modules = view.selected_modules
    # Update database
```

**Features:**
- Multi-select for modules
- Shows current state
- Save button
- Support/Docs links

### 10. AutomodSetupView

Interactive automod filter configuration.

```python
from utils.components import AutomodSetupView

view = AutomodSetupView(author_id=interaction.user.id)
embed = create_embed(
    title="🤖 Automod Configuration",
    description="Select filters to enable",
    color=COLORS["primary"]
)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.saved:
    enabled_filters = view.selected_filters
    # Update database
```

**Features:**
- Filter selection (spam, links, invites, caps, mass mention, NSFW)
- Save button
- Rich descriptions

### 11. PaginatedView

Paginated embed viewer with navigation buttons.

```python
from utils.components import PaginatedView

pages = [embed1, embed2, embed3]
view = PaginatedView(
    pages=pages,
    author_id=interaction.user.id,
    timeout=120.0
)
await interaction.response.send_message(embed=pages[0], view=view)
```

**Features:**
- First/Previous/Next/Last buttons
- Auto-disable at boundaries
- Page tracking
- Timeout handling

### 12. TicketPanelView

Persistent ticket creation panel.

```python
from utils.components import TicketPanelView

view = TicketPanelView()
embed = create_embed(
    title="🎫 Support Tickets",
    description="Select a category and create a ticket",
    color=COLORS["primary"]
)
await channel.send(embed=embed, view=view)
# View persists across bot restarts
```

**Features:**
- Category selection (general, bug, feature, account, other)
- Create ticket button
- Persistent (timeout=None)
- Support/Docs links

## 🎯 Best Practices

### 1. Always Use Embeds with Views

```python
# ✅ Good
embed = create_embed(title="Title", description="Description")
view = GemView()
await interaction.response.send_message(embed=embed, view=view)

# ❌ Bad
view = GemView()
await interaction.response.send_message("Plain text", view=view)
```

### 2. Set Appropriate Timeouts

```python
# Quick actions: 30-60 seconds
view = ConfirmView(author_id=user.id, timeout=30.0)

# Configuration: 120-180 seconds
view = WhitelistConfigView(author_id=user.id)  # Default 120s

# Persistent panels: None
view = TicketPanelView()  # timeout=None
```

### 3. Always Check Author

All views automatically check if the interacting user is the author:

```python
if interaction.user.id != self.author_id:
    return await interaction.response.send_message(
        f"{EMOJIS['denied']} Not your panel.",
        ephemeral=True
    )
```

### 4. Handle Timeouts

```python
view = MyView(author_id=user.id)
await interaction.response.send_message(embed=embed, view=view)
await view.wait()

if view.confirmed is None:
    # Timeout occurred
    await interaction.followup.send("Timed out!", ephemeral=True)
```

### 5. Use Rich Emojis

```python
from utils.custjis import EMOJIS

# Always use emojis from custjis
discord.SelectOption(
    label="Ban",
    value="ban",
    emoji=EMOJIS.get("ban_hammer", "🔨"),  # Fallback to Unicode
    description="Allow banning members"
)
```

## 🎨 Styling Guidelines

### Colors

```python
from utils.custjis import COLORS

# Success actions
color=COLORS["success"]  # Green

# Errors/Dangerous actions
color=COLORS["error"]     # Red

# Warnings
color=COLORS["warning"]   # Yellow

# Info/Primary
color=COLORS["primary"]   # Discord Blurple

# Premium features
color=COLORS["premium"]   # Purple
```

### Button Styles

```python
# Success/Confirm
style=discord.ButtonStyle.success

# Danger/Delete/Cancel
style=discord.ButtonStyle.danger

# Primary actions
style=discord.ButtonStyle.primary

# Secondary/Neutral
style=discord.ButtonStyle.secondary

# Links (external)
style=discord.ButtonStyle.link
```

### Emoji Usage

```python
# Status
EMOJIS["success"]   # ✅
EMOJIS["error"]     # ❌
EMOJIS["warning"]   # ⚠️
EMOJIS["loading"]   # ⏳

# Actions
EMOJIS["add"]       # ➕
EMOJIS["delete"]    # 🗑️
EMOJIS["edit"]      # ✏️
EMOJIS["settings"]  # ⚙️

# Moderation
EMOJIS["ban_hammer"] # 🔨
EMOJIS["kick"]       # 👢
EMOJIS["mute"]       # 🔇
EMOJIS["warn"]       # ⚠️
```

## 📝 Example: Complete Command

```python
@app_commands.command(name="setup", description="Setup welcome messages")
async def welcome_setup(self, interaction: discord.Interaction):
    # Defer if needed
    await interaction.response.defer(ephemeral=True)
    
    # Create view
    view = WelcomeSetupView(author_id=interaction.user.id)
    
    # Create embed
    embed = create_embed(
        title=f"{EMOJIS['a_wave']} Welcome Message Setup",
        description=(
            f"{EMOJIS['info']} Configure how new members are welcomed!\n\n"
            f"{EMOJIS['message']} **Message Type**: Choose text, embed, or image\n"
            f"{EMOJIS['palette']} **Color**: Select embed color\n"
            f"{EMOJIS['delete']} **Auto-Delete**: Set message lifetime\n\n"
            f"{EMOJIS['arrow_down']} Use the menus below to configure"
        ),
        color=COLORS["primary"],
        thumbnail=interaction.guild.icon.url if interaction.guild.icon else None
    )
    embed.set_footer(
        text=f"Requested by {interaction.user.display_name}",
        icon_url=interaction.user.display_avatar.url
    )
    
    # Send with view
    await interaction.followup.send(embed=embed, view=view, ephemeral=True)
    
    # Wait for interaction
    await view.wait()
    
    # Handle result
    if view.saved:
        # Save to database
        async with aiosqlite.connect("db/welcome.db") as db:
            await db.execute(
                "INSERT OR REPLACE INTO welcome VALUES (?, ?, ?, ?, ?)",
                (
                    interaction.guild.id,
                    view.message_type,
                    view.embed_color,
                    view.auto_delete,
                    1  # enabled
                )
            )
            await db.commit()
        
        # Success message
        success_embed = create_embed(
            description=f"{EMOJIS['success']} Welcome messages configured!",
            color=COLORS["success"]
        )
        await interaction.followup.send(embed=success_embed, ephemeral=True)
    else:
        # Timeout or cancel
        await interaction.followup.send(
            f"{EMOJIS['error']} Setup cancelled or timed out.",
            ephemeral=True
        )
```

## 🚀 Advanced Usage

### Custom Views

Create your own views by extending `GemView`:

```python
from utils.components import GemView

class MyCustomView(GemView):
    def __init__(self, author_id: int):
        super().__init__(timeout=120.0, add_links=True)
        self.author_id = author_id
        self.result = None
        
        # Add your components
        self.add_item(MyButton())
        self.add_item(MySelect())
    
    async def on_timeout(self):
        # Custom timeout handling
        await super().on_timeout()
        # Your code here
```

### Dynamic Components

```python
# Generate options dynamically
options = [
    discord.SelectOption(
        label=role.name,
        value=str(role.id),
        emoji=EMOJIS["role"]
    )
    for role in guild.roles[:25]
]

select = discord.ui.Select(
    placeholder="Select roles",
    options=options,
    min_values=1,
    max_values=len(options)
)
```

### Persistent Views

For views that persist across bot restarts:

```python
class PersistentView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(
        label="Click Me",
        custom_id="persistent_button",  # Important!
        style=discord.ButtonStyle.primary
    )
    async def button_callback(self, interaction, button):
        await interaction.response.send_message("Clicked!")

# Register in bot setup
bot.add_view(PersistentView())
```

---

For more examples, check the `cogs/commands/` directory!
