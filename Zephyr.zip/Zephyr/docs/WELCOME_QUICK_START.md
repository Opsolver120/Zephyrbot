# 🚀 Welcome System - Quick Start

## 30-Second Setup

### Option 1: Simple Message (Fastest)
```
/greet quick channel:#welcome message:Welcome {user.mention} to {server}! 🎉
```
✅ Done! Test with `/greet test`

---

### Option 2: Custom Embed (Recommended)
```
/greet setup channel:#welcome
```
Fill in the form that appears:
1. **Message Content:** (optional) Text above embed
2. **Embed Title:** Welcome to {server}!
3. **Embed Description:** Hey {user.mention}! You're member #{member.count}
4. **Embed Color:** #5865F2
5. **Embed Footer:** Member #{member.count}

✅ Done! Test with `/greet test`

---

## 🎨 Add User Avatar (Optional)
```
/greet image image_type:Thumbnail url:avatar
```

---

## ⏱️ Auto-Delete After 30s (Optional)
```
/greet autodelete seconds:30
```

---

## 🔍 Preview Your Welcome
```
/greet test
```

---

## 📋 Most Used Placeholders

| Placeholder | Result |
|-------------|--------|
| `{user.mention}` | @Username (pings user) |
| `{user.name}` | Username (no ping) |
| `{server}` | Server name |
| `{member.count}` | Member number (e.g., 150) |

[See all placeholders →](WELCOME_SYSTEM_GUIDE.md#-available-placeholders)

---

## 💡 Quick Examples

### Minimal
```
/greet quick channel:#welcome message:{user.mention} joined! Member #{member.count}
```

### Friendly
```
/greet setup
Title: Welcome {user.display}! 👋
Description: Thanks for joining {server}! You're member #{member.count} 🎉
Color: #57F287
```

### Professional
```
/greet setup
Title: Welcome to {server}
Description: Hello {user.mention}, please read <#rules> and verify in <#verify>
Color: #5865F2
Footer: Member #{member.count}
```

---

## 🛠️ Useful Commands

| Command | What it does |
|---------|--------------|
| `/greet test` | Preview your welcome |
| `/greet config` | View current setup |
| `/greet disable` | Turn off (keeps config) |
| `/greet enable` | Turn back on |

---

## 🆘 Need Help?

📖 [Full Guide](WELCOME_SYSTEM_GUIDE.md) - Complete documentation  
💬 Support Server - Get help from the community

---

**That's it! Your welcome system is ready to go! 🎉**
