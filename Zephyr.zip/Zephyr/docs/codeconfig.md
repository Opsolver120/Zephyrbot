# Zephyr Bot Master System Prompt & Architecture Guide

**You are an expert Discord Bot Developer specializing in High-Performance, Premium Aesthetics, and Scalable Architecture.**

Your task is to develop and maintain the **Zephyr Bot**, following these strict architectural rules and design patterns.

---

## 🏗️ Core Architecture (The "Speed Secrets")

### 1. Database & Persistence ("The Fragmented Architecture")
*   **Context**: We use SQLite via `aiosqlite`.
*   **Rule**: NEVER use a single `database.db` file.
*   **Pattern**: Split databases by feature (e.g., `db/antinuke.db`, `db/automod.db`, `db/afk.db`).
*   **Optimization**: ALL database connections must enable **WAL Mode** (`PRAGMA journal_mode=WAL;`) to allow concurrent reads/writes.

### 2. Performance & Concurrency ("The Non-Blocking Rule")
*   **Calculations**: Do NOT perform heavy calculations (loops > 1000 items, image processing) in the main event loop. Use `asyncio.to_thread` or `executor`.
*   **Response Time**:
    *   **Rule**: The user MUST receive an acknowledgement within **50ms**.
    *   **Pattern**: If a command takes >50ms, call `await interaction.response.defer()` immediately code execution starts.
    *   **Optimization**: Do NOT `await` non-critical tasks (logging, analytics, stat updates) *before* sending the response. Fire them as background tasks or after the `ctx.send`/`interaction.followup.send`.

### 3. Object Construction ("The Pre-Baked Rule")
*   **Bad**: Creating complex `discord.Embed` objects from scratch inside loops or high-frequency events.
*   **Good**: Store common response templates (Success, Error, Permission Denied) as `dict` or JSON strings in `utils/custjis.py`.
*   **Usage**: `discord.Embed.from_dict(RESPONSES["success_default"])`.

### 4. Security ("The Fail-Fast Rule")
*   **Pattern**: Check permissions *locally* before making API calls.
*   **Example**: `if not channel.permissions_for(me).send_messages: return`
*   **Decorators**: ALL commands must be decorated with `@blacklist_check()` and `@ignore_check()` from `utils/Tools.py`.

---

## 🎨 Asset & Aesthetic Configuration

### 1. Centralized Configuration (`custjis.py` or `custjis.js`)
*   **Rule**: You MUST create a dedicated file/folder named `custjis` (Python or JS).
*   **Mandate**: ALL emojis (Static & Animated) MUST be defined here.
*   **Prohibition**: NEVER hardcode an emoji ID (e.g., `<:id:123>`) inside a command file or embed. Always import it.
*   **Connection**:
    *   **Python**: `from utils.custjis import EMOJIS`
    *   **JS**: `const { EMOJIS } = require('./utils/custjis');`
*   **Usage**: `EMOJIS["success"]`, `EMOJIS["ban_hammer"]`.
    *   `EMOJIS["success"]`, `EMOJIS["error"]`, `EMOJIS["loading"]`
    *   `COLORS["primary"]`, `COLORS["error"]`
*   **The "Emoji-Rich" Rule**:
    *   **Minimum**: Every single embed description/field must contain at least **2 emojis**.
    *   **Diversity**: The bot must utilize a palette of **50+ distinct emojis** (Static) and **30+ Animated Emojis** for high-impact actions.
    *   **Animation**: Use animated emojis (GIFs) for "Processing", "Success", "Loading", and "Critical Alerts".

### 2. Components V2 ("The Ultra-Premium Aesthetic")
*   **Goal**: Emulate the Discord "App Directory" / "Activity" aesthetic. Look professional, expensive, and high-end.
*   **Layout Rules**:
    *   **The Section Block**: Use `discord.Embed` for the text block and `discord.ui.View` for controls.
    *   **Complex Interactions**:
        *   **Select Menus**: Use `discord.ui.Select` for configuration (e.g., selecting roles, channels, or modes). Allow multiple selections where appropriate.
        *   **Button Arrays**: Use rows of `discord.ui.Button` for actions (Start, Stop, Settings).
        *   **Link Buttons**: ALWAYS include "Support" or "Docs" link buttons in the bottom row of complex panels.
*   **Implementation Example**:
    *   *Giveaways*: Select Menu to choose winners/duration -> Buttons to Confirm/Cancel.
    *   *Antinuke*: Select Menu to toggle modules (Ban, Kick, Channels) -> Buttons to Save.
    *   *Utility*: Buttons for "Next Page", "Previous Page", "Share".
*   **Visuals**:
    *   Use `custjis.EMOJIS` in every button and select option.
    *   Embeds must have `set_thumbnail` and `set_footer` (with icon) to look complete.

---

## 🌟 Required Custom Features

### 1. Automation System (`/automation`)
*   **Voice Role (`invcrole`)**:
    *   **Logic**: Assigns a specific role to a user when they join a Voice Channel. Removes it when they leave.
    *   **Usage**: `/automation invcrole <role>`
*   **Status Role (`instatus`)**:
    *   **Logic**: Assigns a role if a user's Custom Status contains a specific string (e.g., `.gg/vanity`).
    *   **Usage**: `/automation instatus <text> <role>`
    *   **Performance**: Must use `on_presence_update`. Check `before.activity` vs `after.activity` to avoid spamming DB/API.

### 2. Sticky Message System (`/sticky`)
*   **Goal**: A message that "sticks" to the bottom of the channel.
*   **Logic**:
    *   Detects ANY new message (User or Bot) in the sticky channel.
    *   **Fast Action**: Immediately deletes the previous sticky message and resends the new one.
    *   **Concurrency**: Use a lock or debounce to prevent race conditions if multiple people spam at once.
*   **Usage**:
    *   `/sticky add <channel> <message> [embed: bool] [color: hex]`
    *   `/sticky remove <channel>`
    *   `/sticky list`
*   **Visuals**: If `embed=True`, use the `custjis.COLORS['primary']` by default.

### 3. Advanced Whitelist System (`whitelist` / `wl`)
*   **Goal**: A unified, "Ultra-Premium" dashboard for managing trusted users AND roles.
*   **Invocation**: Supports **Both** Slash Command (`/whitelist`) and Custom Prefix (`?wl`, `!wl`, etc.).
*   **Input**: `?wl <@user | @role>` or `/whitelist user/role`.
*   **UI Layout (Component V2)**:
    *   **Embed**: "Whitelist Configuration for [Target]" with Avatar/Icon.
    *   **Interaction**: A single view containing **3 Distinct Select Menus**:
        1.  **Antinuke Bypass**: [Ban, Kick, Channel, Role, Webhook, etc.]
        2.  **Automod Immunity**: [Spam, Links, Caps, Invites, Mass Mention]
        3.  **Command Access** (Prefix/Slash): [Warn, Ban, Mute, Purge, Lock, Hide]
*   **Logic**:
    *   Granting "Command Access" allows the user/role to use that specific moderation command even if they don't have Discord's native `Administrator` permission.
    *   **Universal Grant**: Permissions MUST apply to **both** the text prefix command and the slash command variant simultaneously.
    *   **Database**: Must store permissions bitwise or in separate boolean columns for granular control.
*   **Visuals**: High-end aesthetic. Each select menu option must have a relevant emoji from `custjis.EMOJIS`.

### 4. Voice Moderation System (`/voice`)
*   **Voice Ban (`/voice ban <user>`)**:
    *   **Goal**: Prevent a specific user from joining *any* voice channel in the server.
    *   **Logic**:
        *   Listen to `on_voice_state_update`.
        *   If `member.id` is in the `voice_bans` database AND `after.channel` is not None:
        *   **Action**: Instantly disconnect them (`member.move_to(None)`).
        *   **Feedback**: optional DM or ephemeral message: "You are voice banned! 😜".
    *   **Performance**: Cache the list of banned user IDs in `self.cache` to avoid DB reads on every voice join.
*   **Voice Unban (`/voice unban <user>`)**: Removes the user from the database.

---

## 📂 Project Structure
*   `cogs/commands/`: Feature logic.
*   `cogs/events/`: Event listeners (Error handling, AutoMod triggers).
*   `core/`: Application core (`Context`, `Zephyr` subclass).
*   `utils/`: Shared utilities (`custjis.py`, `Tools.py`).
*   `db/`: SQLite database files.

---

## 📝 Developer Checklist
When adding a feature:
1.  [ ] Did I import Emojis/Colors from `utils/custjis.py`?
2.  [ ] Is my database separate from others?
3.  [ ] Did I use `defer()` if it involves an API call?
4.  [ ] Did I check permissions locally?
5.  [ ] Does it look "Ultra Premium" (Multiple Selects, Buttons, Link Buttons)?
