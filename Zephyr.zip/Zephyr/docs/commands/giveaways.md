# Giveaway System Documentation

## Overview
The Giveaway system allows server administrators to host, manage, and automatically end giveaways. It supports custom prizes, multiple winners, and duration parsing.

## Database Connection
*   `db/giveaways.db`: Stores active giveaway data.
*   **Schema**:
    *   `guild_id`, `host_id`, `start_time`, `ends_at`, `prize`, `winners`, `message_id`, `channel_id`.

## Commands
*   `/gstart <time> <winners> <prize>`: Starts a new giveaway.
    *   **Time Format**: `s` (seconds), `m` (minutes), `h` (hours), `d` (days). Max 31 days.
    *   **Constraints**: Max 15 winners, Max 5 concurrent giveaways per guild.
*   `/gend [message_id]`: Ends a giveaway immediately.
    *   Picks winners and updates the embed.
*   `/greroll [message_id]`: Rerolls a new winner for an ended giveaway.
*   `/glist`: Lists all currently active giveaways in the server.

## Logic
*   **Participation**: Users react with 🎉 to join.
*   **Ending**:
    *   A background task (`GiveawayEnd` loop) checks every 5 seconds for giveaways where `ends_at <= now`.
    *   Winners are selected using `random.sample`.
    *   The bot updates the original message to "GIVEAWAY ENDED" and mentions winners.
    *   If not enough participants, the giveaway is cancelled.
*   **Persistence**: Active giveaways survive bot restarts due to SQLite storage.
