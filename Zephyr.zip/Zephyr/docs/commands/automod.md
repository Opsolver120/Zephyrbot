# Automod System Documentation

## Overview
The Automod system filters chat content to prevent spam, toxicity, and unauthorized advertising. It is designed to be highly configurable with "Ignore" lists and variable punishments.

## Database Connection
*   **File**: `db/automod.db`
*   **Key Tables**:
    *   `automod`: Master toggle (`guild_id`, `enabled`).
    *   `automod_punishments`: Maps specific events (e.g., "Anti Spam") to actions ("Mute", "Ban").
    *   `automod_ignored`: Stores whitelisted channels and roles.
    *   `automod_logging`: Stores the ID of the log channel.

### Database Schema (For Developers)
```sql
CREATE TABLE IF NOT EXISTS automod (
    guild_id INTEGER PRIMARY KEY,
    enabled INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS automod_punishments (
    guild_id INTEGER,
    event TEXT,
    punishment TEXT,
    PRIMARY KEY (guild_id, event)
);
CREATE TABLE IF NOT EXISTS automod_ignored (
    guild_id INTEGER,
    type TEXT, -- 'channel' or 'role'
    id INTEGER,
    PRIMARY KEY (guild_id, type, id)
);
```

## Commands

### `/automod enable`
*   **Description**: Opens an interactive setup menu.
*   **Logic**:
    1.  User selects which filters to enable (Spam, Caps, Links, Invites, etc.).
    2.  **Special Optimization**: For **Anti NSFW**, the bot creates a native **Discord AutoMod Rule**. This offloads the processing to Discord's servers, saving bot CPU/Bandwidth.

### `/automod punishment`
*   **Description**: Configures what happens when a user trips a filter.
*   **Options**: Mute (Timeout), Kick, Ban.

### `/automod ignore <channel/role>`
*   **Description**: Whitelists specific channels or roles from *all* automod checks.
*   **Logic**: Updates `automod_ignored` table. Code checks this table *before* processing message content.

## Word Blacklist
A separate but related system for blocking specific words/phrases.
*   **File**: `cogs/commands/blacklist.py`
*   **Database**: `db/blword.db`
*   **Commands**:
    *   `/blacklistword add <word>`: Adds a word to the blocklist.
    *   `/blacklistword remove <word>`: Removes a word.
    *   `/blacklistword config`: Lists all blacklisted words.
    *   `/blacklistword bypass add/remove <user/role>`: Whitelists specific users/roles from the blacklist check.
*   **Logic**:
    *   Checks every message content against the list.
    *   If a match is found, the message is **deleted** and a temporary warning is sent.
    *   Ignores Admins and Bypassed users/roles.

## Key Logic & Internals
*   **Event Listeners**: `cogs/automod/antispam.py`, `antilink.py`, etc.
*   **Performance Tricks**:
    *   **Native Rules**: Uses `interaction.guild.create_automod_rule` for regex/keyword matching where possible.
    *   **RAM Caching**: Spam detection uses an in-memory dictionary `recent_messages` to track message frequency without hitting the DB.
*   **Integration**: Automatically updates Discord Native AutoMod exemptions when you use `/automod ignore`.
