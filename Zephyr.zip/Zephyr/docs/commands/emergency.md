# Emergency / Raid Mode System Documentation

## Overview
The Emergency system (also known as Raid Mode or "Panic Button") is a high-security module designed to instantly secure the server during a raid or rogue admin attack. It allows the **Server Owner** or **Authorized Users** to strip dangerous permissions from specified roles and lock down the hierarchy.

## Database Connection
*   **File**: `db/emergency.db`
*   **Tables**:
    *   `authorised_users`: Users allowed to trigger emergency mode.
    *   `emergency_roles`: List of roles to be affected by the emergency command.
    *   `restore_roles`: Backup of permissions removed during an emergency, used for restoration.
    *   `role_positions`: Backup of role positions (not fully utilized in current logic but present).

## Commands

### `/emergency` (Group)
*   **Aliases**: `/emg`
*   **Description**: Main entry point for configuration.

#### `/emergency enable`
*   **Usage**: Enables the system and **automatically detects** and adds roles with dangerous permissions (Admin, Ban, Kick, Manage Channels/Roles/Guild) to the `emergency_roles` database.
*   **Safety**: Skips roles higher than the bot or managed roles (integration roles).

#### `/emergency disable`
*   **Usage**: Disables the system and clears the tracked role list.

#### `/emergency authorise add/remove/list`
*   **Usage**: Manage users (other than the Owner) who can trigger the panic button.
*   **Limit**: Max 5 authorized users.

#### `/emergency role add/remove/list`
*   **Usage**: Manually manage the list of roles to be stripped.

### `/emergencysituation`
*   **Aliases**: `/emgs`, `/..`
*   **Description**: **THE PANIC BUTTON**.
*   **Logic**:
    1.  **Deletes** `antinuke` config (to prevent the bot from nuking itself during changes).
    2.  Iterates through all roles in `emergency_roles`.
    3.  **Removes** the following permissions:
        *   Administrator
        *   Ban Members
        *   Kick Members
        *   Manage Channels
        *   Manage Roles
        *   Manage Guild
    4.  **Saves** the removed permissions to `restore_roles` table.
    5.  **Moves** the role with the most members to a position just below the bot (to curb mass-mention capabilities or hierarchy abuse), if possible.
    6.  Re-enables Antinuke.

### `/emergencyrestore`
*   **Aliases**: `/emgrestore`, `/...`, `/emgbackup`
*   **Description**: Restores permissions to roles after the threat is gone.
*   **Safety**: Includes a "Yes/No" confirmation button.

## Security Features
*   **Authorisation Check**: Only Server Owner + Whitelisted IDs + Database Authorised Users can run these commands.
*   **Fail-Safe**: Ignores roles higher than the bot to prevent permission errors.
*   **Backup**: Always saves state before modifying, ensuring 100% reversibility.
