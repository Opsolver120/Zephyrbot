# Music System Documentation

## Overview
The Music system is a high-quality audio player powered by **Wavelink** (Lavalink wrapper). It supports tracking from YouTube, Spotify, JioSaavn, and SoundCloud.

## Dependencies & Infrastructure
*   **Library**: `wavelink`
*   **Audio Nodes**: Connects to `lava.inzeworld.com:3128` (Hardcoded in `music.py` - *Developer Note: Move this to config.yml*).
*   **Spotify Integration**: Uses a custom `SpotifyAPI` class with `aiohttp` to resolve Spotify tracks/playlists into YouTube search queries.

## Commands

### `/play <query>`
*   **Description**: Plays a song or playlist.
*   **Logic**:
    1.  Checks user voice state.
    2.  Resolves query:
        *   **Spotify**: Fetches metadata via Spotify API -> Searches on YouTube -> Plays YouTube track.
        *   **Other**: Searches directly via Wavelink.
    3.  Adds to queue.

### `/search <query>`
*   **Description**: Interactive search.
*   **UI**: Buttons for **YouTube**, **JioSaavn**, **SoundCloud**.
*   **Logic**: User clicks platform -> Bot searches -> Returns top 5 results -> User selects track.

### Player Controls
The bot provides an interactive Embed with buttons:
*   **Autoplay**: Toggles infinite autoplay (similar tracks).
*   **Loop**: Toggles Queue Loop.
*   **Shuffle**: Randomizes queue.
*   **Seek**: Rewind/Forward 10s.
*   **Filters**: Pause, Resume, Stop, Skip, Previous.

## Key Internals
*   **Inactivity Monitor**:
    *   `monitor_inactivity()`: Background task checks every 60s.
    *   Disconnects if the bot is alone in VC for > 120s.
*   **Image Generation**:
    *   `display_player_embed`: Uses `PIL` (Pillow) to generate a "Now Playing" card with circular album art and progress info.
    *   Path: `data/pictures/player.png` (Template).

## Configuration
*   **Spotify Credentials**: Hardcoded in `cogs/commands/music.py` (Client ID/Secret).
