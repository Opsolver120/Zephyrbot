# Voice Moderation System Documentation

## Overview
The Voice Moderation cog provides administrative tools to manage voice channels and their members. It allows for mass-moving, muting, deafening, and locking channels.

## Commands

### Member Management
*   `/voice kick <member>`: Disconnects a user from VC.
*   `/voice kickall`: Disconnects **everyone** from the author's VC.
*   `/voice mute <member>` / `/voice unmute <member>`: Server-mutes/unmutes a user.
*   `/voice muteall` / `/voice unmuteall`: Server-mutes/unmutes **everyone** in the author's VC.
*   `/voice deafen <member>` / `/voice undeafen <member>`: Server-deafens/undeafens a user.
*   `/voice deafenall` / `/voice undeafenall`: Server-deafens/undeafens **everyone** in the author's VC.

### Movement
*   `/voice move <member> <channel>`: Moves a specific user to another channel.
*   `/voice moveall <channel>`: Moves **everyone** from the author's current channel to a target channel.
*   `/voice pull <member>`: Moves a user to the author's current channel.
*   `/voice pullall <channel>`: Moves **everyone** from **ALL** voice channels in the server to the target channel. (Mass gathering).

### Channel Management
*   `/voice lock`: Denies the `Connect` permission for `@everyone` in the current channel.
*   `/voice unlock`: Allows `Connect` permission for `@everyone`.
*   `/voice private`: Denies `Connect` and `View Channel` for `@everyone` (Hides the channel).
*   `/voice unprivate`: Restores `Connect` and `View Channel` for `@everyone`.

## Logic & Permissions
*   **Permissions**: Most commands require `Administrator` or specific permissions like `Move Members`, `Mute Members`, or `Manage Roles`.
*   **Safety**: Checks if the user/bot is actually in a VC before attempting actions.
*   **Feedback**: uses Green/Red Embeds with custom emojis (standard Zephyr style).
