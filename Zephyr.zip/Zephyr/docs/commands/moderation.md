# Moderation System Documentation

## Overview
The Moderation system provides standard administrative tools to manage users and channels. It includes warning systems, channel lockdowns, and mass-management tools.

## Database Connection
*   **File**: `db/warn.db`
*   **Key Tables**:
    *   `warns`: Tracks user warning counts (`guild_id`, `user_id`, `warns`).

### Database Schema
```sql
CREATE TABLE IF NOT EXISTS warns (
    guild_id INTEGER,
    user_id INTEGER,
    warns INTEGER,
    PRIMARY KEY (guild_id, user_id)
);
```

## Commands

### `/warn <user> <reason>`
*   **Description**: Issues a formal warning to a user.
*   **Logic**:
    1.  Increments warning count in `warn.db`.
    2.  Attempts to DM the user with the reason.
    3.  Logs the action to the channel.

### `/clearwarns <user>`
*   **Description**: Resets a user's warning count to 0.

### `/nuke`
*   **Description**: Completely wipes and recreates the current channel.
*   **Logic**:
    1.  `channel.clone()` (Copies permissions/topic).
    2.  `channel.delete()` (Removes old channel/messages).
    3.  Sends "Channel Nuked" embed in the new channel.

### `/lockall` / `/unlockall`
*   **Description**: Locks/Unlocks *every* channel in the server.
*   **Logic**:
    *   Iterates through `guild.channels`.
    *   Edits `default_role` permissions (`send_messages=False/True`).
    *   **Performance Note**: heavy operation on large servers; runs in a loop.

### `/hideall` / `/unhideall`
*   **Description**: Hides/Unhides *every* channel.
*   **Logic**: Similar to lockall, but toggles `view_channel`.

### `/prefix <new_prefix>`
*   **Description**: Changes the bot's command prefix.
*   **Storage**: `db/prefix.db` (managed via `utils/config.py`).
