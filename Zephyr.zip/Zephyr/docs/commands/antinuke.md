# Antinuke System Documentation

## Overview
The Antinuke system is the core security module of Zephyr Bot. It prevents unauthorized mass-actions (nukes) such as banning members, deleting channels, or creating roles by "rogue" admins.

## Database Connection
*   **File**: `db/anti.db`
*   **Performance Note**: Isolated in its own SQLite file to prevent locking with other modules.
*   **Key Tables**:
    *   `antinuke`: Stores the toggle status (`guild_id`, `status`).
    *   `whitelisted_users`: Stores specific permissions for trusted users.
    *   `extraowners`: Stores users treated as "Server Owners" for bypass purposes.

### Database Schema (For Developers)
```sql
CREATE TABLE IF NOT EXISTS antinuke (
    guild_id INTEGER PRIMARY KEY,
    status BOOLEAN
);

CREATE TABLE IF NOT EXISTS whitelisted_users (
    guild_id INTEGER,
    user_id INTEGER,
    ban BOOLEAN DEFAULT FALSE,
    kick BOOLEAN DEFAULT FALSE,
    prune BOOLEAN DEFAULT FALSE,
    botadd BOOLEAN DEFAULT FALSE,
    serverup BOOLEAN DEFAULT FALSE,
    memup BOOLEAN DEFAULT FALSE,
    chcr BOOLEAN DEFAULT FALSE,
    chdl BOOLEAN DEFAULT FALSE,
    chup BOOLEAN DEFAULT FALSE,
    rlcr BOOLEAN DEFAULT FALSE,
    rlup BOOLEAN DEFAULT FALSE,
    rldl BOOLEAN DEFAULT FALSE,
    meneve BOOLEAN DEFAULT FALSE,
    mngweb BOOLEAN DEFAULT FALSE,
    mngstemo BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (guild_id, user_id)
);
```

## Commands

### `/antinuke <enable/disable>`
*   **Description**: Toggles the entire system.
*   **Logic**:
    1.  Checks database for `extraowners` or Guild Owner status.
    2.  Creates/Positions a logical role "Zephyr Supreme™" (high priority).
    3.  Updates `antinuke` table.
*   **Usage**: `/antinuke enable`

### `/whitelist <user>` (Alias: `/wl`)
*   **Description**: Grants immunity to specific antinuke triggers.
*   **Logic**:
    *   Opens an Interactive UI (Select Menu) to choose specific bypasses (e.g., allow "Channel Delete" but block "Ban").
    *   Updates `whitelisted_users` table.

### `/whitelisted`
*   **Description**: Lists all trusted users.
*   **Logic**: Fetches all `user_id`s from `whitelisted_users` for the guild.

### `/whitelistreset`
*   **Description**: Wipes all trusting settings.
*   **Logic**: `DELETE FROM whitelisted_users WHERE guild_id = ?`

## Logic & internals
*   **Event Listeners**: Located in `cogs/antinuke/`, individual files like `antichdl.py` (Channel Delete), `antiban.py` (Ban).
*   **Fail-Fast Optimization**:
    1.  **RAM Cache**: Checks `event_limits` in memory to "debounce" repeated actions.
    2.  **Whitelist Check**: user ID is checked against the internal cache/DB before taking action.
    3.  **Action**: If unauthorized, the bot **immediately** bans the user and attempts to reverse the action (e.g., recreate the channel).
