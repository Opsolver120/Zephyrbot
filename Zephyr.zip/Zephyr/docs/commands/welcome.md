# Welcome / Greeter System Documentation

## Overview
The Welcome system provides customizable greeting messages for new members. It supports both simple text messages and complex Embeds, configured via an interactive setup menu.

## Database Connection
*   **File**: `db/welcome.db`
*   **Key Tables**:
    *   `welcome`: Stores configuration (`guild_id`, `welcome_type`, `welcome_message`, `channel_id`, `embed_data`, `auto_delete_duration`).

### Database Schema
```sql
CREATE TABLE IF NOT EXISTS welcome (
    guild_id INTEGER PRIMARY KEY,
    welcome_type TEXT,        -- 'simple' or 'embed'
    welcome_message TEXT,     -- Plain text content
    channel_id INTEGER,       -- Channel to send message in
    embed_data TEXT,          -- JSON string of embed fields
    auto_delete_duration INTEGER
);
```

## Commands

### `/greet setup`
*   **Description**: Launches the interactive setup wizard.
*   **Flow**:
    1.  Choose **Simple** or **Embed**.
    2.  **Simple**: User types a message. Supports placeholders.
    3.  **Embed**: User uses a Select Menu to edit Title, Description, Color, Image, Thumbnail, etc.
    4.  **Preview**: Bot updates a live preview message as values are changed.

### `/greet channel`
*   **Description**: Selects the target channel.
*   **UI**: Paginated Dropdown menu listing all text channels.

### `/greet test`
*   **Description**: Sends a fake welcome message to test configuration.

### `/greet autodelete <time>`
*   **Description**: Sets a timer to delete welcome messages automatically (e.g., `10s`, `1m`). helps keep chat clean.

## Placeholders
The system supports dynamic variable replacement:
*   `{user}`: Mention user
*   `{user_name}`: Username
*   `{user_avatar}`: Avatar URL
*   `{server_name}`: Guild Name
*   `{server_membercount}`: Total members
*   `{user_createdate}` / `{user_joindate}`: Timestamps

## Internals
*   **Storage**: Embed data is serialized as JSON in the `embed_data` column.
*   **JSON Parsing**: `greet test` and `on_member_join` (implied) deserialize this JSON to reconstruct the Embed object.
