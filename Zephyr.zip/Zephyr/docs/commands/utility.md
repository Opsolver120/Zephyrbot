# Utility System Documentation

## Overview
The Utility system aggregates useful tools for server management, information retrieval, and user convenience. It spans across `cogs/commands/general.py` and `cogs/commands/extra.py`.

## Commands

### Information
*   `/avatar [user]`: Displays user's avatar (PNG/JPG/WEBP/GIF) and button links.
*   `/banner user [user]`: Displays user's banner.
*   `/banner server`: Displays server's banner.
*   `/servericon`: Displays server's icon.
*   `/serverinfo` (Aliases: `sinfo`, `si`): Detailed server statistics (Owner, ID, Creation Date, Boosts, Channels, Roles, Emoji counts).
*   `/userinfo [user]` (Aliases: `whois`, `ui`): Detailed user info (ID, Account Created, Join Date, Roles, Key Permissions, Badges, Acknowledgements).
*   `/roleinfo [role]`: Detailed role info (ID, Color, Position, Permissions, Member count).
*   `/membercount`: stats on Total Members, Humans, Bots, and Online/Idle/DND/Offline status.
*   `/uptime`: Shows how long the bot has been online.
*   `/boostcount`: Shows total server boosts.
*   `/stats` (Aliases: `botinfo`, `bi`): Detailed bot statistics (RAM, CPU, Uptime, Libs, Codebase stats).
*   `/status [user]`: Shows detailed status of a user (Online/Idle, Device, Custom Status, Spotify/Game activity).

### Tools
*   `/translate [message]`: Translates text to English using Google Translate API.
*   `/weather [city]`: Current weather info (Temp, Humidity, Pressure) via OpenWeatherMap.
*   `/iplookup [ip]`: Geo-location and ISP info for an IP address.
*   `/hash [algorithm] [text]`: Hashes text using MD5, SHA1, SHA256, etc.
*   `/poll [message]`: Creates a simple Yes/No poll.
*   `/invite`: Bot invite and support server links.

### AFK System
*   `/afk [reason]`: Sets your status to AFK.
*   **Logic**:
    *   If mentioned while AFK, the bot replies with your AFK reason and time.
    *   When you type a message, AFK is removed.
    *   **Database**: `db/afk.db` stores state, reason, and time.
    *   **DM Notification**: Option to receive DMs when mentioned while AFK.

### Listing Commands
*   `/list boosters`: List of server boosters.
*   `/list roles`: List of all roles with IDs.
*   `/list emojies`: List of all emojis.
*   `/list bots`: List of all bots.
*   `/list admins` / `/list moderators`: List of staff members.
*   `/list invoice`: List users in your current voice channel.
*   `/list inrole [role]`: List members having a specific role.
*   `/list bans`: List banned users.

### Map System
*   `/map [location]`: Displays a map of the specified location.
*   **Features**:
    *   Interactive buttons for panning (Up, Down, Left, Right) and zooming (In, Out).
    *   Map style selection (Map, Satellite, Hybrid, Light, Dark).
    *   Coordinate and Address entry support.
*   **Source**: OpenStreetMap (Nominatim) and MapQuest API.

### Steal System (Emoji/Sticker)
*   `/steal [emoji/sticker]` (Alias: `/eadd`): Adds an emoji or sticker to the server.
    *   Can reply to a message to steal emojis/stickers from it.
    *   **Logic**: Checks for available slots (Normal/Animated) based on server boost level.
    *   **Auto-Sanitization**: Renames emojis to valid characters (alphanumeric + underscore).

### Embed Builder
*   `/embed`: Opens an interactive Embed Editor.
*   **Features**:
    *   Edit Title, Description, Color, Thumbnail, Image, Footer, Author, and Fields.
    *   Real-time preview.
    *   Send the finished embed to a specific channel.
    *   **Permission**: `Manage Messages`.

### Tools (Cont.)
*   `/timer [time] [title]`: Starts a countdown timer.
    *   **Formatting**: Supports `10s`, `1m`, `1h`.
    *   **Logic**: Updates the message every few seconds to show remaining time. Pings the user when finished.
