# Custom Role System Documentation

## Overview
The Custom Role system allows server administrators to create custom commands (e.g., `/myrole`, `/staff`) that assign specific roles to users. It also provides pre-defined slots for common roles like Staff, VIP, and Friend.

## Database Connection
*   `db/customrole.db`: Stores role mappings and custom command definitions.
*   **Tables**:
    *   `roles`: Stores mappings for predefined slots (`staff`, `girl`, `vip`, `guest`, `frnd`, `reqrole`).
    *   `custom_roles`: Stores custom command names and their corresponding role IDs.

## Commands

### Predefined Slots
*   `/setup set <type> <role>`: Assigns a role to a predefined slot.
    *   **Types**: `staff`, `girl`, `vip`, `guest`, `friend`.
*   **Usage**: Once set, anyone with the `Required Role` (or Owner/Admin config dependent) can use:
    *   `/staff <user>`
    *   `/vip <user>`
    *   etc.
    *   These commands **toggle** the role (Add if missing, Remove if present).

### Custom Commands
*   `/setup create <name> <role>`: Creates a NEW command with the specified name.
    *   Example: `/setup create helper @Helper` creates a `/helper` command.
    *   **Limit**: Max 56 custom commands.
*   `/setup delete <name>`: Deletes a custom command.
*   `/setup list`: Lists all custom commands.

### Configuration
*   `/setup reqrole <role>`: Sets a "Required Role". Users MUST have this role to use any of the custom role commands (unless they are Owner/Admin).
*   `/setup config`: Shows specific mapping of predefined slots.
*   `/setup reset`: Wipes all configuration.

## Logic
*   **Permissions**: The bot checks update permissions carefully. Users creating/using these commands must usually have a role higher than the role they are assigning.
*   **Cooldowns**: 3-5 seconds user cooldown.
