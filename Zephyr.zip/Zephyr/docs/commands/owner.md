# Owner & Badge System Documentation

## Overview
This system contains commands restricted to the **Bot Owner** (IDs defined in `config.py`) and **Bot Staff**. It handles staff management, global bot administration, and a custom Profile/Badge system.

## Database Connection
*   `db/badges.db`: Stores user badges.
*   `db/np.db`: Stores Bot Staff IDs (`staff` table).

## Global Administration (Owner Only)
*   `/zephyr.restart`: Restarts the bot process.
*   `/sync`: Syncs database/config files (manual refresh).
*   `/servers`: Lists all guilds the bot is in.
*   `/getinvite [guild_id]`: Generates an invite for a specific guild.
*   `/leaveguild [guild_id]`: Forces the bot to leave a guild.
*   `/globalunban [user]`: Unbans a user from **ALL** servers the bot is in.
*   `/dm [user] [message]`: Sends a DM from the bot.
*   `/change nickname [name]`: Changes bot's nickname in current guild.

### Force Moderation
*   `/ownerban [user]`: Bans a user from the current guild (bypassing some checks).
*   `/guildban [guild_id] [user]`: Bans a user from a *remote* guild.
*   `/forcepurgebots` / `/forcepurgeuser`: Mass deletes messages from bots or specific users in a channel.

### Staff Management
*   `/staff add/remove [user]`: Adds/Removes a user from the Bot Staff list.
*   `/staff list`: Views staff members.
*   **Privileges**: Staff members can use certain restricted commands (like viewing guild lists).

### Extra Owner
Calculated permission level for trusted server admins to bypass Anti-Nuke restrictions.
*   **Command**: `/extraowner <set/reset/view> [user]`
*   **Permission**: Server Owner only.
*   **Purpose**: Designates a user as an "Extra Owner" who can manage Anti-Nuke settings and whitelist.

## Badge System
A custom profile system for users.
*   **Badges**: `Owner`, `Staff`, `Partner`, `Sponsor`, `Friend`, `Early Supporter`, `VIP`, `Bug Hunter`.
*   **Commands**:
    *   `/badges [user]` (Alias: `/profile`): Viewing a profile. Displays badges, account age, etc.
    *   `/bdg add [user] [badge]`: Owner-only command to award badges.
    *   `/bdg remove [user] [badge]`: Owner-only command to revoke badges.

## Server Tour (Troll/Fun?)
*   `/servertour [time] [user]`: Rapidly moves a user through all voice channels in the server for a set time. Owner only.

## Global Management
Extensive control over users across all servers the bot is in.
*   **File**: `cogs/commands/owner2.py`
*   **Commands**:
    *   `/global ban <user> [reason]`: Bans a user from **all** mutual guilds.
    *   `/global kick <user> [reason]`: Kicks a user from **all** mutual guilds.
    *   `/global timeout <user> [reason]`: Timeouts a user for 28 days in **all** mutual guilds.
    *   `/global nick <user> <name>`: Sets nickname in **all** mutual guilds.
    *   `/global clearnick <user>`: Clears nickname in **all** mutual guilds.
    *   `/global freezenick <user> <name>`: **Locks** a user's nickname in **all** mutual guilds. If they change it, it changes back.
    *   `/global unfreezenick <user>`: Stops the freeze.

## Blacklist (Global)
Blocks users or guilds from using the bot entirely.
*   **File**: `cogs/commands/block.py`
*   **Database**: `db/block.db`
*   **Commands**:
    *   `/blacklist user add/remove <user>`: Blocks/Unblocks a user.
    *   `/blacklist guild add/remove <guild_id>`: Blocks/Unblocks a guild.
    *   `/blacklist user show`: Lists blacklisted users.

## No Prefix System (NP)
Allows specific users to use commands without a prefix.
*   **File**: `cogs/commands/np.py`
*   **Database**: `db/np.db`
*   **Commands**:
    *   `/np add <user>`: Interactive UI to select duration (10m, 1w... Lifetime).
    *   `/np remove <user>`: Revokes access.
    *   `/np list`: Lists all NP users.
    *   `/autonp guild add/remove`: Automatically gives NP for 2 months to users who boost the partner server.

## Nightmode
Security feature to temporarily strip dangerous permissions from roles.
*   **File**: `cogs/commands/nightmode.py`
*   **Database**: `db/anti.db`
*   **Commands**:
    *   `/nightmode enable`: Removes `Administrator` permission from all roles lower than the bot.
    *   `/nightmode disable`: Restores the permissions.
*   **Purpose**: Used during raids or when staff are offline to prevent unauthorized admin actions.

