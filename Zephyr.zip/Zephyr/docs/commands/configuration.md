# Configuration System Documentation

## Overview
This section covers server-specific configuration modules that allow admins to tailor the bot's behavior.

## Autorole
System to automatically assign roles to new members/bots upon join.
*   **File**: `cogs/commands/autorole.py`
*   **Database**: `db/autorole.db`
*   **Commands**:
    *   `/autorole config`: View current settings.
    *   `/autorole humans add <role>`: Adds a role to be given to humans. (Max 10)
    *   `/autorole humans remove <role>`: Removes a role.
    *   `/autorole bots add/remove`: Same as above, but for bots.
    *   `/autorole reset`: Clears configuration.
*   **Optimizations**: Uses `aiosqlite` and stores data as a stringified list of IDs.

## AutoResponder
Create custom triggers that make the bot reply with a set message.
*   **File**: `cogs/commands/autoresponder.py`
*   **Database**: `db/autoresponder.db`
*   **Commands**:
    *   `/autoresponder create <trigger> <response>`: Creates a new trigger.
    *   `/autoresponder delete <trigger>`: Deletes a trigger.
    *   `/autoresponder edit <trigger> <new_response>`: Updates a response.
    *   `/autoresponder config`: Lists all active triggers.
*   **Constraints**: Max 20 autoresponses per guild. Matches are exact and case-insensitive.

## Ignore System
Restrict the bot from responding in specific channels or to specific users.
*   **File**: `cogs/commands/ignore.py`
*   **Database**: `db/ignore.db`
*   **Commands**:
    *   `/ignore channel add/remove [channel]`: Bot ignores commands in this channel.
    *   `/ignore user add/remove [user]`: Bot ignores commands from this user.
    *   `/ignore bypass add/remove [user]`: User bypasses ignore checks.
*   **Logic**: The `ignore_check()` decorator in `utils/Tools.py` checks this database before every command execution.

## Prefix System
Customizable command prefix per server.
*   **File**: `cogs/commands/moderation.py` (Command location) / `utils/Tools.py` (Logic).
*   **Database**: `db/prefix.db`
*   **Command**: `/prefix [new_prefix]`
*   **Default**: `$` (if not set).

## Welcome / Greeter
*   *See [welcome.md](welcome.md) for full details.*

## Auto Reaction System
Automatically reacts to specific words with set emojis.
*   **File**: `cogs/commands/autoreact.py`
*   **Database**: `db/autoreact.db`
*   **Commands**:
    *   `/react add <trigger> <emojis>`: Adds a reaction trigger.
    *   `/react remove <trigger>`: Removes a trigger.
    *   `/react list`: Lists all triggers.
    *   `/react reset`: Removes all triggers.

## Notification System (Stream Alerts)
Notifies a channel when a user with a specific role starts streaming on Twitch or YouTube.
*   **File**: `cogs/commands/notify.py`
*   **Database**: `db/notify.db`
*   **Commands**:
    *   `/setnotif twitch <role> <channel>`: Sets up Twitch alerts.
    *   `/setnotif youtube <role> <channel>`: Sets up YouTube alerts.
    *   `/setnotif list`: Lists valid configurations.
    *   `/setnotif reset`: Clears all configurations.
*   **Logic**: Monitors `on_presence_update` for `Streaming` activities matching the role.

## Voice Channel Roles (VC Role)
Automatically assigns a role to users when they join a voice channel.
*   **File**: `cogs/commands/Invc.py`
*   **Database**: `db/invc.db`
*   **Commands**:
    *   `/vcrole add <role>`: Sets the role to be given.
    *   `/vcrole remove <role>`: Removes the configuration.
    *   `/vcrole config`: Shows current setting.
*   **Logic**:
    *   **Join VC**: Adds role.
    *   **Leave VC**: Removes role.
    *   **Retry Logic**: Retries up to 5 times if rate-limited.
