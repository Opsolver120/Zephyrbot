# Media Channels Documentation

## Overview
The Media system (`cogs/commands/Media.py`) allows administrators to designate specific channels as "Media Only". In these channels, normal text messages are automatically deleted, and only messages containing attachments (images, videos, files) are allowed.

## Database Connection
*   **File**: `db/media.db`
*   **Tables**:
    *   `media_channels`: Stores the configured channel for each guild (`guild_id`, `channel_id`).
    *   `media_bypass`: Stores users who are exempt from the media-only restriction (`guild_id`, `user_id`).

## Commands

### `/media setup <channel>`
*   **Description**: Sets a specific text channel as the media-only channel.
*   **Permission**: Administrator.
*   **Usage**: `/media setup #channel-name`

### `/media remove` (Alias: `reset`, `delete`)
*   **Description**: Disables the media-only restriction for the server.
*   **Permission**: Administrator.
*   **Usage**: `/media remove`

### `/media config` (Alias: `settings`, `show`)
*   **Description**: Shows the currently configured media-only channel.
*   **Permission**: Administrator.
*   **Usage**: `/media config`

### `/media bypass add <user>`
*   **Description**: Allows a specific user to send text messages in the media channel.
*   **Permission**: Administrator.
*   **Limit**: Max 25 bypassed users per guild.
*   **Usage**: `/media bypass add @User`

### `/media bypass remove <user>`
*   **Description**: Removes a user from the bypass list.
*   **Permission**: Administrator.
*   **Usage**: `/media bypass remove @User`

### `/media bypass show`
*   **Description**: Lists all users currently in the bypass list.
*   **Permission**: Administrator.
*   **Usage**: `/media bypass show`

## Logic & Moderation
1.  **Message Filtering**: The `on_message` listener checks if a message is in a configured media channel.
2.  **Validation**:
    *   If the message contains an attachment, it is ignored (allowed).
    *   If the user is a Bot, Blacklisted (Global User Blacklist), or in the `media_bypass` list, it is ignored (allowed).
3.  **Enforcement**:
    *   If a text-only message is sent, it is **deleted**.
    *   The bot sends a temporary warning message (5 seconds).
4.  **Auto-Blacklist (Spam Protection)**:
    *   The bot tracks infractions in memory.
    *   If a user commits **5 violations within 5 seconds**, they are automatically added to the **Global User Blacklist** (`db/block.db`).
    *   This effectively bans them from using the bot entirely.
