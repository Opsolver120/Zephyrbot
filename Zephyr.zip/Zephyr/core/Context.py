"""
GemContext — Custom commands.Context with convenience helpers.
Every command gets `ctx.success(...)`, `ctx.error(...)`, `ctx.embed(...)`.
"""

from __future__ import annotations

import discord
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS


class GemContext(commands.Context):
    """Extended context with emoji-rich helper methods."""

    async def success(self, message: str, **kwargs) -> discord.Message:
        """Send a green success embed."""
        em = discord.Embed(
            description=f"{EMOJIS['success']} {message}",
            color=COLORS["success"],
        )
        return await self.send(embed=em, **kwargs)

    async def error(self, message: str, **kwargs) -> discord.Message:
        """Send a red error embed."""
        em = discord.Embed(
            description=f"{EMOJIS['error']} {message}",
            color=COLORS["error"],
        )
        return await self.send(embed=em, **kwargs)

    async def warning(self, message: str, **kwargs) -> discord.Message:
        """Send a yellow warning embed."""
        em = discord.Embed(
            description=f"{EMOJIS['warning']} {message}",
            color=COLORS["warning"],
        )
        return await self.send(embed=em, **kwargs)

    async def embed(
        self,
        title: str | None = None,
        description: str | None = None,
        color: int | None = None,
        **kwargs,
    ) -> discord.Message:
        """Send a standard embed with the Zephyr branding."""
        em = discord.Embed(
            title=title,
            description=description,
            color=color or COLORS["primary"],
        )
        em.set_footer(
            text=f"Zephyr",
            icon_url=self.bot.user.display_avatar.url if self.bot.user else None,
        )
        return await self.send(embed=em, **kwargs)

    async def denied(self, message: str | None = None, **kwargs) -> discord.Message:
        """Send a permission-denied embed."""
        msg = message or "You do not have permission to use this command."
        em = discord.Embed(
            description=f"{EMOJIS['denied']} {msg}",
            color=COLORS["error"],
        )
        return await self.send(embed=em, **kwargs)

    async def loading(self, message: str = "Processing…", **kwargs) -> discord.Message:
        """Send a loading/processing embed."""
        em = discord.Embed(
            description=f"{EMOJIS['loading']} {message}",
            color=COLORS["warning"],
        )
        return await self.send(embed=em, **kwargs)
