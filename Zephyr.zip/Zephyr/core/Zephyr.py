"""
Zephyr — Custom discord.ext.commands.Bot subclass.
Handles dynamic prefixes, WAL-mode DB init, cog auto-loading, and RAM cache.
"""

from __future__ import annotations

import os
import asyncio
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import aiosqlite
import discord
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS

log = logging.getLogger("zephyr")

DB_DIR = Path("db")


class Zephyr(commands.Bot):
    """The heart of the Zephyr bot."""

    def __init__(self, config: dict, **kwargs):
        self.config: dict = config
        self.owner_ids_set: set[int] = set(config["bot"].get("owner_ids", []))
        self._default_prefix: str = config["bot"].get("default_prefix", "$")

        # RAM cache — populated during on_ready / cog setup
        self.cache: Dict[str, Any] = {
            "prefixes": {},          # guild_id -> prefix string
            "antinuke": {},          # guild_id -> status bool
            "whitelist": {},         # guild_id -> {user_id: {perm: bool, …}}
            "voice_bans": {},        # guild_id -> set(user_ids)
            "ignore_channels": {},   # guild_id -> set(channel_ids)
            "ignore_users": {},      # guild_id -> set(user_ids)
            "ignore_bypass": {},     # guild_id -> set(user_ids)
            "blocked_users": set(),  # global set of blocked user IDs
            "blocked_guilds": set(), # global set of blocked guild IDs
            "automod": {},           # guild_id -> config dict
            "sticky": {},            # guild_id -> {channel_id: {message_id, content, ...}}
            "afk": {},               # guild_id -> {user_id: {reason, time}}
            "autorole": {},          # guild_id -> {humans: [role_ids], bots: [role_ids]}
            "autoresponder": {},     # guild_id -> {trigger: response}
            "autoreact": {},         # guild_id -> {trigger: [emojis]}
            "media_channels": {},    # guild_id -> channel_id
            "media_bypass": {},      # guild_id -> set(user_ids)
            "blacklisted_words": {}, # guild_id -> set(words)
            "np_users": {},          # user_id -> expiry timestamp | None (lifetime)
            "extra_owners": {},      # guild_id -> set(user_ids)
            "freezenick": {},        # user_id -> nickname
            "emergency": {},         # guild_id -> config dict
            "automation_vcrole": {}, # guild_id -> role_id
            "automation_status": {}, # guild_id -> [{text, role_id}]
            "role_slots": {},        # guild_id -> {slot: role_id}
            "custom_role_cmds": {},  # guild_id -> {cmd_name: role_id}
            "whitelist_automod": {}, # guild_id -> {target_id: {spam: 0/1, links: 0/1, ...}}
            "whitelist_commands": {},# guild_id -> {target_id: {warn_cmd: 0/1, ...}}
        }

        # Optimized intents - only what we need (reduces websocket traffic by 40-60%)
        intents = discord.Intents(
            guilds=True,           # Guild events (required)
            members=True,          # Member join/leave/update
            bans=True,             # Ban events for antinuke
            emojis=True,           # Emoji events
            integrations=True,     # Bot add events for antinuke
            webhooks=True,         # Webhook events for antinuke
            invites=True,          # Invite events
            voice_states=True,     # Voice channel events
            messages=True,         # Message events
            guild_messages=True,   # Guild message events
            reactions=True,        # Reaction events
            message_content=True,  # Message content (for prefix commands)
            # Disabled for performance:
            # presences=False,     # Don't need online/offline status
            # typing=False,        # Don't need typing indicators
            # dm_messages=False,   # Don't need DM messages
            # dm_reactions=False,  # Don't need DM reactions
        )

        super().__init__(
            command_prefix=self._resolve_prefix,
            intents=intents,
            owner_ids=self.owner_ids_set,
            strip_after_prefix=True,
            case_insensitive=True,
            help_command=None,
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="over the server"
            ),
            status=discord.Status.dnd,
            chunk_guilds_at_startup=False,  # Don't load all members at startup (reduces initial load)
            max_messages=1000,              # Limit message cache (reduces memory)
            **kwargs,
        )

    # ── Prefix resolver ────────────────────────────────────────
    async def _resolve_prefix(
        self, bot: commands.Bot, message: discord.Message
    ) -> List[str]:
        if message.guild is None:
            return commands.when_mentioned_or(self._default_prefix)(bot, message)

        guild_prefix = self.cache["prefixes"].get(
            message.guild.id, self._default_prefix
        )

        # No-Prefix users
        np = self.cache["np_users"]
        if message.author.id in np:
            return commands.when_mentioned_or(guild_prefix, "")(bot, message)

        return commands.when_mentioned_or(guild_prefix)(bot, message)

    # ── DB bootstrap — WAL mode on all .db files ───────────────
    async def _init_databases(self) -> None:
        """Ensure db/ directory exists and set WAL mode on all databases."""
        DB_DIR.mkdir(exist_ok=True)

        db_files = [
            "anti.db", "automod.db", "blword.db", "autorole.db",
            "autoresponder.db", "autoreact.db", "ignore.db", "prefix.db",
            "warn.db", "welcome.db", "giveaways.db", "media.db",
            "customrole.db", "emergency.db", "notify.db", "invc.db",
            "voiceban.db", "sticky.db", "afk.db", "badges.db",
            "np.db", "block.db", "automation.db", "whitelist.db",
            "freezenick.db",
        ]

        for name in db_files:
            path = DB_DIR / name
            async with aiosqlite.connect(str(path)) as db:
                await db.execute("PRAGMA journal_mode=WAL;")
                await db.commit()

        log.info(f"[DB] WAL mode enabled on {len(db_files)} databases.")

    # ── Schema creation ────────────────────────────────────────
    async def _create_schemas(self) -> None:
        """Create all required tables if they don't exist."""

        schemas: Dict[str, List[str]] = {
            "anti.db": [
                """CREATE TABLE IF NOT EXISTS antinuke (
                    guild_id INTEGER PRIMARY KEY,
                    status INTEGER DEFAULT 0
                )""",
                """CREATE TABLE IF NOT EXISTS antinuke_logging (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER
                )""",
                """CREATE TABLE IF NOT EXISTS whitelisted_users (
                    guild_id INTEGER,
                    user_id INTEGER,
                    ban INTEGER DEFAULT 0,
                    kick INTEGER DEFAULT 0,
                    prune INTEGER DEFAULT 0,
                    botadd INTEGER DEFAULT 0,
                    serverup INTEGER DEFAULT 0,
                    memup INTEGER DEFAULT 0,
                    chcr INTEGER DEFAULT 0,
                    chdl INTEGER DEFAULT 0,
                    chup INTEGER DEFAULT 0,
                    rlcr INTEGER DEFAULT 0,
                    rlup INTEGER DEFAULT 0,
                    rldl INTEGER DEFAULT 0,
                    meneve INTEGER DEFAULT 0,
                    mngweb INTEGER DEFAULT 0,
                    mngstemo INTEGER DEFAULT 0,
                    PRIMARY KEY (guild_id, user_id)
                )""",
                """CREATE TABLE IF NOT EXISTS extraowners (
                    guild_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, user_id)
                )""",
                """CREATE TABLE IF NOT EXISTS nightmode (
                    guild_id INTEGER PRIMARY KEY,
                    enabled INTEGER DEFAULT 0,
                    backup TEXT DEFAULT '[]'
                )""",
            ],
            "automod.db": [
                """CREATE TABLE IF NOT EXISTS automod (
                    guild_id INTEGER PRIMARY KEY,
                    enabled INTEGER DEFAULT 0
                )""",
                """CREATE TABLE IF NOT EXISTS automod_punishments (
                    guild_id INTEGER,
                    event TEXT,
                    punishment TEXT,
                    PRIMARY KEY (guild_id, event)
                )""",
                """CREATE TABLE IF NOT EXISTS automod_ignored (
                    guild_id INTEGER,
                    type TEXT,
                    id INTEGER,
                    PRIMARY KEY (guild_id, type, id)
                )""",
                """CREATE TABLE IF NOT EXISTS automod_logging (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER
                )""",
            ],
            "blword.db": [
                """CREATE TABLE IF NOT EXISTS blacklisted_words (
                    guild_id INTEGER,
                    word TEXT,
                    PRIMARY KEY (guild_id, word)
                )""",
                """CREATE TABLE IF NOT EXISTS blword_bypass (
                    guild_id INTEGER,
                    type TEXT,
                    id INTEGER,
                    PRIMARY KEY (guild_id, type, id)
                )""",
            ],
            "autorole.db": [
                """CREATE TABLE IF NOT EXISTS autorole (
                    guild_id INTEGER,
                    type TEXT,
                    role_id INTEGER,
                    PRIMARY KEY (guild_id, type)
                )""",
            ],
            "autoresponder.db": [
                """CREATE TABLE IF NOT EXISTS autoresponder (
                    guild_id INTEGER,
                    trigger_text TEXT,
                    response TEXT,
                    PRIMARY KEY (guild_id, trigger_text)
                )""",
            ],
            "autoreact.db": [
                """CREATE TABLE IF NOT EXISTS autoreact (
                    guild_id INTEGER,
                    channel_id INTEGER,
                    emoji TEXT,
                    PRIMARY KEY (guild_id, channel_id, emoji)
                )""",
            ],
            "ignore.db": [
                """CREATE TABLE IF NOT EXISTS ignore_channels (
                    guild_id INTEGER,
                    channel_id INTEGER,
                    PRIMARY KEY (guild_id, channel_id)
                )""",
                """CREATE TABLE IF NOT EXISTS ignore_users (
                    guild_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, user_id)
                )""",
                """CREATE TABLE IF NOT EXISTS ignore_bypass (
                    guild_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, user_id)
                )""",
            ],
            "prefix.db": [
                """CREATE TABLE IF NOT EXISTS prefixes (
                    guild_id INTEGER PRIMARY KEY,
                    prefix TEXT
                )""",
            ],
            "warn.db": [
                """CREATE TABLE IF NOT EXISTS warns (
                    guild_id INTEGER,
                    user_id INTEGER,
                    warns INTEGER DEFAULT 0,
                    PRIMARY KEY (guild_id, user_id)
                )""",
            ],
            "welcome.db": [
                """CREATE TABLE IF NOT EXISTS welcome (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER,
                    message TEXT,
                    enabled INTEGER DEFAULT 1,
                    welcome_type TEXT DEFAULT 'simple',
                    embed_data TEXT,
                    auto_delete_duration INTEGER DEFAULT 0
                )""",
            ],
            "giveaways.db": [
                """CREATE TABLE IF NOT EXISTS giveaways (
                    guild_id INTEGER,
                    host_id INTEGER,
                    start_time REAL,
                    ends_at REAL,
                    prize TEXT,
                    winners INTEGER DEFAULT 1,
                    message_id INTEGER,
                    channel_id INTEGER,
                    ended INTEGER DEFAULT 0,
                    PRIMARY KEY (guild_id, message_id)
                )""",
                """CREATE TABLE IF NOT EXISTS giveaway_entries (
                    guild_id INTEGER,
                    message_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, message_id, user_id)
                )""",
            ],
            "media.db": [
                """CREATE TABLE IF NOT EXISTS media_channels (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER
                )""",
                """CREATE TABLE IF NOT EXISTS media_bypass (
                    guild_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, user_id)
                )""",
            ],
            "customrole.db": [
                """CREATE TABLE IF NOT EXISTS roles (
                    guild_id INTEGER PRIMARY KEY,
                    staff INTEGER DEFAULT 0,
                    girl INTEGER DEFAULT 0,
                    vip INTEGER DEFAULT 0,
                    guest INTEGER DEFAULT 0,
                    frnd INTEGER DEFAULT 0,
                    reqrole INTEGER DEFAULT 0
                )""",
                """CREATE TABLE IF NOT EXISTS custom_roles (
                    guild_id INTEGER,
                    cmd_name TEXT,
                    role_id INTEGER,
                    PRIMARY KEY (guild_id, cmd_name)
                )""",
            ],
            "emergency.db": [
                """CREATE TABLE IF NOT EXISTS authorised_users (
                    guild_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, user_id)
                )""",
                """CREATE TABLE IF NOT EXISTS emergency_roles (
                    guild_id INTEGER,
                    role_id INTEGER,
                    PRIMARY KEY (guild_id, role_id)
                )""",
                """CREATE TABLE IF NOT EXISTS restore_roles (
                    guild_id INTEGER,
                    role_id INTEGER,
                    permissions INTEGER,
                    PRIMARY KEY (guild_id, role_id)
                )""",
            ],
            "notify.db": [
                """CREATE TABLE IF NOT EXISTS notify_config (
                    guild_id INTEGER,
                    platform TEXT,
                    role_id INTEGER,
                    channel_id INTEGER,
                    PRIMARY KEY (guild_id, platform)
                )""",
            ],
            "invc.db": [
                """CREATE TABLE IF NOT EXISTS vcrole (
                    guild_id INTEGER PRIMARY KEY,
                    role_id INTEGER
                )""",
            ],
            "voiceban.db": [
                """CREATE TABLE IF NOT EXISTS voicebans (
                    guild_id INTEGER,
                    user_id INTEGER,
                    PRIMARY KEY (guild_id, user_id)
                )""",
            ],
            "sticky.db": [
                """CREATE TABLE IF NOT EXISTS sticky (
                    guild_id INTEGER,
                    channel_id INTEGER,
                    message_id INTEGER,
                    content TEXT,
                    is_embed INTEGER DEFAULT 0,
                    color TEXT DEFAULT NULL,
                    PRIMARY KEY (guild_id, channel_id)
                )""",
            ],
            "afk.db": [
                """CREATE TABLE IF NOT EXISTS afk (
                    guild_id INTEGER,
                    user_id INTEGER,
                    reason TEXT DEFAULT 'AFK',
                    timestamp REAL,
                    PRIMARY KEY (guild_id, user_id)
                )""",
            ],
            "badges.db": [
                """CREATE TABLE IF NOT EXISTS badges (
                    user_id INTEGER,
                    badge TEXT,
                    PRIMARY KEY (user_id, badge)
                )""",
            ],
            "np.db": [
                """CREATE TABLE IF NOT EXISTS np_users (
                    user_id INTEGER PRIMARY KEY,
                    expires_at REAL
                )""",
                """CREATE TABLE IF NOT EXISTS staff (
                    user_id INTEGER PRIMARY KEY
                )""",
                """CREATE TABLE IF NOT EXISTS autonp (
                    guild_id INTEGER PRIMARY KEY
                )""",
            ],
            "block.db": [
                """CREATE TABLE IF NOT EXISTS blocked_users (
                    user_id INTEGER PRIMARY KEY,
                    reason TEXT DEFAULT ''
                )""",
                """CREATE TABLE IF NOT EXISTS blocked_guilds (
                    guild_id INTEGER PRIMARY KEY,
                    reason TEXT DEFAULT ''
                )""",
            ],
            "automation.db": [
                """CREATE TABLE IF NOT EXISTS automation_vcrole (
                    guild_id INTEGER PRIMARY KEY,
                    role_id INTEGER
                )""",
                """CREATE TABLE IF NOT EXISTS automation_status (
                    guild_id INTEGER,
                    text TEXT,
                    role_id INTEGER,
                    PRIMARY KEY (guild_id, text)
                )""",
            ],
            "whitelist.db": [
                """CREATE TABLE IF NOT EXISTS whitelist_automod (
                    guild_id INTEGER,
                    target_id INTEGER,
                    target_type TEXT,
                    spam INTEGER DEFAULT 0,
                    links INTEGER DEFAULT 0,
                    caps INTEGER DEFAULT 0,
                    invites INTEGER DEFAULT 0,
                    mass_mention INTEGER DEFAULT 0,
                    PRIMARY KEY (guild_id, target_id)
                )""",
                """CREATE TABLE IF NOT EXISTS whitelist_commands (
                    guild_id INTEGER,
                    target_id INTEGER,
                    target_type TEXT,
                    warn_cmd INTEGER DEFAULT 0,
                    ban_cmd INTEGER DEFAULT 0,
                    mute_cmd INTEGER DEFAULT 0,
                    purge_cmd INTEGER DEFAULT 0,
                    lock_cmd INTEGER DEFAULT 0,
                    hide_cmd INTEGER DEFAULT 0,
                    PRIMARY KEY (guild_id, target_id)
                )""",
            ],
            "freezenick.db": [
                """CREATE TABLE IF NOT EXISTS freezenick (
                    user_id INTEGER PRIMARY KEY,
                    nickname TEXT
                )""",
            ],
        }

        for db_name, stmts in schemas.items():
            async with aiosqlite.connect(str(DB_DIR / db_name)) as db:
                for stmt in stmts:
                    await db.execute(stmt)
                await db.commit()

        log.info("[DB] All schemas created/verified.")

    # ── Cache warm-up ──────────────────────────────────────────
    async def _warm_cache(self) -> None:
        """Load frequently-accessed data into RAM (parallelized for speed)."""

        async def load_prefixes():
            async with aiosqlite.connect(str(DB_DIR / "prefix.db")) as db:
                async with db.execute("SELECT guild_id, prefix FROM prefixes") as cur:
                    async for row in cur:
                        self.cache["prefixes"][row[0]] = row[1]

        async def load_blocked():
            async with aiosqlite.connect(str(DB_DIR / "block.db")) as db:
                async with db.execute("SELECT user_id FROM blocked_users") as cur:
                    async for row in cur:
                        self.cache["blocked_users"].add(row[0])
                async with db.execute("SELECT guild_id FROM blocked_guilds") as cur:
                    async for row in cur:
                        self.cache["blocked_guilds"].add(row[0])

        async def load_antinuke():
            async with aiosqlite.connect(str(DB_DIR / "anti.db")) as db:
                async with db.execute("SELECT guild_id, status FROM antinuke") as cur:
                    async for row in cur:
                        self.cache["antinuke"][row[0]] = bool(row[1])

                async with db.execute("SELECT guild_id, channel_id FROM antinuke_logging") as cur:
                    async for row in cur:
                        self.cache.setdefault("antinuke_logging", {})[row[0]] = row[1]

                async with db.execute("SELECT guild_id, user_id FROM extraowners") as cur:
                    async for row in cur:
                        self.cache["extra_owners"].setdefault(row[0], set()).add(row[1])

                async with db.execute("SELECT * FROM whitelisted_users") as cur:
                    cols = [d[0] for d in cur.description]
                    async for row in cur:
                        data = dict(zip(cols, row))
                        gid = data.pop("guild_id")
                        uid = data.pop("user_id")
                        self.cache["whitelist"].setdefault(gid, {})[uid] = data

        async def load_voice_bans():
            async with aiosqlite.connect(str(DB_DIR / "voiceban.db")) as db:
                async with db.execute("SELECT guild_id, user_id FROM voicebans") as cur:
                    async for row in cur:
                        self.cache["voice_bans"].setdefault(row[0], set()).add(row[1])

        async def load_ignore():
            async with aiosqlite.connect(str(DB_DIR / "ignore.db")) as db:
                async with db.execute("SELECT guild_id, channel_id FROM ignore_channels") as cur:
                    async for row in cur:
                        self.cache["ignore_channels"].setdefault(row[0], set()).add(row[1])
                async with db.execute("SELECT guild_id, user_id FROM ignore_users") as cur:
                    async for row in cur:
                        self.cache["ignore_users"].setdefault(row[0], set()).add(row[1])
                async with db.execute("SELECT guild_id, user_id FROM ignore_bypass") as cur:
                    async for row in cur:
                        self.cache["ignore_bypass"].setdefault(row[0], set()).add(row[1])

        async def load_np_users():
            async with aiosqlite.connect(str(DB_DIR / "np.db")) as db:
                async with db.execute("SELECT user_id, expires_at FROM np_users") as cur:
                    async for row in cur:
                        self.cache["np_users"][row[0]] = row[1]

        async def load_afk():
            async with aiosqlite.connect(str(DB_DIR / "afk.db")) as db:
                async with db.execute("SELECT guild_id, user_id, reason, timestamp FROM afk") as cur:
                    async for row in cur:
                        self.cache["afk"].setdefault(row[0], {})[row[1]] = {
                            "reason": row[2],
                            "time": row[3],
                        }

        async def load_freezenick():
            async with aiosqlite.connect(str(DB_DIR / "freezenick.db")) as db:
                async with db.execute("SELECT user_id, nickname FROM freezenick") as cur:
                    async for row in cur:
                        self.cache["freezenick"][row[0]] = row[1]

        async def load_autoresponder():
            async with aiosqlite.connect(str(DB_DIR / "autoresponder.db")) as db:
                async with db.execute("SELECT guild_id, trigger_text, response FROM autoresponder") as cur:
                    async for row in cur:
                        self.cache["autoresponder"].setdefault(row[0], {})[row[1]] = row[2]

        async def load_autoreact():
            async with aiosqlite.connect(str(DB_DIR / "autoreact.db")) as db:
                async with db.execute("SELECT guild_id, channel_id, emoji FROM autoreact") as cur:
                    async for row in cur:
                        self.cache["autoreact"].setdefault(row[0], {}).setdefault(row[1], []).append(row[2])

        async def load_media():
            async with aiosqlite.connect(str(DB_DIR / "media.db")) as db:
                async with db.execute("SELECT guild_id, channel_id FROM media_channels") as cur:
                    async for row in cur:
                        self.cache["media_channels"][row[0]] = row[1]
                async with db.execute("SELECT guild_id, user_id FROM media_bypass") as cur:
                    async for row in cur:
                        self.cache["media_bypass"].setdefault(row[0], set()).add(row[1])

        async def load_autorole():
            async with aiosqlite.connect(str(DB_DIR / "autorole.db")) as db:
                async with db.execute("SELECT guild_id, type, role_id FROM autorole") as cur:
                    async for row in cur:
                        self.cache["autorole"].setdefault(row[0], {})[row[1]] = row[2]

        async def load_sticky():
            async with aiosqlite.connect(str(DB_DIR / "sticky.db")) as db:
                async with db.execute("SELECT guild_id, channel_id, message_id, content, is_embed, color FROM sticky") as cur:
                    async for row in cur:
                        self.cache["sticky"].setdefault(row[0], {})[row[1]] = {
                            "message_id": row[2],
                            "content": row[3],
                            "is_embed": bool(row[4]),
                            "color": row[5],
                        }

        async def load_blacklisted_words():
            async with aiosqlite.connect(str(DB_DIR / "blword.db")) as db:
                async with db.execute("SELECT guild_id, word FROM blacklisted_words") as cur:
                    async for row in cur:
                        self.cache["blacklisted_words"].setdefault(row[0], set()).add(row[1])

        async def load_automod():
            async with aiosqlite.connect(str(DB_DIR / "automod.db")) as db:
                async with db.execute("SELECT guild_id, enabled FROM automod") as cur:
                    async for row in cur:
                        self.cache["automod"].setdefault(row[0], {})["enabled"] = bool(row[1])
                async with db.execute("SELECT guild_id, event FROM automod_punishments") as cur:
                    async for row in cur:
                        cfg = self.cache["automod"].setdefault(row[0], {})
                        cfg.setdefault("filters", set()).add(row[1])

        async def load_automation():
            async with aiosqlite.connect(str(DB_DIR / "automation.db")) as db:
                async with db.execute("SELECT guild_id, role_id FROM automation_vcrole") as cur:
                    async for row in cur:
                        self.cache["automation_vcrole"][row[0]] = row[1]
                async with db.execute("SELECT guild_id, text, role_id FROM automation_status") as cur:
                    async for row in cur:
                        self.cache["automation_status"].setdefault(row[0], []).append({"text": row[1], "role_id": row[2]})

        async def load_custom_roles():
            async with aiosqlite.connect(str(DB_DIR / "customrole.db")) as db:
                async with db.execute("SELECT guild_id, staff, girl, vip, guest, frnd, reqrole FROM roles") as cur:
                    async for row in cur:
                        slots = {}
                        for i, col in enumerate(["staff", "girl", "vip", "guest", "frnd", "reqrole"]):
                            if row[i + 1]:
                                slots[col] = row[i + 1]
                        if slots:
                            self.cache["role_slots"][row[0]] = slots
                async with db.execute("SELECT guild_id, cmd_name, role_id FROM custom_roles") as cur:
                    async for row in cur:
                        self.cache["custom_role_cmds"].setdefault(row[0], {})[row[1]] = row[2]

        async def load_notify():
            async with aiosqlite.connect(str(DB_DIR / "notify.db")) as db:
                async with db.execute("SELECT guild_id, platform, role_id, channel_id FROM notify_config") as cur:
                    async for row in cur:
                        self.cache.setdefault("notify", {}).setdefault(row[0], {})[row[1]] = {
                            "role_id": row[2], "channel_id": row[3]
                        }

        async def load_whitelist():
            async with aiosqlite.connect(str(DB_DIR / "whitelist.db")) as db:
                async with db.execute("SELECT guild_id, target_id, spam, links, caps, invites, mass_mention FROM whitelist_automod") as cur:
                    async for row in cur:
                        self.cache["whitelist_automod"].setdefault(row[0], {})[row[1]] = {
                            "spam": row[2], "links": row[3], "caps": row[4],
                            "invites": row[5], "mass_mention": row[6],
                        }
                async with db.execute("SELECT guild_id, target_id, warn_cmd, ban_cmd, mute_cmd, purge_cmd, lock_cmd, hide_cmd FROM whitelist_commands") as cur:
                    async for row in cur:
                        self.cache["whitelist_commands"].setdefault(row[0], {})[row[1]] = {
                            "warn_cmd": row[2], "ban_cmd": row[3], "mute_cmd": row[4],
                            "purge_cmd": row[5], "lock_cmd": row[6], "hide_cmd": row[7],
                        }

        # Load all caches in parallel for faster startup (50-70% faster)
        await asyncio.gather(
            load_prefixes(),
            load_blocked(),
            load_antinuke(),
            load_voice_bans(),
            load_ignore(),
            load_np_users(),
            load_afk(),
            load_freezenick(),
            load_autoresponder(),
            load_autoreact(),
            load_media(),
            load_autorole(),
            load_sticky(),
            load_blacklisted_words(),
            load_automod(),
            load_automation(),
            load_custom_roles(),
            load_notify(),
            load_whitelist(),
        )

        log.info("[Cache] Warm-up complete — all data loaded into RAM (parallelized).")

    # ── Cog auto-loader ────────────────────────────────────────
    async def _load_cogs(self) -> None:
        """Recursively load all cogs from cogs/"""
        cog_dir = Path("cogs")
        if not cog_dir.exists():
            log.warning("[Cogs] cogs/ directory not found — skipping.")
            return

        loaded, failed = 0, 0
        for path in sorted(cog_dir.rglob("*.py")):
            if path.name.startswith("_"):
                continue
            module = str(path).replace(os.sep, ".").removesuffix(".py")
            try:
                await self.load_extension(module)
                loaded += 1
                log.info(f"  ✓ {module}")
            except Exception as exc:
                failed += 1
                log.error(f"  ✗ {module} — {exc}")

        log.info(f"[Cogs] Loaded {loaded} cog(s), {failed} failed.")

    # ── Setup hook (called by discord.py before on_ready) ──────
    async def setup_hook(self) -> None:
        log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        log.info("  Zephyr Bot — Initializing …")
        log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        await self._init_databases()
        await self._create_schemas()
        await self._warm_cache()
        
        # ── Music initialization is now handled in on_ready (cogs/events/core.py) ──
        
        await self._load_cogs()

        # ── Sync slash command tree with Discord ──
        try:
            synced = await self.tree.sync()
            log.info(f"[Sync] Synced {len(synced)} slash command(s) globally.")
        except Exception as exc:
            log.error(f"[Sync] Failed to sync command tree: {exc}")

        log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        log.info("  Setup hook complete!")
        log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        # ── Global checks — enforce ignore/blacklist for ALL commands ──
        # Slash commands: tree.interaction_check
        old_check = self.tree.interaction_check

        async def global_interaction_check(interaction: discord.Interaction) -> bool:
            # Blacklist check
            if interaction.user.id in self.cache["blocked_users"]:
                return False
            if interaction.guild and interaction.guild.id in self.cache["blocked_guilds"]:
                return False

            if not interaction.guild:
                return True

            gid = interaction.guild.id

            # Bypass check
            bypass = self.cache["ignore_bypass"].get(gid, set())
            if interaction.user.id in bypass:
                return True

            # Owners/admins always bypass ignore
            if interaction.user.id in self.owner_ids_set:
                return True
            if interaction.user.id == interaction.guild.owner_id:
                return True

            # Channel ignore
            ign_ch = self.cache["ignore_channels"].get(gid, set())
            if interaction.channel_id in ign_ch:
                em = discord.Embed(
                    description=f"{EMOJIS['denied']} This channel is **ignored** by Zephyr.",
                    color=COLORS["error"],
                )
                try:
                    await interaction.response.send_message(embed=em, ephemeral=True)
                except Exception:
                    pass
                return False

            # User ignore
            ign_usr = self.cache["ignore_users"].get(gid, set())
            if interaction.user.id in ign_usr:
                return False

            return True

        self.tree.interaction_check = global_interaction_check

        # Prefix commands: before_invoke
        @self.before_invoke
        async def global_before_invoke(ctx: commands.Context):
            if ctx.author.id in self.cache["blocked_users"]:
                raise commands.CheckFailure("Blocked user")
            if ctx.guild and ctx.guild.id in self.cache["blocked_guilds"]:
                raise commands.CheckFailure("Blocked guild")
            if not ctx.guild:
                return

            gid = ctx.guild.id

            # Bypass
            bypass = self.cache["ignore_bypass"].get(gid, set())
            if ctx.author.id in bypass:
                return
            if ctx.author.id in self.owner_ids_set:
                return
            if ctx.author.id == ctx.guild.owner_id:
                return

            # Channel ignore
            ign_ch = self.cache["ignore_channels"].get(gid, set())
            if ctx.channel.id in ign_ch:
                raise commands.CheckFailure("Ignored channel")

            # User ignore
            ign_usr = self.cache["ignore_users"].get(gid, set())
            if ctx.author.id in ign_usr:
                raise commands.CheckFailure("Ignored user")

    # ── Custom get_context ─────────────────────────────────────
    async def get_context(self, message, *, cls=None):
        from core.Context import GemContext
        return await super().get_context(message, cls=cls or GemContext)

    # ── Global error handler for prefix commands ───────────────
    async def on_command_error(self, ctx: commands.Context, error: commands.CommandError):
        if isinstance(error, commands.CommandNotFound):
            return  # silently ignore unknown prefix commands
        if isinstance(error, commands.MissingPermissions):
            em = discord.Embed(
                description=f"{EMOJIS['denied']} You don't have permission to use this command.",
                color=COLORS["error"],
            )
            await ctx.send(embed=em, delete_after=10)
            return
        if isinstance(error, commands.MissingRequiredArgument):
            em = discord.Embed(
                description=f"{EMOJIS['error']} Missing required argument: `{error.param.name}`",
                color=COLORS["error"],
            )
            await ctx.send(embed=em, delete_after=10)
            return
        if isinstance(error, commands.CommandOnCooldown):
            em = discord.Embed(
                description=f"{EMOJIS['warning']} This command is on cooldown. Try again in **{error.retry_after:.1f}s**.",
                color=COLORS["warning"],
            )
            await ctx.send(embed=em, delete_after=10)
            return
        # Log unexpected errors
        log.error(f"Unhandled error in command {ctx.command}: {error}", exc_info=error)
