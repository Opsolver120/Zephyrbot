r"""
custjis.py — Centralised Emoji & Color Registry for Zephyr Bot.

╔══════════════════════════════════════════════════════════════╗
║  HOW TO SET UP YOUR CUSTOM EMOJIS:                           ║
║                                                              ║
║  1. Upload all emojis to your bot's emoji servers            ║
║  2. In Discord, type  \:emoji_name:  to get the full ID      ║
║  3. Replace the Unicode emojis below with your custom ones   ║
║                                                              ║
║  Example:                                                    ║
║    Before:  "✅"                                              ║
║    After:   "<:success:1234567890123456>"                     ║
║                                                              ║
║  Animated emojis (prefix "a_") use <a:name:id> format.       ║
║  Static emojis use <:name:id> format.                        ║
╚══════════════════════════════════════════════════════════════╝

ALL emojis and ALL colors MUST be defined here.
NEVER hardcode emoji IDs inside command files — always import from here.

Usage:
    from utils.custjis import EMOJIS, COLORS, RESPONSES, LINKS
"""

# ═══════════════════════════════════════════════════════════════
#  LINKS — Loaded dynamically from config.yml
# ═══════════════════════════════════════════════════════════════

def _load_links():
    import yaml
    try:
        with open("config.yml", "r", encoding="utf-8") as f:
            c = yaml.safe_load(f)
            return c.get("links", {})
    except Exception:
        return {}

_cfg_links = _load_links()

LINKS: dict[str, str] = {
    "support":      _cfg_links.get("support_server", "https://discord.gg/placeholder"),
    "website":      _cfg_links.get("website", "https://zephyr.bot"),
    "docs":         _cfg_links.get("docs", "https://docs.zephyr.bot"),
    "invite":       _cfg_links.get("bot_invite", "https://discord.com/oauth2/authorize?client_id=YOUR_ID&permissions=8&scope=bot%20applications.commands"),
    "vote":         _cfg_links.get("vote", "https://top.gg/bot/YOUR_ID/vote"),
    "github":       _cfg_links.get("github", "https://github.com/your-repo"),
}

# ═══════════════════════════════════════════════════════════════
#  EMOJIS — Unicode fallbacks (replace with custom IDs later)
# ═══════════════════════════════════════════════════════════════

EMOJIS: dict[str, str] = {

    # ── STATUS / FEEDBACK ──
    "success":          "✅",
    "error":            "❌",
    "warning":          "⚠️",
    "denied":           "🚫",
    "info":             "ℹ️",
    "loading":          "⏳",
    "processing":       "🔄",
    "checkmark":        "✔️",
    "crossmark":        "✖️",
    "online":           "🟢",
    "idle":             "🌙",
    "dnd":              "🔴",
    "offline":          "⚫",
    "enabled":          "✅",
    "disabled":         "❌",

    # ── MODERATION ──
    "ban_hammer":       "🔨",
    "kick":             "👢",
    "mute":             "🔇",
    "unmute":           "🔊",
    "warn":             "⚠️",
    "timeout":          "⏱️",
    "unban":            "🕊️",
    "purge":            "🗑️",
    "lock":             "🔒",
    "unlock":           "🔓",
    "nuke":             "☢️",
    "deafen":           "🎧",
    "voiceban":         "🚫",

    # ── SECURITY ──
    "shield":           "🛡️",
    "shield_on":        "🛡️",
    "shield_off":       "🛡️",
    "antinuke":         "☢️",
    "automod":          "🤖",
    "whitelist":        "📝",
    "emergency":        "🚨",
    "nightmode":        "🌙",

    # ── ANIMATED (use Unicode until you add custom) ──
    "a_success":        "✅",
    "a_error":          "❌",
    "a_loading":        "⏳",
    "a_alert":          "🚨",
    "a_ban":            "🔨",
    "a_shield":         "🛡️",
    "a_fire":           "🔥",
    "a_star":           "⭐",
    "a_wave":           "👋",
    "a_boost":          "🚀",
    "a_music":          "🎵",
    "a_giveaway":       "🎉",
    "a_confetti":       "🎊",
    "a_typing":         "💬",
    "a_heart":          "❤️",
    "a_verify":         "✅",
    "a_crown":          "👑",
    "a_sparkle":        "✨",
    "a_globe":          "🌍",
    "a_rocket":         "🚀",
    "a_thunder":        "⚡",
    "a_diamond":        "💎",
    "a_gift":           "🎁",
    "a_clock":          "🕒",
    "a_check_green":    "✅",
    "a_cross_red":      "❌",
    "a_warning_yellow": "⚠️",
    "a_ping":           "🏓",
    "a_nitro":          "🚀",
    "a_partner":        "🤝",
    "a_live":           "🔴",

    # ── UTILITY / GENERAL ──
    "channel":          "💬",
    "voice":            "🔊",
    "role":             "🎭",
    "member":           "👤",
    "bot":              "🤖",
    "owner":            "👑",
    "admin":            "🛡️",
    "moderator":        "👮",
    "staff":            "🛠️",
    "boost":            "🚀",
    "invite":           "🔗",
    "link":             "🔗",
    "settings":         "⚙️",
    "edit":             "✏️",
    "delete":           "🗑️",
    "add":              "➕",
    "remove":           "➖",
    "search":           "🔍",
    "pin":              "📌",
    "reply":            "↩️",
    "thread":           "🧵",
    "stage":            "🎤",
    "emoji":            "😀",
    "sticker":          "🌠",
    "image":            "🖼️",
    "globe":            "🌍",
    "hash":             "#️⃣",
    "translate":        "🌐",
    "timer":            "⏱️",
    "weather":          "⛅",
    "map":              "🗺️",
    "support":          "🚑",

    # ── NAVIGATION ──
    "arrow_left":       "⬅️",
    "arrow_right":      "➡️",
    "arrow_up":         "⬆️",
    "arrow_down":       "⬇️",
    "first_page":       "⏮️",
    "last_page":        "⏭️",
    "share":            "📤",

    # ── MUSIC ──
    "play":             "▶️",
    "pause":            "⏸️",
    "stop":             "⏹️",
    "skip":             "⏭️",
    "previous":         "⏮️",
    "loop":             "🔁",
    "shuffle":          "🔀",
    "volume":           "🔊",
    "queue":            "📋",
    "autoplay":         "📻",
    "spotify":          "🟢",
    "youtube":          "🔴",
    "soundcloud":       "☁️",

    # ── BADGES ──
    "badge_owner":      "👑",
    "badge_staff":      "🛠️",
    "badge_partner":    "🤝",
    "badge_sponsor":    "💲",
    "badge_friend":     "❤️",
    "badge_early":      "🕒",
    "badge_vip":        "🌟",
    "badge_bughunter":  "🐛",

    # ── MISC / DECORATIVE ──
    "giveaway":         "🎉",
    "zephyr":              "💎",
    "dot":              "•",
    "dash":             "—",
    "blank":            "⠀",
    "divider":          "───",
    "crown":            "👑",
    "fire":             "🔥",
    "heart":            "❤️",
    "calendar":         "📅",
    "message":          "💬",
    "palette":          "🎨",
    "infinity":         "♾️",
    "ticket":           "🎫",
    
    # ── PING COMMAND ──
    "ping_pong":        "🏓",
    "websocket":        "📡",
    "database":         "💾",
    "cache":            "🧠",
    "uptime":           "⏲️",
    "green_circle":     "🟢",
    "yellow_circle":    "🟡",
    "orange_circle":    "🟠",
    "red_circle":       "🔴",
    
    # ── HELP COMMAND / COG CATEGORIES ──
    "camera":           "📷",
    "toolbox":          "🧰",
    "bell":             "🔔",
    "waving_hand":      "👋",
}


# ═══════════════════════════════════════════════════════════════
#  COLORS — Hex values as integers for discord.Embed(color=…)
# ═══════════════════════════════════════════════════════════════

COLORS: dict[str, int] = {
    # ── BRIGHT PURPLE CORE THEME ──
    "primary":      0xA855F7,   # Electric Violet
    "success":      0x00FF11,   # Neon Cyan
    "error":        0xFF0000,   # Hot Rose
    "warning":      0xFF0000,   # Bright Amber
    "info":         0xC084FC,   # Soft Lavender
    "embed":        0x1E1B2E,   # Deep Purple Dark
    "premium":      0xE879F9,   # Bright Magenta
    "white":        0xF5F3FF,   # Ghost White Purple
    "invisible":    0x1E1B2E,   # Deep Purple Dark
    "boost":        0xE879F9,   # Bright Magenta
    "gold":         0xF59E0B,   # Warm Gold
    "cyan":         0x06B6D4,   # Cyan Pop
    "zephyr":      0xA855F7,   # Zephyr Purple
    "spotify":      0x1DB954,
    "youtube":      0xFF0000,
    "twitch":       0x9146FF,
    # ── EXTRA BRIGHT ACCENTS ──
    "music":        0xD946EF,   # Fuchsia
    "mod":          0x8B5CF6,   # Indigo
    "antinuke":     0xF97316,   # Neon Orange
    "security":     0x7C3AED,   # Deep Violet
}


# ═══════════════════════════════════════════════════════════════
#  RESPONSES — Pre-baked embed templates
# ═══════════════════════════════════════════════════════════════

RESPONSES: dict[str, dict] = {
    "success_default": {
        "description": f"{EMOJIS['success']} Operation completed successfully.",
        "color": COLORS["success"],
    },
    "error_default": {
        "description": f"{EMOJIS['error']} Something went wrong. Please try again.",
        "color": COLORS["error"],
    },
    "permission_denied": {
        "description": f"{EMOJIS['denied']} You do not have permission to use this command.",
        "color": COLORS["error"],
    },
    "cooldown": {
        "description": f"{EMOJIS['warning']} You are on cooldown. Please wait before using this command again.",
        "color": COLORS["warning"],
    },
    "not_found": {
        "description": f"{EMOJIS['error']} The requested resource was not found.",
        "color": COLORS["error"],
    },
    "blacklisted": {
        "description": f"{EMOJIS['denied']} You have been blacklisted from using this bot.",
        "color": COLORS["error"],
    },
}
