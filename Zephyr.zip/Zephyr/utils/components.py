"""
components.py — Discord Components V2 "Ultra-Premium" UI Helpers for Zephyr Bot.

Provides reusable Views, Buttons, and Select Menus that implement the
"Ultra-Premium" aesthetic rules from codeconfig.md:
  - Rich interactive components embedded in messages
  - Every view includes Support/Docs link buttons in the bottom row
  - All buttons use emojis from custjis.EMOJIS
  - Select Menus for config commands
  - Confirm/Cancel dialogs
  - Multi-step configuration wizards

Usage:
    from utils.components import GemView, ConfirmView, ConfigSelectView, NPConfigView
"""
from __future__ import annotations
import discord
from typing import Optional, List, Callable
from utils.custjis import EMOJIS, COLORS, LINKS


# ═══════════════════════════════════════════════════════════════
#  BASE VIEW — All Zephyr views inherit from this
# ═══════════════════════════════════════════════════════════════

class GemView(discord.ui.View):
    """
    Base view for all Zephyr interactions.
    Automatically adds Support + Docs link buttons in the last row.
    Supports optional timeout (default 180s).
    """

    def __init__(self, *, timeout: float = 180.0, add_links: bool = True):
        super().__init__(timeout=timeout)
        if add_links:
            self.add_item(discord.ui.Button(
                label="Support",
                emoji=EMOJIS.get("support", "💬"),
                url=LINKS["support"],
                style=discord.ButtonStyle.link,
                row=4,
            ))
            self.add_item(discord.ui.Button(
                label="Docs",
                emoji=EMOJIS.get("link", "🔗"),
                url=LINKS["docs"],
                style=discord.ButtonStyle.link,
                row=4,
            ))

    async def on_timeout(self):
        """Disable all non-link items on timeout."""
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue  # Don't disable link buttons
                item.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

    message: discord.Message | None = None


# ═══════════════════════════════════════════════════════════════
#  CONFIRM / CANCEL VIEW
# ═══════════════════════════════════════════════════════════════

class ConfirmView(GemView):
    """
    A simple Confirm/Cancel dialog with buttons.
    Usage:
        view = ConfirmView(author_id=interaction.user.id)
        await interaction.response.send_message("Are you sure?", view=view)
        await view.wait()
        if view.confirmed:  ...
    """

    def __init__(self, author_id: int, *, timeout: float = 30.0):
        super().__init__(timeout=timeout, add_links=False)
        self.author_id = author_id
        self.confirmed: bool | None = None

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.success, emoji="✅", row=0)
    async def confirm_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} This isn't your interaction.", ephemeral=True)
        self.confirmed = True
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                item.disabled = True
        await interaction.response.edit_message(view=self)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.danger, emoji="❌", row=0)
    async def cancel_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} This isn't your interaction.", ephemeral=True)
        self.confirmed = False
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  MULTI-SELECT CONFIG VIEW
# ═══════════════════════════════════════════════════════════════

class ConfigSelectView(GemView):
    """
    A view with one or more Select Menus for configuration.
    Each select returns its values via callback.

    Usage:
        options = [
            discord.SelectOption(label="Ban", value="ban", emoji="🔨"),
            discord.SelectOption(label="Kick", value="kick", emoji="👢"),
        ]
        view = ConfigSelectView(author_id=123, options=options, placeholder="Select permissions...")
        await interaction.response.send_message("Configure:", view=view)
        await view.wait()
        selected = view.selected_values  # list of selected values
    """

    def __init__(self, author_id: int, options: list[discord.SelectOption], *,
                 placeholder: str = "Select options...", min_values: int = 1,
                 max_values: int | None = None, timeout: float = 120.0):
        super().__init__(timeout=timeout, add_links=True)
        self.author_id = author_id
        self.selected_values: list[str] = []
        actual_max = max_values or len(options)
        self._select = discord.ui.Select(
            placeholder=placeholder,
            options=options,
            min_values=min_values,
            max_values=min(actual_max, len(options)),
            row=0,
        )
        self._select.callback = self._select_callback
        self.add_item(self._select)

    async def _select_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} This isn't your interaction.", ephemeral=True)
        self.selected_values = self._select.values
        await interaction.response.defer()

    @discord.ui.button(label="Save", style=discord.ButtonStyle.success, emoji="💾", row=1)
    async def save_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} This isn't your interaction.", ephemeral=True)
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  WHITELIST CONFIG VIEW (3 Select Menus as per codeconfig.md)
# ═══════════════════════════════════════════════════════════════

class WhitelistConfigView(GemView):
    """
    Ultra-Premium whitelist configuration panel with 3 distinct select menus:
    1. Antinuke Bypass — Ban, Kick, Channel, Role, Webhook, etc.
    2. Automod Immunity — Spam, Links, Caps, Invites, Mass Mention
    3. Command Access — Warn, Ban, Mute, Purge, Lock, Hide
    """

    def __init__(self, author_id: int):
        super().__init__(timeout=120.0, add_links=True)
        self.author_id = author_id
        self.antinuke_perms: list[str] = []
        self.automod_perms: list[str] = []
        self.command_perms: list[str] = []

        # Select 1: Antinuke Bypass
        an_options = [
            discord.SelectOption(label="Ban", value="ban", emoji=EMOJIS.get("ban_hammer", "🔨"), description="Allow banning members"),
            discord.SelectOption(label="Kick", value="kick", emoji=EMOJIS.get("kick", "👢"), description="Allow kicking members"),
            discord.SelectOption(label="Channel Create", value="chcr", emoji=EMOJIS.get("add", "➕"), description="Allow creating channels"),
            discord.SelectOption(label="Channel Delete", value="chdl", emoji=EMOJIS.get("delete", "🗑️"), description="Allow deleting channels"),
            discord.SelectOption(label="Channel Update", value="chup", emoji=EMOJIS.get("edit", "✏️"), description="Allow editing channels"),
            discord.SelectOption(label="Role Create", value="rlcr", emoji=EMOJIS.get("role", "🏷️"), description="Allow creating roles"),
            discord.SelectOption(label="Role Delete", value="rldl", emoji=EMOJIS.get("delete", "🗑️"), description="Allow deleting roles"),
            discord.SelectOption(label="Role Update", value="rlup", emoji=EMOJIS.get("edit", "✏️"), description="Allow editing roles"),
            discord.SelectOption(label="Server Update", value="serverup", emoji=EMOJIS.get("settings", "⚙️"), description="Allow editing server"),
            discord.SelectOption(label="Webhook Manage", value="mngweb", emoji=EMOJIS.get("link", "🔗"), description="Allow managing webhooks"),
            discord.SelectOption(label="Bot Add", value="botadd", emoji=EMOJIS.get("bot", "🤖"), description="Allow adding bots"),
            discord.SelectOption(label="Prune", value="prune", emoji=EMOJIS.get("purge", "🧹"), description="Allow member prune"),
            discord.SelectOption(label="Member Update", value="memup", emoji=EMOJIS.get("member", "👤"), description="Allow member updates"),
        ]
        self._an_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('antinuke', '☢️')} Antinuke Bypass Permissions",
            options=an_options, min_values=0, max_values=len(an_options), row=0,
        )
        self._an_select.callback = self._an_callback
        self.add_item(self._an_select)

        # Select 2: Automod Immunity
        am_options = [
            discord.SelectOption(label="Anti Spam", value="spam", emoji=EMOJIS.get("automod", "🤖"), description="Bypass spam filter"),
            discord.SelectOption(label="Anti Links", value="links", emoji=EMOJIS.get("link", "🔗"), description="Bypass link filter"),
            discord.SelectOption(label="Anti Caps", value="caps", emoji=EMOJIS.get("warn", "⚠️"), description="Bypass caps filter"),
            discord.SelectOption(label="Anti Invites", value="invites", emoji=EMOJIS.get("invite", "📨"), description="Bypass invite filter"),
            discord.SelectOption(label="Anti Mass Mention", value="massmention", emoji=EMOJIS.get("member", "👤"), description="Bypass mention filter"),
        ]
        self._am_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('automod', '🤖')} Automod Immunity",
            options=am_options, min_values=0, max_values=len(am_options), row=1,
        )
        self._am_select.callback = self._am_callback
        self.add_item(self._am_select)

        # Select 3: Command Access
        cmd_options = [
            discord.SelectOption(label="Warn", value="warn", emoji=EMOJIS.get("warn", "⚠️")),
            discord.SelectOption(label="Ban", value="cmd_ban", emoji=EMOJIS.get("ban_hammer", "🔨")),
            discord.SelectOption(label="Mute", value="mute", emoji=EMOJIS.get("mute", "🔇")),
            discord.SelectOption(label="Purge", value="purge", emoji=EMOJIS.get("purge", "🧹")),
            discord.SelectOption(label="Lock", value="lock", emoji=EMOJIS.get("lock", "🔒")),
            discord.SelectOption(label="Hide", value="hide", emoji=EMOJIS.get("shield", "🛡️")),
        ]
        self._cmd_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('staff', '🔧')} Command Access (Prefix + Slash)",
            options=cmd_options, min_values=0, max_values=len(cmd_options), row=2,
        )
        self._cmd_select.callback = self._cmd_callback
        self.add_item(self._cmd_select)

        # Save button
        save_btn = discord.ui.Button(label="Save Configuration", style=discord.ButtonStyle.success, emoji="💾", row=3)
        save_btn.callback = self._save_callback
        self.add_item(save_btn)

        self.saved = False

    async def _an_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.antinuke_perms = self._an_select.values
        await interaction.response.defer()

    async def _am_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.automod_perms = self._am_select.values
        await interaction.response.defer()

    async def _cmd_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.command_perms = self._cmd_select.values
        await interaction.response.defer()

    async def _save_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.saved = True
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  PAGINATED VIEW (Next/Previous buttons)
# ═══════════════════════════════════════════════════════════════

class PaginatedView(GemView):
    """
    Paginated embed viewer with Next/Previous/First/Last buttons.

    Usage:
        pages = [embed1, embed2, embed3]
        view = PaginatedView(pages=pages, author_id=123)
        await interaction.response.send_message(embed=pages[0], view=view)
    """

    def __init__(self, pages: list[discord.Embed], author_id: int, *, timeout: float = 120.0):
        super().__init__(timeout=timeout, add_links=False)
        self.pages = pages
        self.author_id = author_id
        self.current_page = 0
        self._update_buttons()

    def _update_buttons(self):
        self.first_btn.disabled = self.current_page == 0
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page >= len(self.pages) - 1
        self.last_btn.disabled = self.current_page >= len(self.pages) - 1

    @discord.ui.button(emoji="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def first_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.current_page = 0
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current_page], view=self)

    @discord.ui.button(emoji="◀️", style=discord.ButtonStyle.primary, row=0)
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.current_page = max(0, self.current_page - 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current_page], view=self)

    @discord.ui.button(emoji="▶️", style=discord.ButtonStyle.primary, row=0)
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.current_page = min(len(self.pages) - 1, self.current_page + 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current_page], view=self)

    @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary, row=0)
    async def last_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.current_page = len(self.pages) - 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current_page], view=self)


# ═══════════════════════════════════════════════════════════════
#  ANTINUKE SETUP VIEW (Select Menu + Buttons)
# ═══════════════════════════════════════════════════════════════

class AntinukeSetupView(GemView):
    """
    Interactive antinuke configuration panel.
    Select Menu to toggle modules -> Buttons to Save.
    """

    def __init__(self, author_id: int, current_settings: dict | None = None):
        super().__init__(timeout=120.0, add_links=True)
        self.author_id = author_id
        self.selected_modules: list[str] = []
        self.saved = False

        modules = [
            discord.SelectOption(label="Anti Ban", value="ban", emoji=EMOJIS.get("ban_hammer", "🔨"), description="Prevent mass banning"),
            discord.SelectOption(label="Anti Kick", value="kick", emoji=EMOJIS.get("kick", "👢"), description="Prevent mass kicking"),
            discord.SelectOption(label="Anti Channel Create", value="chcr", emoji=EMOJIS.get("add", "➕"), description="Prevent channel creation"),
            discord.SelectOption(label="Anti Channel Delete", value="chdl", emoji=EMOJIS.get("delete", "🗑️"), description="Prevent channel deletion"),
            discord.SelectOption(label="Anti Channel Update", value="chup", emoji=EMOJIS.get("edit", "✏️"), description="Prevent channel edits"),
            discord.SelectOption(label="Anti Role Create", value="rlcr", emoji=EMOJIS.get("role", "🏷️"), description="Prevent role creation"),
            discord.SelectOption(label="Anti Role Delete", value="rldl", emoji=EMOJIS.get("delete", "🗑️"), description="Prevent role deletion"),
            discord.SelectOption(label="Anti Role Update", value="rlup", emoji=EMOJIS.get("edit", "✏️"), description="Prevent role edits"),
            discord.SelectOption(label="Anti Server Update", value="serverup", emoji=EMOJIS.get("settings", "⚙️"), description="Prevent server changes"),
            discord.SelectOption(label="Anti Webhook", value="mngweb", emoji=EMOJIS.get("link", "🔗"), description="Prevent webhook abuse"),
            discord.SelectOption(label="Anti Bot Add", value="botadd", emoji=EMOJIS.get("bot", "🤖"), description="Prevent unauthorized bots"),
        ]
        # Mark currently enabled as default
        if current_settings:
            for opt in modules:
                if current_settings.get(opt.value):
                    opt.default = True

        self._select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('antinuke', '☢️')} Toggle Antinuke Modules",
            options=modules, min_values=0, max_values=len(modules), row=0,
        )
        self._select.callback = self._select_cb
        self.add_item(self._select)

        save_btn = discord.ui.Button(label="Save", style=discord.ButtonStyle.success, emoji="💾", row=1)
        save_btn.callback = self._save_cb
        self.add_item(save_btn)

    async def _select_cb(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.selected_modules = self._select.values
        await interaction.response.defer()

    async def _save_cb(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.saved = True
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  AUTOMOD SETUP VIEW (Select Menu for filter toggles)
# ═══════════════════════════════════════════════════════════════

class AutomodSetupView(GemView):
    """Interactive automod configuration with filter toggles."""

    def __init__(self, author_id: int):
        super().__init__(timeout=120.0, add_links=True)
        self.author_id = author_id
        self.selected_filters: list[str] = []
        self.saved = False

        filters = [
            discord.SelectOption(label="Anti Spam", value="spam", emoji=EMOJIS.get("automod", "🤖"), description="Block spam messages"),
            discord.SelectOption(label="Anti Links", value="links", emoji=EMOJIS.get("link", "🔗"), description="Block external links"),
            discord.SelectOption(label="Anti Invites", value="invites", emoji=EMOJIS.get("invite", "📨"), description="Block Discord invites"),
            discord.SelectOption(label="Anti Caps", value="caps", emoji=EMOJIS.get("warn", "⚠️"), description="Block excessive caps"),
            discord.SelectOption(label="Anti Mass Mention", value="massmention", emoji=EMOJIS.get("member", "👤"), description="Block mass mentions"),
            discord.SelectOption(label="Anti NSFW", value="nsfw", emoji=EMOJIS.get("shield", "🛡️"), description="Block NSFW content (uses Discord AutoMod)"),
        ]
        self._select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('automod', '🤖')} Select filters to enable",
            options=filters, min_values=0, max_values=len(filters), row=0,
        )
        self._select.callback = self._select_cb
        self.add_item(self._select)

        save_btn = discord.ui.Button(label="Save Filters", style=discord.ButtonStyle.success, emoji="💾", row=1)
        save_btn.callback = self._save_cb
        self.add_item(save_btn)

    async def _select_cb(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.selected_filters = self._select.values
        await interaction.response.defer()

    async def _save_cb(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not yours.", ephemeral=True)
        self.saved = True
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  NP CONFIG VIEW (Interactive No-Prefix Management)
# ═══════════════════════════════════════════════════════════════

class NPConfigView(GemView):
    """
    Interactive No-Prefix configuration panel with duration selection.
    Embedded select menu for duration + action buttons.
    """

    def __init__(self, author_id: int, target_user: discord.User):
        super().__init__(timeout=120.0, add_links=True)
        self.author_id = author_id
        self.target_user = target_user
        self.selected_duration: str | None = None
        self.action_taken: str | None = None

        # Duration select menu
        duration_options = [
            discord.SelectOption(label="10 Minutes", value="10m", emoji=EMOJIS.get("a_clock", "⏰"), description="Quick temporary access"),
            discord.SelectOption(label="1 Hour", value="1h", emoji=EMOJIS.get("a_clock", "⏰"), description="Short-term access"),
            discord.SelectOption(label="1 Day", value="1d", emoji=EMOJIS.get("calendar", "📅"), description="Daily access"),
            discord.SelectOption(label="1 Week", value="7d", emoji=EMOJIS.get("calendar", "📅"), description="Weekly access"),
            discord.SelectOption(label="1 Month", value="30d", emoji=EMOJIS.get("calendar", "📅"), description="Monthly access"),
            discord.SelectOption(label="Lifetime", value="lifetime", emoji=EMOJIS.get("a_star", "⭐"), description="Permanent access"),
        ]
        self._duration_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('a_clock', '⏰')} Select Duration",
            options=duration_options, min_values=1, max_values=1, row=0,
        )
        self._duration_select.callback = self._duration_callback
        self.add_item(self._duration_select)

        # Action buttons
        grant_btn = discord.ui.Button(label="Grant Access", style=discord.ButtonStyle.success, emoji=EMOJIS.get("success", "✅"), row=1)
        grant_btn.callback = self._grant_callback
        self.add_item(grant_btn)

        revoke_btn = discord.ui.Button(label="Revoke Access", style=discord.ButtonStyle.danger, emoji=EMOJIS.get("delete", "🗑️"), row=1)
        revoke_btn.callback = self._revoke_callback
        self.add_item(revoke_btn)

    async def _duration_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.selected_duration = self._duration_select.values[0]
        await interaction.response.defer()

    async def _grant_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        if not self.selected_duration:
            return await interaction.response.send_message(f"{EMOJIS['error']} Please select a duration first!", ephemeral=True)
        self.action_taken = "grant"
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)

    async def _revoke_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.action_taken = "revoke"
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  MODERATION ACTION VIEW (Quick Mod Actions)
# ═══════════════════════════════════════════════════════════════

class ModerationActionView(GemView):
    """
    Quick moderation panel with action buttons and reason input.
    Embedded in moderation command responses.
    """

    def __init__(self, author_id: int, target: discord.Member, actions: List[str]):
        super().__init__(timeout=60.0, add_links=False)
        self.author_id = author_id
        self.target = target
        self.selected_action: str | None = None
        self.reason: str = "No reason provided"

        # Action buttons based on provided actions
        action_styles = {
            "warn": (discord.ButtonStyle.secondary, EMOJIS.get("warn", "⚠️")),
            "kick": (discord.ButtonStyle.primary, EMOJIS.get("kick", "👢")),
            "ban": (discord.ButtonStyle.danger, EMOJIS.get("ban_hammer", "🔨")),
            "timeout": (discord.ButtonStyle.secondary, EMOJIS.get("timeout", "⏱️")),
            "mute": (discord.ButtonStyle.secondary, EMOJIS.get("mute", "🔇")),
        }

        for action in actions[:5]:  # Max 5 actions per row
            if action in action_styles:
                style, emoji = action_styles[action]
                btn = discord.ui.Button(label=action.title(), style=style, emoji=emoji, row=0)
                btn.callback = self._create_action_callback(action)
                self.add_item(btn)

        # Cancel button
        cancel_btn = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.secondary, emoji="❌", row=1)
        cancel_btn.callback = self._cancel_callback
        self.add_item(cancel_btn)

    def _create_action_callback(self, action: str):
        async def callback(interaction: discord.Interaction):
            if interaction.user.id != self.author_id:
                return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
            self.selected_action = action
            self.stop()
            for item in self.children:
                if isinstance(item, discord.ui.Button):
                    item.disabled = True
            await interaction.response.edit_message(view=self)
        return callback

    async def _cancel_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.selected_action = None
        self.stop()
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  GIVEAWAY SETUP VIEW (Multi-Step Configuration)
# ═══════════════════════════════════════════════════════════════

class GiveawaySetupView(GemView):
    """
    Interactive giveaway setup with duration and winner selection.
    Uses select menus for configuration.
    """

    def __init__(self, author_id: int):
        super().__init__(timeout=180.0, add_links=True)
        self.author_id = author_id
        self.duration: str | None = None
        self.winners: int = 1
        self.confirmed: bool = False

        # Duration select
        duration_options = [
            discord.SelectOption(label="5 Minutes", value="5m", emoji=EMOJIS.get("a_clock", "⏰"), description="Quick giveaway"),
            discord.SelectOption(label="30 Minutes", value="30m", emoji=EMOJIS.get("a_clock", "⏰")),
            discord.SelectOption(label="1 Hour", value="1h", emoji=EMOJIS.get("a_clock", "⏰")),
            discord.SelectOption(label="6 Hours", value="6h", emoji=EMOJIS.get("calendar", "📅")),
            discord.SelectOption(label="12 Hours", value="12h", emoji=EMOJIS.get("calendar", "📅")),
            discord.SelectOption(label="1 Day", value="1d", emoji=EMOJIS.get("calendar", "📅")),
            discord.SelectOption(label="3 Days", value="3d", emoji=EMOJIS.get("calendar", "📅")),
            discord.SelectOption(label="1 Week", value="7d", emoji=EMOJIS.get("calendar", "📅")),
        ]
        self._duration_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('a_clock', '⏰')} Select Giveaway Duration",
            options=duration_options, min_values=1, max_values=1, row=0,
        )
        self._duration_select.callback = self._duration_callback
        self.add_item(self._duration_select)

        # Winners select
        winner_options = [
            discord.SelectOption(label="1 Winner", value="1", emoji=EMOJIS.get("a_star", "⭐"), default=True),
            discord.SelectOption(label="2 Winners", value="2", emoji=EMOJIS.get("a_star", "⭐")),
            discord.SelectOption(label="3 Winners", value="3", emoji=EMOJIS.get("a_star", "⭐")),
            discord.SelectOption(label="5 Winners", value="5", emoji=EMOJIS.get("a_star", "⭐")),
            discord.SelectOption(label="10 Winners", value="10", emoji=EMOJIS.get("a_star", "⭐")),
        ]
        self._winner_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('a_star', '⭐')} Select Number of Winners",
            options=winner_options, min_values=1, max_values=1, row=1,
        )
        self._winner_select.callback = self._winner_callback
        self.add_item(self._winner_select)

        # Start button
        start_btn = discord.ui.Button(label="Start Giveaway", style=discord.ButtonStyle.success, emoji=EMOJIS.get("success", "✅"), row=2)
        start_btn.callback = self._start_callback
        self.add_item(start_btn)

        # Cancel button
        cancel_btn = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.danger, emoji="❌", row=2)
        cancel_btn.callback = self._cancel_callback
        self.add_item(cancel_btn)

    async def _duration_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.duration = self._duration_select.values[0]
        await interaction.response.defer()

    async def _winner_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.winners = int(self._winner_select.values[0])
        await interaction.response.defer()

    async def _start_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        if not self.duration:
            return await interaction.response.send_message(f"{EMOJIS['error']} Please select a duration first!", ephemeral=True)
        self.confirmed = True
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)

    async def _cancel_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.confirmed = False
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  WELCOME MESSAGE SETUP VIEW (Interactive Configuration)
# ═══════════════════════════════════════════════════════════════

class WelcomeSetupView(GemView):
    """
    Interactive welcome message configuration with type and style selection.
    """

    def __init__(self, author_id: int):
        super().__init__(timeout=180.0, add_links=True)
        self.author_id = author_id
        self.message_type: str = "simple"
        self.embed_color: str | None = None
        self.auto_delete: int = 0
        self.saved: bool = False

        # Message type select
        type_options = [
            discord.SelectOption(label="Simple Text", value="simple", emoji=EMOJIS.get("message", "💬"), description="Plain text message", default=True),
            discord.SelectOption(label="Embed", value="embed", emoji=EMOJIS.get("a_star", "⭐"), description="Rich embed message"),
            discord.SelectOption(label="Image Banner", value="image", emoji=EMOJIS.get("image", "🖼️"), description="Custom image banner"),
        ]
        self._type_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('settings', '⚙️')} Select Message Type",
            options=type_options, min_values=1, max_values=1, row=0,
        )
        self._type_select.callback = self._type_callback
        self.add_item(self._type_select)

        # Color select (for embeds)
        color_options = [
            discord.SelectOption(label="Zephyr Blue", value="zephyr", emoji="💎", description="Premium blue"),
            discord.SelectOption(label="Success Green", value="success", emoji="✅", description="Bright green"),
            discord.SelectOption(label="Gold", value="gold", emoji="🏆", description="Golden yellow"),
            discord.SelectOption(label="Purple", value="premium", emoji="👑", description="Royal purple"),
            discord.SelectOption(label="Red", value="error", emoji="🔴", description="Vibrant red"),
        ]
        self._color_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('palette', '🎨')} Select Embed Color",
            options=color_options, min_values=1, max_values=1, row=1,
        )
        self._color_select.callback = self._color_callback
        self.add_item(self._color_select)

        # Auto-delete select
        delete_options = [
            discord.SelectOption(label="Never Delete", value="0", emoji=EMOJIS.get("infinity", "♾️"), description="Keep forever", default=True),
            discord.SelectOption(label="Delete after 10s", value="10", emoji=EMOJIS.get("a_clock", "⏰")),
            discord.SelectOption(label="Delete after 30s", value="30", emoji=EMOJIS.get("a_clock", "⏰")),
            discord.SelectOption(label="Delete after 1m", value="60", emoji=EMOJIS.get("a_clock", "⏰")),
            discord.SelectOption(label="Delete after 5m", value="300", emoji=EMOJIS.get("a_clock", "⏰")),
        ]
        self._delete_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('delete', '🗑️')} Auto-Delete Duration",
            options=delete_options, min_values=1, max_values=1, row=2,
        )
        self._delete_select.callback = self._delete_callback
        self.add_item(self._delete_select)

        # Save button
        save_btn = discord.ui.Button(label="Save Configuration", style=discord.ButtonStyle.success, emoji="💾", row=3)
        save_btn.callback = self._save_callback
        self.add_item(save_btn)

    async def _type_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.message_type = self._type_select.values[0]
        await interaction.response.defer()

    async def _color_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.embed_color = self._color_select.values[0]
        await interaction.response.defer()

    async def _delete_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.auto_delete = int(self._delete_select.values[0])
        await interaction.response.defer()

    async def _save_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.saved = True
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                if hasattr(item, 'url') and item.url:
                    continue
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  ROLE MANAGEMENT VIEW (Quick Role Actions)
# ═══════════════════════════════════════════════════════════════

class RoleManagementView(GemView):
    """
    Interactive role management panel with add/remove buttons.
    Embedded in role command responses.
    """

    def __init__(self, author_id: int, target: discord.Member, roles: List[discord.Role]):
        super().__init__(timeout=60.0, add_links=False)
        self.author_id = author_id
        self.target = target
        self.action: str | None = None
        self.selected_roles: List[discord.Role] = []

        # Role select menu
        role_options = [
            discord.SelectOption(
                label=role.name[:100],
                value=str(role.id),
                emoji=EMOJIS.get("role", "🏷️"),
                description=f"{len(role.members)} members"
            )
            for role in roles[:25]  # Discord limit
        ]
        
        if role_options:
            self._role_select = discord.ui.Select(
                placeholder=f"{EMOJIS.get('role', '🏷️')} Select Roles",
                options=role_options, min_values=1, max_values=min(len(role_options), 10), row=0,
            )
            self._role_select.callback = self._role_callback
            self.add_item(self._role_select)

        # Action buttons
        add_btn = discord.ui.Button(label="Add Roles", style=discord.ButtonStyle.success, emoji=EMOJIS.get("add", "➕"), row=1)
        add_btn.callback = self._add_callback
        self.add_item(add_btn)

        remove_btn = discord.ui.Button(label="Remove Roles", style=discord.ButtonStyle.danger, emoji=EMOJIS.get("delete", "🗑️"), row=1)
        remove_btn.callback = self._remove_callback
        self.add_item(remove_btn)

    async def _role_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        self.selected_roles = [interaction.guild.get_role(int(rid)) for rid in self._role_select.values]
        self.selected_roles = [r for r in self.selected_roles if r]  # Filter None
        await interaction.response.defer()

    async def _add_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        if not self.selected_roles:
            return await interaction.response.send_message(f"{EMOJIS['error']} Please select roles first!", ephemeral=True)
        self.action = "add"
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                item.disabled = True
        await interaction.response.edit_message(view=self)

    async def _remove_callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.author_id:
            return await interaction.response.send_message(f"{EMOJIS['denied']} Not your panel.", ephemeral=True)
        if not self.selected_roles:
            return await interaction.response.send_message(f"{EMOJIS['error']} Please select roles first!", ephemeral=True)
        self.action = "remove"
        self.stop()
        for item in self.children:
            if isinstance(item, (discord.ui.Button, discord.ui.Select)):
                item.disabled = True
        await interaction.response.edit_message(view=self)


# ═══════════════════════════════════════════════════════════════
#  TICKET SYSTEM VIEW (Support Ticket Creation)
# ═══════════════════════════════════════════════════════════════

class TicketPanelView(GemView):
    """
    Persistent ticket panel with category selection.
    Users can create tickets by selecting a category.
    """

    def __init__(self):
        super().__init__(timeout=None, add_links=True)  # Persistent view

        # Category select
        category_options = [
            discord.SelectOption(label="General Support", value="general", emoji=EMOJIS.get("support", "💬"), description="General questions and help"),
            discord.SelectOption(label="Bug Report", value="bug", emoji=EMOJIS.get("error", "🐛"), description="Report a bug or issue"),
            discord.SelectOption(label="Feature Request", value="feature", emoji=EMOJIS.get("a_star", "⭐"), description="Suggest a new feature"),
            discord.SelectOption(label="Account Issues", value="account", emoji=EMOJIS.get("member", "👤"), description="Account-related problems"),
            discord.SelectOption(label="Other", value="other", emoji=EMOJIS.get("info", "ℹ️"), description="Something else"),
        ]
        self._category_select = discord.ui.Select(
            placeholder=f"{EMOJIS.get('ticket', '🎫')} Select Ticket Category",
            options=category_options, min_values=1, max_values=1, row=0,
            custom_id="ticket_category_select"
        )
        self._category_select.callback = self._category_callback
        self.add_item(self._category_select)

        # Create ticket button
        create_btn = discord.ui.Button(
            label="Create Ticket",
            style=discord.ButtonStyle.primary,
            emoji=EMOJIS.get("add", "➕"),
            row=1,
            custom_id="create_ticket_button"
        )
        create_btn.callback = self._create_callback
        self.add_item(create_btn)

        self.selected_category: str | None = None

    async def _category_callback(self, interaction: discord.Interaction):
        self.selected_category = self._category_select.values[0]
        await interaction.response.defer()

    async def _create_callback(self, interaction: discord.Interaction):
        if not self.selected_category:
            return await interaction.response.send_message(
                f"{EMOJIS.get('error', '❌')} Please select a category first!",
                ephemeral=True
            )
        # This would be handled by the command that uses this view
        await interaction.response.send_message(
            f"{EMOJIS.get('loading', '⏳')} Creating your ticket...",
            ephemeral=True
        )
