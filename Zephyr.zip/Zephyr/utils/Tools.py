"""
Tools.py — Shared decorators & helper functions for Zephyr Bot.

Provides:
  - blacklist_check()  — blocks blacklisted users/guilds
  - ignore_check()     — blocks ignored channels/users
  - is_owner()         — checks bot owner list
  - is_staff()         — checks bot staff list
  - get_prefix()       — resolves per-guild prefix
  - create_embed()     — emoji-rich embed factory
"""

from __future__ import annotations

import time
import functools
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

from utils.custjis import EMOJIS, COLORS

if TYPE_CHECKING:
    from core.Zephyr import Zephyr


# ═══════════════════════════════════════════════════════════════
#  DECORATORS
# ═══════════════════════════════════════════════════════════════

def blacklist_check():
    """
    Command check decorator.
    Returns False (silently blocks) if the user or guild is blacklisted.
    """
    async def predicate(ctx: commands.Context) -> bool:
        bot: Zephyr = ctx.bot  # type: ignore
        if ctx.author.id in bot.cache["blocked_users"]:
            return False
        if ctx.guild and ctx.guild.id in bot.cache["blocked_guilds"]:
            return False
        return True

    return commands.check(predicate)


def ignore_check():
    """
    Command check decorator.
    Returns False if the channel or user is in the ignore list,
    UNLESS the user is in the bypass list.
    """
    async def predicate(ctx: commands.Context) -> bool:
        bot: Zephyr = ctx.bot  # type: ignore
        if not ctx.guild:
            return True

        gid = ctx.guild.id

        # Bypass check first
        bypass = bot.cache["ignore_bypass"].get(gid, set())
        if ctx.author.id in bypass:
            return True

        # Channel ignore
        ign_ch = bot.cache["ignore_channels"].get(gid, set())
        if ctx.channel.id in ign_ch:
            return False

        # User ignore
        ign_usr = bot.cache["ignore_users"].get(gid, set())
        if ctx.author.id in ign_usr:
            return False

        return True

    return commands.check(predicate)


def is_owner():
    """Check if the command invoker is a bot owner (from config.yml)."""
    async def predicate(ctx: commands.Context) -> bool:
        bot: Zephyr = ctx.bot  # type: ignore
        return ctx.author.id in bot.owner_ids_set

    return commands.check(predicate)


def is_staff():
    """Check if the command invoker is a bot staff member or owner."""
    async def predicate(ctx: commands.Context) -> bool:
        bot: Zephyr = ctx.bot  # type: ignore
        if ctx.author.id in bot.owner_ids_set:
            return True
        # Check staff table in cache — loaded from np.db staff table
        # We check by looking at np.db staff during cache warm-up
        # For now, check DB directly if not cached
        import aiosqlite
        async with aiosqlite.connect("db/np.db") as db:
            async with db.execute(
                "SELECT 1 FROM staff WHERE user_id = ?", (ctx.author.id,)
            ) as cur:
                return await cur.fetchone() is not None

    return commands.check(predicate)


def is_extra_owner():
    """Check if the invoker is the guild owner or an extra owner."""
    async def predicate(ctx: commands.Context) -> bool:
        bot: Zephyr = ctx.bot  # type: ignore
        if not ctx.guild:
            return False
        if ctx.author.id == ctx.guild.owner_id:
            return True
        if ctx.author.id in bot.owner_ids_set:
            return True
        extras = bot.cache["extra_owners"].get(ctx.guild.id, set())
        return ctx.author.id in extras

    return commands.check(predicate)


def is_admin():
    """Check if the invoker has Administrator permission or is a bot owner/extra owner."""
    async def predicate(ctx: commands.Context) -> bool:
        bot: Zephyr = ctx.bot  # type: ignore
        if ctx.author.id in bot.owner_ids_set:
            return True
        if not ctx.guild:
            return False
        if ctx.author.id == ctx.guild.owner_id:
            return True
        extras = bot.cache["extra_owners"].get(ctx.guild.id, set())
        if ctx.author.id in extras:
            return True
        return ctx.author.guild_permissions.administrator  # type: ignore

    return commands.check(predicate)


# ═══════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════

async def get_prefix(bot: Zephyr, guild_id: int | None) -> str:
    """Resolve the prefix for a guild (or return default)."""
    if guild_id is None:
        return bot._default_prefix
    return bot.cache["prefixes"].get(guild_id, bot._default_prefix)


def create_embed(
    title: str | None = None,
    description: str | None = None,
    color: int | None = None,
    *,
    footer_text: str | None = None,
    footer_icon: str | None = None,
    author_name: str | None = None,
    author_icon: str | None = None,
    author_url: str | None = None,
    timestamp: bool = False,
) -> discord.Embed:
    """
    Ultra-premium embed factory with Zephyr purple branding.
    Automatically adds dividers, branding footer, and uses rich formatting.
    """
    import datetime

    # Add decorative bottom divider to description
    divider = "\n-# ━━━━━━━━━━━━━━━━━━━━━━━━━━"
    if description:
        final_desc = f"{description}{divider}"
    else:
        final_desc = None

    em = discord.Embed(
        title=title,
        description=final_desc,
        color=color or COLORS["primary"],
    )
    if timestamp:
        em.timestamp = datetime.datetime.now(datetime.timezone.utc)
    if footer_text:
        em.set_footer(text=f"✦ {footer_text} • Zephyr", icon_url=footer_icon)
    else:
        em.set_footer(text="✦ Zephyr • Premium Discord Bot", icon_url=footer_icon)
    if author_name:
        em.set_author(name=author_name, icon_url=author_icon, url=author_url)

    return em


def success_embed(message: str) -> discord.Embed:
    """Quick success embed."""
    return discord.Embed(
        description=f"{EMOJIS['success']} {message}",
        color=COLORS["success"],
    )


def error_embed(message: str) -> discord.Embed:
    """Quick error embed."""
    return discord.Embed(
        description=f"{EMOJIS['error']} {message}",
        color=COLORS["error"],
    )


def warning_embed(message: str) -> discord.Embed:
    """Quick warning embed."""
    return discord.Embed(
        description=f"{EMOJIS['warning']} {message}",
        color=COLORS["warning"],
    )


def denied_embed(message: str | None = None) -> discord.Embed:
    """Quick permission-denied embed."""
    msg = message or "You do not have permission to use this command."
    return discord.Embed(
        description=f"{EMOJIS['denied']} {msg}",
        color=COLORS["error"],
    )


def parse_duration(duration_str: str) -> int | None:
    """
    Parse a human duration string (e.g. '10s', '5m', '2h', '1d') into seconds.
    Returns None if invalid.
    """
    duration_str = duration_str.strip().lower()
    if not duration_str:
        return None

    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
    suffix = duration_str[-1]
    if suffix not in multipliers:
        return None

    try:
        value = int(duration_str[:-1])
    except ValueError:
        return None

    if value <= 0:
        return None

    return value * multipliers[suffix]


def format_duration(seconds: int) -> str:
    """Format seconds into a human-readable string."""
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        m, s = divmod(seconds, 60)
        return f"{m}m {s}s" if s else f"{m}m"
    elif seconds < 86400:
        h, remainder = divmod(seconds, 3600)
        m = remainder // 60
        return f"{h}h {m}m" if m else f"{h}h"
    else:
        d, remainder = divmod(seconds, 86400)
        h = remainder // 3600
        return f"{d}d {h}h" if h else f"{d}d"


def truncate(text: str, max_len: int = 1024) -> str:
    """Truncate text to fit in embed fields."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "…"
