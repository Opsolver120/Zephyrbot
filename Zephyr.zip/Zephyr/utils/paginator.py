"""
paginator.py — Reusable Button Paginator for Zephyr Bot.

Usage:
    pages = [embed1, embed2, embed3]
    view = ButtonPaginator(pages, ctx.author)
    await ctx.send(embed=pages[0], view=view)
"""

from __future__ import annotations

import discord
from discord.ext import commands
from utils.custjis import EMOJIS, COLORS


class ButtonPaginator(discord.ui.View):
    """
    A reusable paginator with Previous / Page Counter / Next / Share buttons.
    """

    def __init__(
        self,
        pages: list[discord.Embed],
        author: discord.Member | discord.User,
        *,
        timeout: float = 120.0,
    ):
        super().__init__(timeout=timeout)
        self.pages = pages
        self.author = author
        self.current = 0
        self.message: discord.Message | None = None
        self._update_buttons()

    def _update_buttons(self):
        self.first_btn.disabled = self.current == 0
        self.prev_btn.disabled = self.current == 0
        self.next_btn.disabled = self.current >= len(self.pages) - 1
        self.last_btn.disabled = self.current >= len(self.pages) - 1
        self.page_btn.label = f"{self.current + 1}/{len(self.pages)}"

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author.id:
            await interaction.response.send_message(
                f"{EMOJIS['denied']} This menu belongs to {self.author.mention}.",
                ephemeral=True,
            )
            return False
        return True

    async def on_timeout(self):
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

    @discord.ui.button(
        emoji="⏮️", style=discord.ButtonStyle.secondary, custom_id="pag_first"
    )
    async def first_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current = 0
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current], view=self)

    @discord.ui.button(
        emoji="◀️", style=discord.ButtonStyle.primary, custom_id="pag_prev"
    )
    async def prev_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current = max(0, self.current - 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current], view=self)

    @discord.ui.button(
        label="1/1", style=discord.ButtonStyle.secondary, disabled=True, custom_id="pag_page"
    )
    async def page_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()

    @discord.ui.button(
        emoji="▶️", style=discord.ButtonStyle.primary, custom_id="pag_next"
    )
    async def next_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current = min(len(self.pages) - 1, self.current + 1)
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current], view=self)

    @discord.ui.button(
        emoji="⏭️", style=discord.ButtonStyle.secondary, custom_id="pag_last"
    )
    async def last_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.current = len(self.pages) - 1
        self._update_buttons()
        await interaction.response.edit_message(embed=self.pages[self.current], view=self)


class ConfirmView(discord.ui.View):
    """Simple Yes/No confirmation view."""

    def __init__(self, author: discord.Member | discord.User, *, timeout: float = 30.0):
        super().__init__(timeout=timeout)
        self.author = author
        self.value: bool | None = None
        self.message: discord.Message | None = None

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author.id:
            await interaction.response.send_message(
                f"{EMOJIS['denied']} This confirmation belongs to {self.author.mention}.",
                ephemeral=True,
            )
            return False
        return True

    async def on_timeout(self):
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass

    @discord.ui.button(
        label="Confirm", style=discord.ButtonStyle.success, emoji="✅"
    )
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = True
        self.stop()
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True
        await interaction.response.edit_message(view=self)

    @discord.ui.button(
        label="Cancel", style=discord.ButtonStyle.danger, emoji="❌"
    )
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.value = False
        self.stop()
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True
        await interaction.response.edit_message(view=self)
